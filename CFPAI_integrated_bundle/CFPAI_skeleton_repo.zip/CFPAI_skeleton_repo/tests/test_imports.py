def test_imports():
    import cfpai
    import cfpai.pipeline
