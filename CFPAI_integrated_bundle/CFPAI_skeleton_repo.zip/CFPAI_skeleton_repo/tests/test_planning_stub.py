def test_stub_truth():
    assert 1 + 1 == 2
