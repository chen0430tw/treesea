from cfpai.pipeline import run_demo_pipeline

if __name__ == "__main__":
    result = run_demo_pipeline()
    print(result)
