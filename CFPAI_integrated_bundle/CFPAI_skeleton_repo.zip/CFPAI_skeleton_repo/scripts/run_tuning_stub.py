from cfpai.tuning_pipeline import run_tuning_demo

if __name__ == "__main__":
    print(run_tuning_demo())
