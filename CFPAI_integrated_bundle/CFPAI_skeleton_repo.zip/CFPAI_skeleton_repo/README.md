# CFPAI skeleton repo

CFPAI（Computational Finance Planning AI，计算金融规划人工智能）源码骨架仓库。

这份骨架仓库的目标不是直接提供完整成品，而是先把以下主链正式占住：

```text
状态表示 Φ
→ 反向 MOROZ 动态展开 R
→ 链式搜索 C
→ Tree Diagram 网格求值 T
→ 规划输出 Ψ
```

并把：

```text
UTM
```

作为正式调参与结构校准层嵌入到工程目录中。

## 当前包含

- `docs/`：白皮书、API、repo 结构、Claude 工作指南
- `cfpai/`：主包骨架
- `configs/`：toy / benchmark / multiasset / utm 配置占位
- `scripts/`：可运行脚本入口占位
- `tests/`：最小测试骨架
- `archive/`：预留旧原型与参考资料

## 推荐推进顺序

1. 拆 `data/stooq_loader.py`
2. 拆 `features/feature_pipeline.py`
3. 拆 `state/encoder.py`
4. 拆 `reverse_moroz/anchors.py`
5. 拆 `chain_search/path_builder.py`
6. 拆 `tree_diagram/grid_builder.py`
7. 拆 `planner/output_mapper.py`
8. 拆 `utm/tuner.py`
9. 接 `backtest/engine.py`
