from __future__ import annotations
from cfpai.pipeline import run_demo_pipeline

def run_multiasset_demo():
    return run_demo_pipeline()
