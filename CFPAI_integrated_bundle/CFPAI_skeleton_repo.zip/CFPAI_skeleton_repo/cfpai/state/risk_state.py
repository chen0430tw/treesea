from __future__ import annotations
import pandas as pd

def build_risk_state(row: pd.Series, asset_prefixes: list[str]) -> dict[str, float]:
    return {a: float(row.get(f"{a}_vol_20", 0.0)) for a in asset_prefixes}
