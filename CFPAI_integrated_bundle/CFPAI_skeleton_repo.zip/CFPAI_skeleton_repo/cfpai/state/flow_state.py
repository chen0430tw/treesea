from __future__ import annotations
import pandas as pd

def build_flow_state(row: pd.Series, asset_prefixes: list[str]) -> dict[str, float]:
    return {a: float(row.get(f"{a}_volume_z", 0.0)) for a in asset_prefixes}
