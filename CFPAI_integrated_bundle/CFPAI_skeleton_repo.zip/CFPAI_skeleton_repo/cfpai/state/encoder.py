from __future__ import annotations
import pandas as pd
from cfpai.contracts.state_types import MarketState
from .flow_state import build_flow_state
from .risk_state import build_risk_state
from .rotation_state import build_rotation_state
from .liquidity_state import build_liquidity_state

def encode_states(df: pd.DataFrame, asset_prefixes: list[str]) -> list[MarketState]:
    out: list[MarketState] = []
    for _, row in df.iterrows():
        flow = build_flow_state(row, asset_prefixes)
        risk = build_risk_state(row, asset_prefixes)
        rotation = build_rotation_state(row, asset_prefixes)
        liquidity = build_liquidity_state(row, asset_prefixes)
        latent = list(flow.values()) + list(risk.values()) + list(rotation.values())
        out.append(MarketState(
            timestamp=str(row["Date"]),
            flow_state=flow,
            risk_state=risk,
            rotation_state=rotation,
            liquidity_state=liquidity,
            latent_vector=[float(v) for v in latent],
        ))
    return out
