class GridEngine:
    def evaluate(self, state, grid):
        raise NotImplementedError
