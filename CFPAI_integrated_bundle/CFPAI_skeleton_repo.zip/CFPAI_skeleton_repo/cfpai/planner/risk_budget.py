from __future__ import annotations

def compute_risk_budget(risk_values: dict[str, float], bmax: float = 1.0, kappa: float = 0.5) -> float:
    avg_risk = sum(risk_values.values()) / max(len(risk_values), 1)
    return float(bmax * (2.718281828 ** (-kappa * avg_risk)))
