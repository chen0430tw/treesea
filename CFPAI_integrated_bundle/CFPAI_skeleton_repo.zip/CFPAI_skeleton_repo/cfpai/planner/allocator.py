from __future__ import annotations

def allocate_weights(value_map: dict[str, float], max_assets: int = 3, cash_floor: float = 0.0) -> dict[str, float]:
    ranked = sorted(value_map.items(), key=lambda kv: kv[1], reverse=True)[:max_assets]
    pos = [max(v, 0.0) for _, v in ranked]
    total = sum(pos)
    out = {k: 0.0 for k in value_map}
    if total <= 1e-12:
        return out
    scale = max(0.0, 1.0 - cash_floor)
    for (a, _), p in zip(ranked, pos):
        out[a] = float(scale * p / total)
    return out
