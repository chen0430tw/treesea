from __future__ import annotations
from cfpai.contracts.planning_types import PlanningOutput
from .risk_budget import compute_risk_budget
from .allocator import allocate_weights

def build_planning_output(timestamp: str, value_map: dict[str, float], risk_map: dict[str, float]) -> PlanningOutput:
    budget = compute_risk_budget(risk_map)
    actions = allocate_weights(value_map)
    label = "risk_on" if sum(actions.values()) > 0.6 else "neutral"
    return PlanningOutput(
        timestamp=timestamp,
        market_label=label,
        selected_paths=list(sorted(value_map, key=value_map.get, reverse=True)[:3]),
        risk_budget=budget,
        actions=actions,
        diagnostics={"value_map": value_map, "risk_map": risk_map},
    )
