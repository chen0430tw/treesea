from __future__ import annotations
from cfpai.api.tuning_api import run_utm_tuning

def run_tuning_demo():
    return run_utm_tuning()
