from __future__ import annotations
import matplotlib.pyplot as plt
import pandas as pd

def plot_equity(date_series: pd.Series, equity: pd.Series, out_path: str) -> None:
    plt.figure(figsize=(10, 6))
    plt.plot(date_series, equity)
    plt.yscale("log")
    plt.tight_layout()
    plt.savefig(out_path, dpi=160)
    plt.close()
