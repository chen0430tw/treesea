from __future__ import annotations
import pandas as pd

def backtest_weights(weights: pd.DataFrame, returns_df: pd.DataFrame, asset_cols: list[str]) -> pd.Series:
    pret = pd.Series(0.0, index=returns_df.index)
    for a in asset_cols:
        pret = pret + weights[f"{a}_weight"].shift(1).fillna(0.0) * returns_df[f"{a}_ret_1d"].fillna(0.0)
    return pret
