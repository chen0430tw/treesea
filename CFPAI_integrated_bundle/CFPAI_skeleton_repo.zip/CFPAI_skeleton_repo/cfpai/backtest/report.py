from __future__ import annotations
import json
from pathlib import Path

def write_report(path: str | Path, summary: dict) -> None:
    Path(path).write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
