from __future__ import annotations
import numpy as np
import pandas as pd

def add_risk_features(df: pd.DataFrame, prefix: str) -> pd.DataFrame:
    x = df.copy()
    close = x[f"{prefix}_Close"]
    ret = x[f"{prefix}_ret_1d"] if f"{prefix}_ret_1d" in x.columns else close.pct_change()
    x[f"{prefix}_vol_20"] = ret.rolling(20).std() * np.sqrt(252)
    x[f"{prefix}_roll_max_63"] = close.rolling(63).max()
    x[f"{prefix}_drawdown_63"] = close / x[f"{prefix}_roll_max_63"] - 1
    return x
