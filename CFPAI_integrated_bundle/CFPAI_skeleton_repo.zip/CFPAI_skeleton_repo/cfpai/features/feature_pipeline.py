from __future__ import annotations
import pandas as pd
from .price_features import add_price_features
from .flow_features import add_flow_features
from .risk_features import add_risk_features

def build_feature_pipeline(df: pd.DataFrame, asset_prefixes: list[str]) -> pd.DataFrame:
    x = df.copy()
    for a in asset_prefixes:
        x = add_price_features(x, a)
        x = add_flow_features(x, a)
        x = add_risk_features(x, a)
    return x.dropna().reset_index(drop=True)
