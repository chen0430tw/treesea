from __future__ import annotations
import numpy as np
import pandas as pd

def add_price_features(df: pd.DataFrame, prefix: str) -> pd.DataFrame:
    x = df.copy()
    close = x[f"{prefix}_Close"]
    x[f"{prefix}_ret_1d"] = close.pct_change()
    x[f"{prefix}_mom_20"] = close.pct_change(20)
    x[f"{prefix}_ma_50"] = close.rolling(50).mean()
    x[f"{prefix}_ma_200"] = close.rolling(200).mean()
    x[f"{prefix}_trend_gap"] = x[f"{prefix}_ma_50"] / x[f"{prefix}_ma_200"] - 1
    return x
