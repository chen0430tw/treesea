from __future__ import annotations
import pandas as pd

def add_flow_features(df: pd.DataFrame, prefix: str) -> pd.DataFrame:
    x = df.copy()
    volm = x[f"{prefix}_Volume"]
    vol_mean = volm.rolling(20).mean()
    vol_std = volm.rolling(20).std()
    x[f"{prefix}_volume_z"] = (volm - vol_mean) / vol_std
    return x
