from __future__ import annotations
import pandas as pd

def build_rotation_snapshot(df: pd.DataFrame, asset_prefixes: list[str]) -> dict[str, float]:
    latest = {}
    if len(df) == 0:
        return latest
    i = len(df) - 1
    for a in asset_prefixes:
        latest[a] = float(df.at[i, f"{a}_mom_20"]) if f"{a}_mom_20" in df.columns else 0.0
    return latest
