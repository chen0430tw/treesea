from __future__ import annotations
from cfpai.contracts.path_types import DynamicPath

def build_grid(paths: list[DynamicPath]) -> dict:
    return {
        "nodes": [p.nodes[0] for p in paths],
        "edges": [(p.nodes[0], p.nodes[-1]) for p in paths],
        "paths": paths,
    }
