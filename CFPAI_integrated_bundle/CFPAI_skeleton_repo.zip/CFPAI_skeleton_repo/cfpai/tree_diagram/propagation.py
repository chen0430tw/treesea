from __future__ import annotations

def propagate(values: dict[str, float], eta: float = 0.85) -> dict[str, float]:
    # simple identity-like propagation placeholder
    return {k: float(v * eta + v) for k, v in values.items()}
