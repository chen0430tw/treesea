from __future__ import annotations
from cfpai.contracts.state_types import MarketState

def node_utility(state: MarketState, asset: str, lambda_risk: float = 0.42) -> float:
    flow = state.flow_state.get(asset, 0.0)
    trend = state.rotation_state.get(asset, 0.0)
    risk = state.risk_state.get(asset, 0.0)
    return float(flow + trend - lambda_risk * risk)
