from __future__ import annotations
from cfpai.contracts.grid_types import GridNodeValue
from cfpai.contracts.state_types import MarketState
from .node_utility import node_utility
from .propagation import propagate

def evaluate_grid(state: MarketState, grid: dict) -> list[GridNodeValue]:
    raw = {asset: node_utility(state, asset) for asset in grid["nodes"]}
    prop = propagate(raw)
    return [
        GridNodeValue(node_id=a, utility=float(raw[a]), propagated_value=float(prop[a]))
        for a in raw
    ]
