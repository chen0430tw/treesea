from __future__ import annotations
from cfpai.contracts.grid_types import GridNodeValue

def aggregate_grid_values(values: list[GridNodeValue]) -> dict[str, float]:
    return {v.node_id: v.propagated_value for v in values}
