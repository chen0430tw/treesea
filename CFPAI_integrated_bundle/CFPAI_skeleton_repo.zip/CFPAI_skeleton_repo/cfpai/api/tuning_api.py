from __future__ import annotations
from cfpai.utm.tuner import tune_with_utm

def run_utm_tuning(*args, **kwargs):
    return tune_with_utm(*args, **kwargs)
