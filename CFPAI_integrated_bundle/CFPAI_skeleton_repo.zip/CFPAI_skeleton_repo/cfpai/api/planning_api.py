from __future__ import annotations
from cfpai.reverse_moroz.anchors import detect_anchors
from cfpai.reverse_moroz.expansion import expand_reverse_moroz
from cfpai.chain_search.path_builder import build_top_paths
from cfpai.tree_diagram.grid_builder import build_grid
from cfpai.tree_diagram.engines import evaluate_grid
from cfpai.tree_diagram.result_aggregator import aggregate_grid_values
from cfpai.planner.output_mapper import build_planning_output

def run_single_step_plan(state, assets):
    anchors = detect_anchors(state)
    scores = expand_reverse_moroz(state, assets)
    paths = build_top_paths(scores, topk=2)
    grid = build_grid(paths)
    grid_values = evaluate_grid(state, grid)
    value_map = aggregate_grid_values(grid_values)
    return build_planning_output(state.timestamp, value_map, state.risk_state)
