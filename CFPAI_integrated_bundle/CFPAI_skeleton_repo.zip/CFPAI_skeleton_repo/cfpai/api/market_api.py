from __future__ import annotations
from cfpai.data.stooq_loader import download_stooq_csv
from cfpai.data.aligner import align_on_date
from cfpai.data.universe_builder import build_default_universe
from cfpai.features.feature_pipeline import build_feature_pipeline

def load_default_market(start: str = "2010-01-01", end: str | None = None):
    universe = build_default_universe()
    frames = {s: download_stooq_csv(s, start, end) for s in universe}
    aligned = align_on_date(frames)
    prefixes = universe
    features = build_feature_pipeline(aligned, prefixes)
    return features, prefixes
