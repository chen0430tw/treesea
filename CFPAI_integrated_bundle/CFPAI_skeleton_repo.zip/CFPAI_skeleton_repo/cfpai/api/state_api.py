from __future__ import annotations
from cfpai.state.encoder import encode_states

def run_state_encoding(features, asset_prefixes):
    return encode_states(features, asset_prefixes)
