from __future__ import annotations
from cfpai.contracts.state_types import MarketState

def reverse_moroz_score(state: MarketState, asset: str, w_mom: float = 0.9, w_trend: float = 0.2, w_vol: float = 0.33, w_dd: float = 0.36) -> float:
    mom = state.rotation_state.get(asset, 0.0)
    vol = state.risk_state.get(asset, 0.0)
    flow = state.flow_state.get(asset, 0.0)
    return float(w_mom * flow + w_trend * mom - w_vol * vol + w_dd * min(flow, 0.0))
