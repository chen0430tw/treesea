from __future__ import annotations
from cfpai.contracts.path_types import DynamicAnchor
from cfpai.contracts.state_types import MarketState

def detect_anchors(state: MarketState) -> list[DynamicAnchor]:
    anchors = []
    for k, v in state.rotation_state.items():
        anchors.append(DynamicAnchor(
            anchor_id=f"rot::{k}",
            anchor_type="rotation",
            score=float(v),
            description=f"Rotation anchor for {k}",
        ))
    anchors.sort(key=lambda a: a.score, reverse=True)
    return anchors
