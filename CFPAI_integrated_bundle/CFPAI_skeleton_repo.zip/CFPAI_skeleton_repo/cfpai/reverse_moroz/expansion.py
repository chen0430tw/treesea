from __future__ import annotations
from cfpai.contracts.state_types import MarketState
from .scoring import reverse_moroz_score
from .filters import keep_top_assets

def expand_reverse_moroz(state: MarketState, assets: list[str], topk: int = 3) -> dict[str, float]:
    scores = {a: reverse_moroz_score(state, a) for a in assets}
    return keep_top_assets(scores, topk=topk)
