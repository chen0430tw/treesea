from __future__ import annotations

def keep_top_assets(score_map: dict[str, float], topk: int = 3) -> dict[str, float]:
    ranked = sorted(score_map.items(), key=lambda kv: kv[1], reverse=True)
    return dict(ranked[:topk])
