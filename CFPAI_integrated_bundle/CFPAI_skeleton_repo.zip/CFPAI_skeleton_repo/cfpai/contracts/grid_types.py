from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

@dataclass
class GridNodeValue:
    node_id: str
    utility: float
    propagated_value: float
    meta: dict[str, Any] = field(default_factory=dict)
