from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

@dataclass
class MarketObservation:
    timestamp: str
    features: dict[str, float]
    meta: dict[str, Any] = field(default_factory=dict)

@dataclass
class AssetObservation:
    symbol: str
    timestamp: str
    open: float
    high: float
    low: float
    close: float
    volume: float
    extra_features: dict[str, float] = field(default_factory=dict)
