from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

@dataclass
class MarketState:
    timestamp: str
    flow_state: dict[str, float]
    risk_state: dict[str, float]
    rotation_state: dict[str, float]
    liquidity_state: dict[str, float]
    latent_vector: list[float]
    meta: dict[str, Any] = field(default_factory=dict)
