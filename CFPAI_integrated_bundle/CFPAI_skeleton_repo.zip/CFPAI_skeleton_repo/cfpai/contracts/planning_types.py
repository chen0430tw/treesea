from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

@dataclass
class PlanningOutput:
    timestamp: str
    market_label: str
    selected_paths: list[str]
    risk_budget: float
    actions: dict[str, float]
    diagnostics: dict[str, Any] = field(default_factory=dict)
