from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

@dataclass
class DynamicAnchor:
    anchor_id: str
    anchor_type: str
    score: float
    description: str
    meta: dict[str, Any] = field(default_factory=dict)

@dataclass
class DynamicPath:
    path_id: str
    nodes: list[str]
    score: float
    horizon: int
    risk_penalty: float
    meta: dict[str, Any] = field(default_factory=dict)
