from __future__ import annotations

DEFAULT_UNIVERSE = ["SPY.US", "QQQ.US", "TLT.US", "GLD.US", "XLF.US", "XLK.US", "XLE.US"]

def build_default_universe() -> list[str]:
    return DEFAULT_UNIVERSE.copy()
