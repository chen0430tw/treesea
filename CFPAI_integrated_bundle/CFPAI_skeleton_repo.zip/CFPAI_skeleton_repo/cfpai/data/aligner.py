from __future__ import annotations
import pandas as pd

def align_on_date(frames: dict[str, pd.DataFrame]) -> pd.DataFrame:
    merged = None
    for name, df in frames.items():
        use = df.copy()
        keep = ["Date", "Open", "High", "Low", "Close", "Volume"]
        use = use[keep].rename(columns={c: f"{name}_{c}" for c in keep if c != "Date"})
        merged = use if merged is None else merged.merge(use, on="Date", how="inner")
    return merged.sort_values("Date").reset_index(drop=True)
