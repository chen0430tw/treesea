from __future__ import annotations
import io
import pandas as pd
import requests

def download_stooq_csv(symbol: str, start: str | None = None, end: str | None = None) -> pd.DataFrame:
    url = "https://stooq.com/q/d/l/"
    params = {"s": symbol.lower(), "i": "d"}
    if start:
        params["d1"] = pd.to_datetime(start).strftime("%Y%m%d")
    if end:
        params["d2"] = pd.to_datetime(end).strftime("%Y%m%d")
    r = requests.get(url, params=params, timeout=30)
    r.raise_for_status()
    df = pd.read_csv(io.StringIO(r.text))
    df["Date"] = pd.to_datetime(df["Date"])
    return df.sort_values("Date").reset_index(drop=True)
