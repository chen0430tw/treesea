from __future__ import annotations
from cfpai.api.market_api import load_default_market
from cfpai.api.state_api import run_state_encoding
from cfpai.api.planning_api import run_single_step_plan

def run_demo_pipeline():
    features, prefixes = load_default_market()
    states = run_state_encoding(features, prefixes)
    return run_single_step_plan(states[-1], prefixes)
