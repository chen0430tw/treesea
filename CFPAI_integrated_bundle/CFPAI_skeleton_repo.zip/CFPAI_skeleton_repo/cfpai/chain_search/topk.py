from __future__ import annotations
from cfpai.contracts.path_types import DynamicPath

def topk_paths(paths: list[DynamicPath], k: int = 2) -> list[DynamicPath]:
    return sorted(paths, key=lambda p: p.score, reverse=True)[:k]
