from __future__ import annotations
from .transition_rules import persistence_bonus

def path_score(asset_score: float, prev_asset: str | None, current_asset: str, bonus: float = 0.13) -> float:
    return float(asset_score + persistence_bonus(prev_asset, current_asset, bonus))
