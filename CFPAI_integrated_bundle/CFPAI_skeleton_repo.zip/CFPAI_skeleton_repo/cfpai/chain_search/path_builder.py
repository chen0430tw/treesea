from __future__ import annotations
from cfpai.contracts.path_types import DynamicPath

def build_top_paths(score_map: dict[str, float], prev_asset: str | None = None, topk: int = 2) -> list[DynamicPath]:
    ranked = sorted(score_map.items(), key=lambda kv: kv[1], reverse=True)
    out = []
    for i, (asset, score) in enumerate(ranked[:topk]):
        nxt = asset if prev_asset == asset else (ranked[min(i+1, len(ranked)-1)][0] if len(ranked) > 1 else asset)
        out.append(DynamicPath(
            path_id=f"path::{asset}",
            nodes=[asset, nxt],
            score=float(score),
            horizon=2,
            risk_penalty=0.0,
            meta={"anchor_asset": asset},
        ))
    return out
