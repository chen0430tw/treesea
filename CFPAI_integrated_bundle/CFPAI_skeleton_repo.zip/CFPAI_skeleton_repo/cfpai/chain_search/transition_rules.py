from __future__ import annotations

def persistence_bonus(prev_asset: str | None, current_asset: str, bonus: float = 0.13) -> float:
    return bonus if prev_asset == current_asset else 0.0
