from __future__ import annotations
import numpy as np

def contract_scales(current_scales: np.ndarray, elite_std: np.ndarray, lower: np.ndarray, upper: np.ndarray) -> np.ndarray:
    return np.maximum(0.03 * (upper - lower), 0.85 * elite_std + 0.15 * current_scales)
