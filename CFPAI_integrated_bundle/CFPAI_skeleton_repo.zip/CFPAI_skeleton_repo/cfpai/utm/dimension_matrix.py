from __future__ import annotations
import numpy as np

def approximate_dimension_matrix(elite_vectors: np.ndarray) -> np.ndarray:
    if elite_vectors.ndim != 2 or elite_vectors.shape[0] < 2:
        return np.eye(elite_vectors.shape[1] if elite_vectors.ndim == 2 else 1)
    cov = np.cov(elite_vectors, rowvar=False)
    return np.atleast_2d(cov)
