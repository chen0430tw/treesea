from __future__ import annotations
import pandas as pd

def best_by_generation(history: pd.DataFrame) -> pd.DataFrame:
    return history.sort_values(["generation", "score"], ascending=[True, False]).groupby("generation").head(1).reset_index(drop=True)
