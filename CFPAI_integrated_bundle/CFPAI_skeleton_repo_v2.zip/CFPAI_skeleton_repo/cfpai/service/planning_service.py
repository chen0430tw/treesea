from __future__ import annotations

def planning_service(*args, **kwargs) -> dict:
    return {"status": "stub", "message": "Implement planning_service here."}
