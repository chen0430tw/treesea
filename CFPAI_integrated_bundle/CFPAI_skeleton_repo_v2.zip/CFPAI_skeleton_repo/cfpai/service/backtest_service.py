from __future__ import annotations

def backtest_service(*args, **kwargs) -> dict:
    return {"status": "stub", "message": "Implement backtest_service here."}
