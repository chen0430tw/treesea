from __future__ import annotations
from pathlib import Path

def run_tuning(
    symbols: list[str] | None = None,
    start: str | None = None,
    end: str | None = None,
    generations: int = 6,
    population: int = 12,
    elite_k: int = 4,
    seed: int = 430,
) -> dict:
    symbols = symbols or ["SPY.US", "QQQ.US", "TLT.US", "GLD.US", "XLF.US", "XLK.US", "XLE.US"]
    return {
        "status": "stub",
        "symbols": symbols,
        "start": start,
        "end": end,
        "generations": generations,
        "population": population,
        "elite_k": elite_k,
        "seed": seed,
        "run_dir": str(Path("runs") / "tuning_latest"),
        "best_params": {},
        "message": "Connect to cfpai/service/tuning_service.py",
    }
