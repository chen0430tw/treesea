from __future__ import annotations

def build_report(run_dir: str, format: str = "markdown") -> str:
    if format == "markdown":
        return f"# CFPAI Agent Report\n\nRun dir: `{run_dir}`\n\nStatus: stub\n"
    return f"Run dir: {run_dir} | Status: stub"
