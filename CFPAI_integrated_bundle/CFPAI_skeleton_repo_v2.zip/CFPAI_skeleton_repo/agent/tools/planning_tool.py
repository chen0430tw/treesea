from __future__ import annotations
from pathlib import Path
from typing import Any

def run_planning(
    symbols: list[str] | None = None,
    start: str | None = None,
    end: str | None = None,
    mode: str = "multiasset",
    config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    symbols = symbols or ["SPY.US", "QQQ.US", "TLT.US", "GLD.US", "XLF.US", "XLK.US", "XLE.US"]
    return {
        "status": "stub",
        "mode": mode,
        "symbols": symbols,
        "start": start,
        "end": end,
        "config": config or {},
        "run_dir": str(Path("runs") / "planning_latest"),
        "message": "Connect to cfpai/service/planning_service.py",
    }
