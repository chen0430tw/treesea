from __future__ import annotations

def explain_latest_run(run_dir: str) -> dict:
    return {
        "status": "stub",
        "run_dir": run_dir,
        "anchors": [],
        "paths": [],
        "weights": {},
        "risk_budget": None,
        "message": "Connect to cfpai/service/diagnostics_service.py",
    }
