from __future__ import annotations
from pathlib import Path
from typing import Any

def run_backtest(
    symbols: list[str] | None = None,
    start: str | None = None,
    end: str | None = None,
    use_utm: bool = False,
    config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    symbols = symbols or ["SPY.US", "QQQ.US", "TLT.US", "GLD.US", "XLF.US", "XLK.US", "XLE.US"]
    return {
        "status": "stub",
        "symbols": symbols,
        "start": start,
        "end": end,
        "use_utm": use_utm,
        "config": config or {},
        "run_dir": str(Path("runs") / ("backtest_utm_latest" if use_utm else "backtest_latest")),
        "message": "Connect to cfpai/service/backtest_service.py",
    }
