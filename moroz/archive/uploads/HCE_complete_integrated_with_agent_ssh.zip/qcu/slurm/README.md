# QCU Slurm Templates
