def main():
    print("QCU runner placeholder")
