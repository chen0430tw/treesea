# mpi_adapter placeholder
