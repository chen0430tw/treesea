def main():
    print("run_local placeholder for QCU")
