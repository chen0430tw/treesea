def main():
    print("inspect placeholder for QCU")
