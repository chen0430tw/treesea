def main():
    print("QCU CLI placeholder")
