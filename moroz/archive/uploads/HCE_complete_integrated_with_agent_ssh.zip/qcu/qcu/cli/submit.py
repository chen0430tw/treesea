def main():
    print("submit placeholder for QCU")
