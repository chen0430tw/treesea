# collapse_operator placeholder
