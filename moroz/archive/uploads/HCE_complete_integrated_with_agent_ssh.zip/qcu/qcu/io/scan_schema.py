# scan_schema placeholder
