# result_io placeholder
