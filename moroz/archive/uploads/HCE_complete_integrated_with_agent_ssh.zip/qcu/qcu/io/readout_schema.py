# readout_schema placeholder
