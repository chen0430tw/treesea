# shared config loader placeholder
