# shared config validator placeholder
