# metrics_writer placeholder
