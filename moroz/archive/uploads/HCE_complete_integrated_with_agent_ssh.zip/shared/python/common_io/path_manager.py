# path_manager placeholder
