# shared logger placeholder
