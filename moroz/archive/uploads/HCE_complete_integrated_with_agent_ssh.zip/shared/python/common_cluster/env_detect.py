# env_detect placeholder
