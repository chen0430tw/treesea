# Tree Diagram abstract layer placeholder: worldline_kernel
