# input_loader placeholder
