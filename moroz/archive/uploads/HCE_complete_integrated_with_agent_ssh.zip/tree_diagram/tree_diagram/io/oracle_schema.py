# oracle_schema placeholder
