# output_writer placeholder
