def main():
    print("run_local placeholder for Tree Diagram")
