def main():
    print("inspect placeholder for Tree Diagram")
