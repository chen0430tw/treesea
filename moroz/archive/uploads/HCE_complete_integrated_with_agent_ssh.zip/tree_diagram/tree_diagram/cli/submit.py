def main():
    print("submit placeholder for Tree Diagram")
