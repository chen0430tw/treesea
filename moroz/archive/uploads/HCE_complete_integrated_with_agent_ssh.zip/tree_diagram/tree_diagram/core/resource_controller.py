# resource_controller placeholder
