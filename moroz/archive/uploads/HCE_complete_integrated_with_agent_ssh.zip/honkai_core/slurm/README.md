# Honkai Core Slurm Templates
