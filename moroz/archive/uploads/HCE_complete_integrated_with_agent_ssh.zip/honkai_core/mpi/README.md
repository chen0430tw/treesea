# Honkai Core MPI
