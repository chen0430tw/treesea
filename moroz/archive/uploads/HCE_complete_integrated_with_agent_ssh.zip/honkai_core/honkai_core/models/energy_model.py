# energy_model placeholder
