# threshold_model placeholder
