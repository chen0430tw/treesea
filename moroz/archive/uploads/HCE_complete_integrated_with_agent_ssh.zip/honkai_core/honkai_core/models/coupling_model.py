# coupling_model placeholder
