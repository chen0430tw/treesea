""" Honkai Core package. """
