def main():
    print("submit placeholder for Honkai Core")
