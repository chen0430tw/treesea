def main():
    print("run_local placeholder for Honkai Core")
