def main():
    print("inspect placeholder for Honkai Core")
