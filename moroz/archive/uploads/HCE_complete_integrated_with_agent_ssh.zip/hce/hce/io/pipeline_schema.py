# pipeline_schema placeholder
