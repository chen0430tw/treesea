def main():
    print("HCE runner placeholder")
