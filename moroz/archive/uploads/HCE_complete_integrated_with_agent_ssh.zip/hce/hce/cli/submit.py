def main():
    print("submit placeholder for HCE")
