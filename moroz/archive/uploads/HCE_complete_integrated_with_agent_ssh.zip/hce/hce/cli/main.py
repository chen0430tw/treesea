def main():
    print("HCE CLI placeholder")
