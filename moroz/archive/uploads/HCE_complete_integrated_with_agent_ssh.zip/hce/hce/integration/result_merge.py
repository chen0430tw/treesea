# result_merge placeholder
