# hc_bridge placeholder
