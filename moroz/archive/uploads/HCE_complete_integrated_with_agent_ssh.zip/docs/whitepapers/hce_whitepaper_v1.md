# HCE Whitepaper
