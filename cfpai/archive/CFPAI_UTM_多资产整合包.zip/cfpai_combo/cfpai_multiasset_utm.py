from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple
import json
import numpy as np
import pandas as pd


@dataclass
class CFPAIParams:
    w_mom: float = 1.0
    w_trend: float = 0.8
    w_vol: float = 0.25
    w_dd: float = 0.35
    lambda_risk: float = 0.35
    persistence_bonus: float = 0.08
    warmup: int = 120
    max_assets: int = 3
    cash_weight_floor: float = 0.0


class CFPAIMultiAssetUTM:
    """
    Multi-asset CFPAI prototype.

    Expected input folder:
    - one CSV per asset
    - each CSV must contain Date, Open, High, Low, Close, Volume

    Example:
    data/
      SPY.csv
      QQQ.csv
      TLT.csv
      GLD.csv
      XLF.csv
      XLK.csv
      XLE.csv
    """

    def __init__(self, data: pd.DataFrame, params: CFPAIParams):
        self.data = data.copy()
        self.params = params
        self.assets = sorted([c[:-6] for c in data.columns if c.endswith("_Close")])

    @staticmethod
    def load_folder(folder: str | Path) -> pd.DataFrame:
        folder = Path(folder)
        merged = None
        for csv_path in sorted(folder.glob("*.csv")):
            asset = csv_path.stem.upper()
            df = pd.read_csv(csv_path)
            df["Date"] = pd.to_datetime(df["Date"])
            df = df.sort_values("Date").reset_index(drop=True)
            keep = ["Date", "Open", "High", "Low", "Close", "Volume"]
            df = df[keep].copy()
            df = df.rename(columns={c: f"{asset}_{c}" for c in keep if c != "Date"})
            if merged is None:
                merged = df
            else:
                merged = merged.merge(df, on="Date", how="inner")
        if merged is None:
            raise FileNotFoundError("No CSV files found in the folder.")
        return merged.sort_values("Date").reset_index(drop=True)

    def build_features(self) -> pd.DataFrame:
        x = self.data.copy()
        for a in self.assets:
            close = x[f"{a}_Close"]
            volm = x[f"{a}_Volume"]
            x[f"{a}_ret_1d"] = close.pct_change()
            x[f"{a}_mom_20"] = close.pct_change(20)
            x[f"{a}_ma_50"] = close.rolling(50).mean()
            x[f"{a}_ma_200"] = close.rolling(200).mean()
            x[f"{a}_trend_gap"] = x[f"{a}_ma_50"] / x[f"{a}_ma_200"] - 1
            x[f"{a}_vol_20"] = x[f"{a}_ret_1d"].rolling(20).std() * np.sqrt(252)
            x[f"{a}_roll_max_63"] = close.rolling(63).max()
            x[f"{a}_drawdown_63"] = close / x[f"{a}_roll_max_63"] - 1
            vol_mean = volm.rolling(20).mean()
            vol_std = volm.rolling(20).std()
            x[f"{a}_volume_z"] = (volm - vol_mean) / vol_std
        return x.dropna().reset_index(drop=True)

    def compute_anchor_scores(self, x: pd.DataFrame) -> pd.DataFrame:
        p = self.params
        rows = []
        for _, row in x.iterrows():
            scores = {}
            for a in self.assets:
                score = (
                    p.w_mom * row[f"{a}_mom_20"]
                    + p.w_trend * row[f"{a}_trend_gap"]
                    - p.w_vol * row[f"{a}_vol_20"]
                    + 0.10 * np.clip(row[f"{a}_volume_z"], -3, 3)
                    + p.w_dd * row[f"{a}_drawdown_63"]
                )
                scores[a] = float(score)
            rows.append(scores)
        score_df = pd.DataFrame(rows)
        score_df.insert(0, "Date", x["Date"].values)
        return score_df

    def pick_chain_paths(self, score_df: pd.DataFrame) -> pd.DataFrame:
        # simple chain search: top assets today + persistence from last 5 days
        top1 = []
        top2 = []
        path = []
        for i in range(len(score_df)):
            asset_scores = score_df.iloc[i].drop(labels=["Date"]).sort_values(ascending=False)
            a1 = asset_scores.index[0]
            a2 = asset_scores.index[1] if len(asset_scores) > 1 else a1
            if i >= 5:
                prev = top1[max(0, i-5):i]
                if len(prev) > 0 and prev.count(a1) / len(prev) > 0.6:
                    pth = f"{a1} -> {a1}"
                else:
                    pth = f"{a1} -> {a2}"
            else:
                pth = f"{a1} -> {a2}"
            top1.append(a1)
            top2.append(a2)
            path.append(pth)
        out = pd.DataFrame({
            "Date": score_df["Date"].values,
            "anchor_asset": top1,
            "secondary_asset": top2,
            "path": path,
        })
        return out

    def tree_diagram_grid(self, x: pd.DataFrame, chain_df: pd.DataFrame) -> pd.DataFrame:
        # simplified grid evaluation:
        # choose up to max_assets assets by anchor scores with cash fallback
        p = self.params
        weights = []
        for i in range(len(x)):
            asset_scores = {}
            risk_penalties = {}
            for a in self.assets:
                score = (
                    p.w_mom * x.at[i, f"{a}_mom_20"]
                    + p.w_trend * x.at[i, f"{a}_trend_gap"]
                    - p.w_vol * x.at[i, f"{a}_vol_20"]
                    + p.w_dd * x.at[i, f"{a}_drawdown_63"]
                )
                risk = p.lambda_risk * x.at[i, f"{a}_vol_20"]
                asset_scores[a] = float(score - risk)
                risk_penalties[a] = float(risk)

            ranked = sorted(asset_scores.items(), key=lambda kv: kv[1], reverse=True)
            chosen = ranked[:p.max_assets]
            positive = np.array([max(v, 0.0) for _, v in chosen], dtype=float)

            w = {a: 0.0 for a in self.assets}
            if positive.sum() <= 1e-12:
                # no strong path, go to cash
                pass
            else:
                positive = positive / positive.sum()
                for (a, _), ww in zip(chosen, positive):
                    w[a] = float(ww)

            weights.append(w)

        wdf = pd.DataFrame(weights)
        wdf.insert(0, "Date", x["Date"].values)
        return wdf

    def backtest(self) -> Tuple[pd.DataFrame, Dict[str, float]]:
        x = self.build_features()
        scores = self.compute_anchor_scores(x)
        chains = self.pick_chain_paths(scores)
        weights = self.tree_diagram_grid(x, chains)

        result = x[["Date"]].copy()
        for a in self.assets:
            result[f"{a}_weight"] = weights[a].values
            result[f"{a}_ret_1d"] = x[f"{a}_ret_1d"].values

        portfolio_ret = np.zeros(len(result))
        for a in self.assets:
            portfolio_ret += result[f"{a}_weight"].shift(1).fillna(0).to_numpy() * result[f"{a}_ret_1d"].fillna(0).to_numpy()
        result["portfolio_ret"] = portfolio_ret
        result["equity"] = (1 + result["portfolio_ret"]).cumprod()

        equity = result["equity"]
        total_return = float(equity.iloc[-1] - 1)
        ann_return = float(equity.iloc[-1] ** (252 / len(result)) - 1)
        ann_vol = float(pd.Series(result["portfolio_ret"]).std() * np.sqrt(252))
        sharpe = float(ann_return / ann_vol) if ann_vol > 1e-12 else float("nan")
        dd = equity / equity.cummax() - 1
        max_dd = float(dd.min())

        stats = {
            "total_return": total_return,
            "ann_return": ann_return,
            "ann_vol": ann_vol,
            "sharpe": sharpe,
            "max_dd": max_dd,
        }
        return result, stats


def save_run(folder: str | Path, result: pd.DataFrame, stats: Dict[str, float]) -> None:
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    result.to_csv(folder / "multiasset_signals.csv", index=False, encoding="utf-8-sig")
    (folder / "multiasset_stats.json").write_text(
        json.dumps(stats, indent=2, ensure_ascii=False), encoding="utf-8"
    )


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--data-folder", type=str, required=True)
    parser.add_argument("--out-folder", type=str, required=True)
    args = parser.parse_args()

    data = CFPAIMultiAssetUTM.load_folder(args.data_folder)
    model = CFPAIMultiAssetUTM(data=data, params=CFPAIParams())
    result, stats = model.backtest()
    save_run(args.out_folder, result, stats)
    print(json.dumps(stats, indent=2, ensure_ascii=False))
