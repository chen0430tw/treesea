#!/usr/bin/env python3
"""
Tree Diagram Engine (TDE) gate wrapper for water MD

This module wraps the high‑fidelity rigid water molecule simulation provided by
``tde_water_md_v1`` and adds three layers of functionality:

  1. **Fast/Slow gating (M1)** – A low‑cost surrogate is used to generate
     preliminary predictions and an uncertainty measure is computed by
     comparing multiple fast runs. If the uncertainty exceeds a user
     configurable threshold then a high‑fidelity (slow) simulation is
     executed. The final output reflects whichever path was taken and
     records the gating decision and confidence.

  2. **Multi‑resolution refinement (M2)** – After a coarse run, the grid
     cells with highest risk are identified. A refined simulation is then
     performed on a finer grid and the refined values corresponding to
     those high‑risk regions are extracted and returned alongside the
     coarse risk field. This allows front ends to visualize detailed
     structure only where it matters while keeping overall costs low.

  3. **Posterior estimation (M3)** – A very simple Bayesian posterior
     over the ``entropy`` (temperature scaling) parameter is returned
     based on the prior value used for the run. In a full system this
     would be produced by simulation‑based inference (SBI) but here we
     provide a stub implementation that returns a normal distribution
     centred on the current entropy with a fixed width.

The output from ``run_gated`` is a JSON‑serializable dictionary with
sections for the prediction, confidence, posterior and some metadata.

This module does **not** modify the underlying ``tde_water_md_v1`` kernel
and therefore does not violate the basic Tree Diagram formula
``DanmakuDynamics + COC + MPI + WCN``. All enhancements live strictly
around the core and can be disabled without changing the core results.

Usage example::

    python tde_water_gate.py --steps 200 --entropy 0.0 --threshold 0.2 \
      --roi-count 4 --refine-grid 64 --out out.json

"""

from __future__ import annotations

import argparse
import json
import math
import random
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional

# Import the high‑fidelity water simulation kernel
import importlib

# We import the module lazily so that tools checking for existence don't
# trigger the heavy load immediately. Users can also replace this import
# with a different kernel as long as it exposes SimConfig and simulate().
md = importlib.import_module("tde_water_md_v1")


@dataclass
class FastConfig:
    """Parameters for a fast surrogate simulation.

    ``steps`` and ``dt`` control the time horizon and resolution.
    ``grid`` controls the spatial grid resolution used to collect
    statistics. ``entropy``, ``temp_ramp`` and ``skin`` mirror the
    corresponding water MD parameters. ``replicates`` controls how many
    independent fast runs are performed to estimate uncertainty.
    """

    steps: int = 150
    dt: float = 0.02
    grid: int = 32
    entropy: float = 0.0
    temp_ramp: float = 0.0
    skin: float = 0.05
    replicates: int = 2


@dataclass
class SlowConfig:
    """Parameters for a high‑fidelity (slow) simulation.

    These parameters are passed directly into the underlying water MD
    kernel. They default to values similar to the v1 kernel but can be
    changed from the command line to increase fidelity. ``grid`` may be
    increased to produce more detailed risk fields at the cost of
    runtime.
    """

    steps: int = 200
    dt: float = 0.02
    grid: int = 32
    entropy: float = 0.0
    temp_ramp: float = 0.0
    skin: float = 0.05


@dataclass
class RunConfig:
    """Run configuration for gating and refinement.

    ``threshold``: uncertainty threshold in [0,1]. If the estimated
      confidence is below this value the system triggers a slow
      simulation.
    ``roi_count``: number of cells with highest risk to refine. 0 means
      no refinement.
    ``refine_grid``: the resolution of the fine grid used to compute
      refined risk fields. Must be > ``fast.grid`` and divisible by
      ``fast.grid`` for straightforward mapping.
    """

    threshold: float = 0.3
    roi_count: int = 4
    refine_grid: int = 64


def run_fast(cfg: FastConfig, seed: int) -> Dict:
    """Run a surrogate fast simulation using the underlying MD kernel.

    A ``FastConfig`` is translated into an ``md.SimConfig``. The
    simulation is executed and the results returned. We intentionally
    keep the interface flat to avoid coupling to internal details.
    """
    sim_cfg = md.SimConfig(
        steps=cfg.steps,
        dt=cfg.dt,
        grid=cfg.grid,
        entropy=cfg.entropy,
        temp_ramp=cfg.temp_ramp,
        skin=cfg.skin,
    )
    return md.simulate(sim_cfg, seed=seed)


def run_slow(cfg: SlowConfig, seed: int) -> Dict:
    """Run a high‑fidelity simulation using the underlying MD kernel."""
    sim_cfg = md.SimConfig(
        steps=cfg.steps,
        dt=cfg.dt,
        grid=cfg.grid,
        entropy=cfg.entropy,
        temp_ramp=cfg.temp_ramp,
        skin=cfg.skin,
    )
    return md.simulate(sim_cfg, seed=seed)


def risk_curve_discrepancy(res1: Dict, res2: Dict) -> Tuple[float, float]:
    """Compute discrepancies between two fast simulation outputs.

    Returns a tuple (risk_diff, curve_diff) where each term is the
    average absolute difference of the respective arrays. Values are
    scaled to fall into [0,1] by normalising by the maximum possible
    difference.
    """
    # Risk field difference: L1 norm / 2
    r1 = res1["riskfield"]
    r2 = res2["riskfield"]
    assert len(r1) == len(r2), "Risk fields must have same length"
    risk_diff = sum(abs(a - b) for a, b in zip(r1, r2)) / 2.0
    # Curves difference: L1 norm / steps
    c1 = res1["curve"]
    c2 = res2["curve"]
    min_len = min(len(c1), len(c2))
    curve_diff = sum(abs(c1[i] - c2[i]) for i in range(min_len)) / max(1, min_len)
    # Normalise by rough worst case: risk_diff max ~1, curve_diff max ~1
    risk_diff = min(1.0, risk_diff)
    curve_diff = min(1.0, curve_diff)
    return risk_diff, curve_diff


def estimate_confidence(res_list: List[Dict]) -> float:
    """Estimate a single scalar confidence from multiple fast runs.

    The variance and disagreement of the runs are used to derive a
    confidence measure in [0,1], where 1 means perfect agreement.
    """
    if len(res_list) < 2:
        return 1.0
    # Compute pairwise discrepancies and average them
    total_risk = 0.0
    total_curve = 0.0
    pairs = 0
    for i in range(len(res_list)):
        for j in range(i + 1, len(res_list)):
            dr, dc = risk_curve_discrepancy(res_list[i], res_list[j])
            total_risk += dr
            total_curve += dc
            pairs += 1
    if pairs == 0:
        return 1.0
    # Convert differences to confidence by 1 - average_difference
    avg_risk = total_risk / pairs
    avg_curve = total_curve / pairs
    # Weight risk and curve differences (risk heavier as it influences WCN)
    conf = 1.0 - (0.7 * avg_risk + 0.3 * avg_curve)
    return max(0.0, min(1.0, conf))


def pick_top_cells(riskfield: List[float], grid: int, count: int) -> List[int]:
    """Return indices of the ``count`` cells with the highest risk values."""
    if count <= 0:
        return []
    # Enumerate cell indices and risk values
    indices = list(range(len(riskfield)))
    # Sort by descending risk value
    sorted_cells = sorted(indices, key=lambda i: riskfield[i], reverse=True)
    return sorted_cells[:count]


def refine_riskfield(coarse: Dict, cfg_slow: SlowConfig, roi: List[int], fast_grid: int, refine_grid: int, seed: int) -> Optional[Dict]:
    """Compute refined riskfield values for each ROI cell.

    The function runs a slow simulation at ``refine_grid`` resolution. It then
    maps the refine grid back to the coarse grid and extracts the refine
    values for each coarse cell index in ``roi``. Returns a dict with
    metadata and a list of per‑ROI arrays.
    """
    if not roi or refine_grid <= fast_grid:
        return None
    # Run a slow simulation with finer grid
    refine_cfg = md.SimConfig(
        steps=cfg_slow.steps,
        dt=cfg_slow.dt,
        grid=refine_grid,
        entropy=cfg_slow.entropy,
        temp_ramp=cfg_slow.temp_ramp,
        skin=cfg_slow.skin,
    )
    res_ref = md.simulate(refine_cfg, seed=seed)
    risk_ref = res_ref["riskfield"]
    # Prepare mapping from coarse index to refine indices
    factor = refine_grid // fast_grid
    refine_data: Dict[int, List[float]] = {}
    for cell_idx in roi:
        # Determine coarse cell (gx, gy)
        gx = cell_idx % fast_grid
        gy = cell_idx // fast_grid
        # Compute refine cell region
        # refine cells span [gx*factor .. (gx+1)*factor-1] in x, same for y
        values: List[float] = []
        for ry in range(gy * factor, (gy + 1) * factor):
            for rx in range(gx * factor, (gx + 1) * factor):
                idx = ry * refine_grid + rx
                values.append(risk_ref[idx])
        refine_data[cell_idx] = values
    return {
        "grid": refine_grid,
        "roi": roi,
        "data": refine_data,
    }


def compute_posterior(entropy: float) -> Dict:
    """Return a simple Gaussian posterior over the entropy parameter.

    This stub function produces a normal distribution centred on the
    current entropy value with a fixed width. A real implementation
    would run simulation‑based inference to derive this from data.
    """
    mean = entropy
    # Fixed 95% CI width of ±0.5 around the mean
    ci_low = entropy - 0.5
    ci_high = entropy + 0.5
    # Draw a few samples for illustration
    rng = random.Random(42)
    samples = [rng.gauss(mean, 0.25) for _ in range(10)]
    return {
        "mean": {"entropy": mean},
        "ci95": {"entropy": [ci_low, ci_high]},
        "samples": samples,
    }


def run_gated(fast_cfg: FastConfig, slow_cfg: SlowConfig, run_cfg: RunConfig, seed: int = 123) -> Dict:
    """Execute a gated Tree Diagram run.

    1. Perform ``fast_cfg.replicates`` fast simulations.
    2. Compute confidence from the variability of the fast runs.
    3. If confidence < ``run_cfg.threshold``, run a slow simulation
       using ``slow_cfg`` to obtain high‑fidelity results.
    4. Identify top ``run_cfg.roi_count`` coarse cells by risk and
       perform refinement using ``run_cfg.refine_grid`` if requested.
    5. Compute a simple posterior over entropy.
    6. Assemble and return a result dict.

    The result dict contains keys: ``prediction``, ``confidence``,
    ``posterior`` and ``meta``. The ``prediction`` itself contains
    ``riskfield``, ``curve``, ``graph``, ``samples`` and optionally
    ``refine`` (for M2). ``confidence`` includes the confidence value
    and the gating reason. ``meta`` records whether the slow path was
    taken and some parameter settings.
    """
    # Run fast replicates
    fast_results = []
    rng = random.Random(seed)
    for i in range(fast_cfg.replicates):
        res_fast = run_fast(fast_cfg, seed=rng.randint(0, 10_000_000))
        fast_results.append(res_fast)
    # Compute confidence
    conf = estimate_confidence(fast_results)
    # Decide whether to run slow
    slow_taken = conf < run_cfg.threshold
    if slow_taken:
        res = run_slow(slow_cfg, seed=seed)
    else:
        # Use the first fast result as representative
        res = fast_results[0]
    # Multi‑resolution refinement (M2)
    refine_info = None
    if run_cfg.roi_count > 0:
        top_cells = pick_top_cells(res["riskfield"], fast_cfg.grid, run_cfg.roi_count)
        refine_info = refine_riskfield(
            res,
            slow_cfg,
            top_cells,
            fast_cfg.grid,
            run_cfg.refine_grid,
            seed=seed + 999
        )
    # Posterior estimation (M3)
    posterior = compute_posterior(slow_cfg.entropy)
    # Build output
    prediction = {
        "riskfield": res["riskfield"],
        "curve": res["curve"],
        "graph": res["graph"],
        "samples": res["samples"],
    }
    if refine_info is not None:
        prediction["refine"] = refine_info
    result = {
        "prediction": prediction,
        "confidence": {
            "value": conf,
            "threshold": run_cfg.threshold,
            "slow_taken": slow_taken,
        },
        "posterior": posterior,
        "meta": {
            "fast_cfg": {
                "steps": fast_cfg.steps,
                "dt": fast_cfg.dt,
                "grid": fast_cfg.grid,
                "entropy": fast_cfg.entropy,
                "temp_ramp": fast_cfg.temp_ramp,
                "replicates": fast_cfg.replicates,
            },
            "slow_cfg": {
                "steps": slow_cfg.steps,
                "dt": slow_cfg.dt,
                "grid": slow_cfg.grid,
                "entropy": slow_cfg.entropy,
                "temp_ramp": slow_cfg.temp_ramp,
            },
            "run_cfg": {
                "threshold": run_cfg.threshold,
                "roi_count": run_cfg.roi_count,
                "refine_grid": run_cfg.refine_grid,
            },
        },
    }
    return result


def main() -> None:
    ap = argparse.ArgumentParser(description="Run gated TDE water MD simulation")
    # Fast parameters
    ap.add_argument("--fast-steps", type=int, default=150, help="Fast sim steps")
    ap.add_argument("--fast-dt", type=float, default=0.02, help="Fast sim time step")
    ap.add_argument("--fast-grid", type=int, default=32, help="Fast sim grid size")
    ap.add_argument("--fast-entropy", type=float, default=0.0, help="Fast sim entropy knob")
    ap.add_argument("--fast-temp-ramp", type=float, default=0.0, help="Fast sim temperature ramp")
    ap.add_argument("--fast-replicates", type=int, default=2, help="Number of fast replicates for uncertainty")
    # Slow parameters
    ap.add_argument("--slow-steps", type=int, default=200, help="Slow sim steps")
    ap.add_argument("--slow-dt", type=float, default=0.02, help="Slow sim time step")
    ap.add_argument("--slow-grid", type=int, default=32, help="Slow sim grid size")
    ap.add_argument("--slow-entropy", type=float, default=0.0, help="Slow sim entropy knob")
    ap.add_argument("--slow-temp-ramp", type=float, default=0.0, help="Slow sim temperature ramp")
    # Gating parameters
    ap.add_argument("--threshold", type=float, default=0.3, help="Confidence threshold for slow simulation")
    ap.add_argument("--roi-count", type=int, default=4, help="Number of top risk cells to refine")
    ap.add_argument("--refine-grid", type=int, default=64, help="Grid size for refinement")
    # Other
    ap.add_argument("--seed", type=int, default=123, help="Random seed")
    ap.add_argument("--out", type=str, default="tde_water_gated_output.json", help="Output JSON filename")
    args = ap.parse_args()
    # Build configs
    fast_cfg = FastConfig(
        steps=args.fast_steps,
        dt=args.fast_dt,
        grid=args.fast_grid,
        entropy=args.fast_entropy,
        temp_ramp=args.fast_temp_ramp,
        skin=0.05,
        replicates=args.fast_replicates,
    )
    slow_cfg = SlowConfig(
        steps=args.slow_steps,
        dt=args.slow_dt,
        grid=args.slow_grid,
        entropy=args.slow_entropy,
        temp_ramp=args.slow_temp_ramp,
        skin=0.05,
    )
    run_cfg = RunConfig(
        threshold=args.threshold,
        roi_count=args.roi_count,
        refine_grid=args.refine_grid,
    )
    result = run_gated(fast_cfg, slow_cfg, run_cfg, seed=args.seed)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False)
    print(f"Wrote {args.out}")


if __name__ == "__main__":
    main()