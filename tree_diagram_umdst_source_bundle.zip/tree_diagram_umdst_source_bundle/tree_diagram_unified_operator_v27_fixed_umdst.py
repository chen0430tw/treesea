
"""
Tree Diagram Unified Operator v27_fixed + UMDST integration
-----------------------------------------------------------
Safe wrapper:
- preserves legacy v27 unified behavior for plan / meteorology
- adds UMDST backend v2 as an extra routed domain
- does NOT overwrite the original v27 / v27_fixed lineage
"""

from __future__ import annotations
from pathlib import Path
import importlib.util
import sys
import json

LEGACY_PATH = Path("/mnt/data/tree_diagram_unified_operator_v27.py")
UMDST_ADAPTER_PATH = Path("/mnt/data/tree_diagram_umdst_adapter_v3.py")


def load_module(path: Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load module from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


LEGACY = load_module(LEGACY_PATH, "tree_diagram_unified_operator_v27_legacy")
UMDST_ADAPTER = load_module(UMDST_ADAPTER_PATH, "tree_diagram_umdst_adapter_v3_for_v27")


DEFAULT_REQUEST = {
    "problem": {
        "title": "Tree Diagram Unified Operator v27_fixed with UMDST",
        "target": "Route standard unified tasks to legacy Tree Diagram, and molecular/gas/particle tasks to UMDST backend v2."
    }
}


def deep_merge(base, override):
    out = dict(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def route_mappings(req):
    text = (req["problem"]["title"] + " " + req["problem"]["target"]).lower()
    umdst_hit = any(k in text for k in [
        "umdst", "molecule", "molecular", "gas", "particle", "dsmc", "collision exchange"
    ])
    if umdst_hit:
        return {
            "plan": False,
            "meteorology": False,
            "umdst_backend": True,
            "coupled": False,
        }
    # fall back to legacy routing
    legacy = LEGACY.route_mappings(req)
    legacy["umdst_backend"] = False
    return legacy


def _wrap_legacy_result(req):
    legacy_oracle = LEGACY.run_unified(req)
    meta = dict(legacy_oracle.get("meta", {}))
    meta["engine"] = "tree_diagram_unified_operator_v27_fixed_umdst"
    meta["legacy_engine"] = meta.get("engine_legacy", "tree_diagram_unified_operator_v27")
    meta["umdst_available"] = True
    legacy_oracle["meta"] = meta
    return legacy_oracle


def _wrap_umdst_result():
    umdst_oracle = UMDST_ADAPTER.run_umdst_oracle()
    return {
        "meta": {
            "engine": "tree_diagram_unified_operator_v27_fixed_umdst",
            "structure": "legacy_v27_shell + umdst_backend_v2_route",
            "legacy_available": True,
            "umdst_available": True,
        },
        "routing": {
            "plan": False,
            "meteorology": False,
            "umdst_backend": True,
            "coupled": False,
        },
        "domains": umdst_oracle["domains"],
        "selection": umdst_oracle["selection"],
        "oracle_summary": umdst_oracle["oracle_summary"],
    }


def run_unified(req=None):
    if req is None:
        req = DEFAULT_REQUEST
    routing = route_mappings(req)
    if routing.get("umdst_backend", False):
        return _wrap_umdst_result()
    return _wrap_legacy_result(req)


def main():
    oracle = run_unified()
    outpath = Path("/mnt/data/tree_diagram_unified_operator_v27_fixed_umdst_result.json")
    outpath.write_text(json.dumps(oracle, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "routing": oracle["routing"],
        "selection": oracle["selection"],
        "oracle_summary": oracle["oracle_summary"],
        "domains_present": list(oracle["domains"].keys()),
    }, ensure_ascii=False, indent=2))
    print(f"saved: {outpath}")


if __name__ == "__main__":
    main()
