
# Tree Diagram Unified Operator Core v3
# One unified algorithm core with built-in grid computation layer.
#
# Key change from v2:
# - grid computation is now embedded as a core organ, not an external add-on
# - plan / meteorology are only different encoders/decoders over the same grid solver
# - one td_step / td_rollout / td_score / td_adjudicate path
#
# Usage:
#   python tree_diagram_unified_operator_v3.py
#   python tree_diagram_unified_operator_v3.py --input request.json
#
# Output:
#   ./tree_diagram_unified_out_v3/unified_oracle.json

from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Any, Tuple
import argparse
import itertools
import json
import math
import statistics
import numpy as np

# =========================================================
# 0. Unified request
# =========================================================

DEFAULT_REQUEST: Dict[str, Any] = {
    "problem": {
        "title": "Urban Resonance Upgrade Program",
        "target": "Find the most viable route to upgrade a city-scale resonance system from Level-5-equivalent stability to Level-6-equivalent stability.",
        "constraints": [
            "must remain under city-level safety threshold",
            "must avoid irreversible collapse of field stability",
            "must be scalable under limited infrastructure budget",
            "must remain reproducible across repeated trials",
        ],
        "time_horizon": "medium"
    },
    "subject": {
        "output_power": 0.93,
        "control_precision": 0.88,
        "load_tolerance": 0.61,
        "aim_coupling": 0.97,
        "stress_level": 0.22,
        "phase_proximity": 0.69,
        "marginal_decay": 0.11,
        "instability_sensitivity": 0.28,
    },
    "environment": {
        "budget": 0.62,
        "infrastructure": 0.71,
        "data_coverage": 0.66,
        "population_coupling": 0.83,
        "field_noise": 0.34,
        "social_pressure": 0.58,
        "regulatory_friction": 0.47,
        "network_density": 0.76,
        "phase_instability": 0.41,
        "weather_relevance": 0.70,
        "terrain_relevance": 0.62,
    },
    "candidates": {
        "mode": "auto_generate",
        "families_hint": ["batch", "network", "phase", "hybrid", "composite"],
    },
    "reward": {
        "components": {
            "feasibility": 1.15,
            "stability": 1.00,
            "field_fit": 0.95,
            "risk": -1.10,
            "spread_penalty": -0.25,
            "weather_h_err": -0.80 / 1.0e4,
            "weather_t_err": -1.20,
            "weather_q_err": -280.0,
            "weather_w_err": -0.020,
            "weather_instability": -0.030,
        },
        "nutrient": {
            "feasibility_threshold_gain": 1.00,
            "stability_threshold_gain": 0.88,
            "field_fit_threshold_gain": 0.84,
            "risk_penalty": -0.74,
            "oversize_penalty": -0.05,
        }
    },
    "runtime": {
        "plan_grid_shape": [8, 8],
        "weather_grid_shape": [112, 84],
        "weather_steps": 180,
        "weather_dt": 45.0,
        "grid_engine": "numpy_local"
    }
}

def deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out

def load_request(path: str | None) -> Dict[str, Any]:
    if path is None:
        return DEFAULT_REQUEST
    return deep_merge(DEFAULT_REQUEST, json.loads(Path(path).read_text(encoding="utf-8")))

# =========================================================
# 1. Shared utilities
# =========================================================

def weighted_score(components: Dict[str, float], weights: Dict[str, float]) -> float:
    return sum(weights.get(k, 0.0) * v for k, v in components.items())

def classify_relative(scores: List[float], idx: int) -> str:
    best = max(scores)
    worst = min(scores)
    span = max(1e-9, best - worst)
    rel = best - scores[idx]
    if rel <= max(0.20, 0.22 * span):
        return "active"
    if rel <= max(0.55, 0.45 * span):
        return "restricted"
    if rel <= max(1.20, 0.90 * span):
        return "starved"
    return "withered"

def histogram_of_status(rows: List[Dict[str, object]], key="branch_status") -> Dict[str, int]:
    return {
        "active": sum(r[key] == "active" for r in rows),
        "restricted": sum(r[key] == "restricted" for r in rows),
        "starved": sum(r[key] == "starved" for r in rows),
        "withered": sum(r[key] == "withered" for r in rows),
    }

def clip(a, lo, hi):
    return np.clip(a, lo, hi)

# =========================================================
# 2. Grid computation layer (embedded core organ)
# =========================================================

@dataclass
class GridSpec:
    shape: Tuple[int, int]
    dx: float = 1.0
    dy: float = 1.0
    dt: float = 1.0
    engine: str = "numpy_local"

@dataclass
class GridState:
    # unified field container
    fields: Dict[str, np.ndarray]
    meta: Dict[str, Any]

class GridComputeEngine:
    def lap(self, f: np.ndarray, spec: GridSpec) -> np.ndarray:
        return (
            (np.roll(f, -1, axis=0) - 2.0 * f + np.roll(f, 1, axis=0)) / (spec.dy ** 2)
            + (np.roll(f, -1, axis=1) - 2.0 * f + np.roll(f, 1, axis=1)) / (spec.dx ** 2)
        )

    def grad_x(self, f: np.ndarray, spec: GridSpec) -> np.ndarray:
        return (np.roll(f, -1, axis=1) - np.roll(f, 1, axis=1)) / (2.0 * spec.dx)

    def grad_y(self, f: np.ndarray, spec: GridSpec) -> np.ndarray:
        return (np.roll(f, -1, axis=0) - np.roll(f, 1, axis=0)) / (2.0 * spec.dy)

    def smooth(self, f: np.ndarray, alpha: float = 0.10) -> np.ndarray:
        return (1.0 - alpha) * f + alpha * (
            np.roll(f, 1, 0) + np.roll(f, -1, 0) + np.roll(f, 1, 1) + np.roll(f, -1, 1)
        ) / 4.0

    def bilinear_sample(self, field: np.ndarray, px: np.ndarray, py: np.ndarray) -> np.ndarray:
        px = np.clip(px, 0.0, field.shape[1] - 1.001)
        py = np.clip(py, 0.0, field.shape[0] - 1.001)
        x0 = np.floor(px).astype(int)
        y0 = np.floor(py).astype(int)
        x1 = np.clip(x0 + 1, 0, field.shape[1] - 1)
        y1 = np.clip(y0 + 1, 0, field.shape[0] - 1)
        wx = px - x0
        wy = py - y0
        f00 = field[y0, x0]
        f10 = field[y0, x1]
        f01 = field[y1, x0]
        f11 = field[y1, x1]
        return ((1.0 - wx) * (1.0 - wy) * f00 + wx * (1.0 - wy) * f10 + (1.0 - wx) * wy * f01 + wx * wy * f11)

    def semi_lagrangian(self, field: np.ndarray, u: np.ndarray, v: np.ndarray, spec: GridSpec) -> np.ndarray:
        jj, ii = np.meshgrid(np.arange(field.shape[0]), np.arange(field.shape[1]), indexing="ij")
        dep_x = ii - (u * spec.dt / spec.dx)
        dep_y = jj - (v * spec.dt / spec.dy)
        return self.bilinear_sample(field, dep_x, dep_y)

class GridAbstractionLayer:
    def __init__(self, spec: GridSpec):
        self.spec = spec
        self.engine = GridComputeEngine()

    def scheduler(self, candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        # placeholder scheduler; core layer is embedded even if local
        return candidates

    def aggregate(self, rows: List[Dict[str, Any]]) -> Dict[str, Any]:
        return {
            "count": len(rows),
            "mean_score": float(np.mean([r["score"] for r in rows])) if rows else 0.0,
            "score_span": float(max(r["score"] for r in rows) - min(r["score"] for r in rows)) if rows else 0.0,
        }

# =========================================================
# 3. Mapping router
# =========================================================

def route_mappings(req: Dict[str, Any]) -> Dict[str, bool]:
    env = req["environment"]
    problem_text = (req["problem"]["title"] + " " + req["problem"]["target"]).lower()
    weather_keywords = ["weather", "meteorology", "storm", "climate", "atmosphere", "city-scale", "urban", "environment"]
    keyword_hit = any(k in problem_text for k in weather_keywords)
    weather_signal = max(env.get("weather_relevance", 0.0), env.get("terrain_relevance", 0.0))
    needs_meteorology = keyword_hit or weather_signal >= 0.55 or env.get("field_noise", 0.0) >= 0.30
    return {"plan": True, "meteorology": needs_meteorology, "coupled": needs_meteorology}

# =========================================================
# 3.5 Shared physical constants for grid mappings
# =========================================================

BASE_H = 5400.0
G = 9.81
F0 = 8.0e-5
CP = 1004.0
LV = 2.5e6
DX = 12000.0
DY = 12000.0

# =========================================================
# 4. Candidate generation
# =========================================================

def family_lock(family: str, n: float) -> float:
    nc_map = {"batch":18000.0,"network":15000.0,"phase":17000.0,"electrical":16000.0,"ascetic":20000.0,"hybrid":18000.0,"composite":18500.0,
              "weak_mix":15000.0,"balanced":15000.0,"high_mix":15000.0,"humid_bias":15000.0,"strong_pg":15000.0,"terrain_lock":15000.0}
    sharp_map = {"batch":2200.0,"network":2000.0,"phase":2400.0,"electrical":2200.0,"ascetic":2600.0,"hybrid":2300.0,"composite":2500.0,
                 "weak_mix":2500.0,"balanced":2500.0,"high_mix":2500.0,"humid_bias":2500.0,"strong_pg":2500.0,"terrain_lock":2500.0}
    x = (n - nc_map[family]) / sharp_map[family]
    return 1.0 / (1.0 + math.exp(-x))

def generate_plan_candidates() -> List[Dict[str, Any]]:
    family_params = {
        "batch":      {"n": [12000, 18000, 20000, 24000], "rho": [0.5, 1.0], "A": [0.7, 0.9], "sigma": [0.01, 0.03]},
        "network":    {"n": [10000, 16000, 20000],       "rho": [0.8, 1.2], "A": [0.6, 0.8], "sigma": [0.02]},
        "phase":      {"n": [10000, 18000],              "rho": [0.5, 1.0], "A": [0.6, 0.75], "sigma": [0.04]},
        "electrical": {"n": [10000, 16000, 20000],       "rho": [0.6, 1.0], "A": [0.7],       "sigma": [0.05]},
        "ascetic":    {"n": [10000, 20000],              "rho": [0.2, 0.4], "A": [0.4, 0.55], "sigma": [0.03]},
        "hybrid":     {"n": [14000, 18000, 22000],       "rho": [0.7, 1.0], "A": [0.75],      "sigma": [0.08]},
        "composite":  {"n": [18000, 22000],              "rho": [0.8, 1.0], "A": [0.8],       "sigma": [0.04]},
    }
    out = []
    for fam, spec in family_params.items():
        for n, rho, A, sigma in itertools.product(spec["n"], spec["rho"], spec["A"], spec["sigma"]):
            out.append({"family": fam, "template": f"{fam}_route", "params": {"n": float(n), "rho": float(rho), "A": float(A), "sigma": float(sigma)}})
    return out

def generate_weather_candidates() -> List[Dict[str, Any]]:
    return [
        {"family": "weak_mix", "template": "weak_mix_route", "params": {"Kh":240.0,"Kt":120.0,"Kq":95.0,"drag":1.2e-5,"humid_couple":0.80,"nudging":0.00014,"pg_scale":1.00}},
        {"family": "balanced", "template": "balanced_route", "params": {"Kh":360.0,"Kt":180.0,"Kq":130.0,"drag":1.5e-5,"humid_couple":1.00,"nudging":0.00016,"pg_scale":1.00}},
        {"family": "high_mix", "template": "high_mix_route", "params": {"Kh":520.0,"Kt":260.0,"Kq":180.0,"drag":1.8e-5,"humid_couple":1.05,"nudging":0.00017,"pg_scale":1.00}},
        {"family": "humid_bias", "template": "humid_bias_route", "params": {"Kh":340.0,"Kt":175.0,"Kq":220.0,"drag":1.5e-5,"humid_couple":1.24,"nudging":0.00016,"pg_scale":1.00}},
        {"family": "strong_pg", "template": "strong_pg_route", "params": {"Kh":300.0,"Kt":150.0,"Kq":125.0,"drag":1.2e-5,"humid_couple":0.95,"nudging":0.00015,"pg_scale":1.18}},
        {"family": "terrain_lock", "template": "terrain_lock_route", "params": {"Kh":330.0,"Kt":170.0,"Kq":135.0,"drag":1.6e-5,"humid_couple":1.02,"nudging":0.00015,"pg_scale":1.04}},
    ]

# =========================================================
# 5. Encoders: map domain -> unified grid state
# =========================================================

def encode_plan_field(req: Dict[str, Any], spec: GridSpec, external_boost: Dict[str, float] | None = None) -> GridState:
    env = req["environment"]
    subj = req["subject"]
    h, w = spec.shape
    ones = np.ones((h, w), dtype=np.float64)

    field = {
        "field_coherence": ones * (0.42 * subj["aim_coupling"] + 0.18 * subj["control_precision"] + 0.12 * subj["phase_proximity"] + 0.18 * env["population_coupling"] + 0.06 * env["data_coverage"] - 0.14 * env["field_noise"] - 0.08 * env["phase_instability"]),
        "network_amplification": ones * (0.60 * env["network_density"] + 0.20 * env["infrastructure"] + 0.20 * env["data_coverage"]),
        "governance_drag": ones * (0.65 * env["regulatory_friction"] + 0.35 * env["social_pressure"]),
        "phase_turbulence": ones * (0.75 * env["phase_instability"] + 0.25 * env["field_noise"]),
        "resource_elasticity": ones * (0.60 * env["budget"] + 0.40 * env["infrastructure"]),
        "u": np.zeros((h, w)),
        "v": np.zeros((h, w)),
    }
    if external_boost:
        for k, v in external_boost.items():
            if k in field:
                field[k] = clip(field[k] + v, 0.0, 1.0)
    for k in ["field_coherence","network_amplification","governance_drag","phase_turbulence","resource_elasticity"]:
        field[k] = clip(field[k], 0.0, 1.0)
    return GridState(fields=field, meta={"domain": "plan"})

def encode_weather_field(req: Dict[str, Any], spec: GridSpec) -> GridState:
    h, w = spec.shape[1], spec.shape[0]  # request stores [112,84] as x,y-like; use arrays below
    x = np.linspace(-1.0, 1.0, w)
    y = np.linspace(-1.0, 1.0, h)
    XX, YY = np.meshgrid(x, y)

    topo = (
        1400.0 * np.exp(-7.0 * ((XX + 0.36) ** 2 + (YY - 0.06) ** 2)) +
         720.0 * np.exp(-10.5 * ((XX - 0.18) ** 2 + (YY + 0.24) ** 2)) +
         350.0 * np.exp(-14.0 * ((XX + 0.05) ** 2 + (YY + 0.28) ** 2))
    )
    H = BASE_H + 170.0 * np.exp(-7.0 * ((XX + 0.25) ** 2 + (YY + 0.02) ** 2)) - 105.0 * np.exp(-7.8 * ((XX - 0.25) ** 2 + (YY - 0.18) ** 2)) - 0.18 * topo
    T = 288.0 + 6.2 * np.exp(-7.5 * ((XX + 0.23) ** 2 + (YY + 0.04) ** 2)) - 4.3 * np.exp(-9.2 * ((XX - 0.29) ** 2 + (YY - 0.16) ** 2)) - 0.0032 * topo
    Q = 0.009 + 0.0085 * np.exp(-8.0 * ((XX - 0.08) ** 2 + (YY + 0.20) ** 2))
    U = 10.5 * np.sin(0.8 * np.pi * YY) * np.cos(0.7 * np.pi * XX)
    V = -7.2 * np.sin(0.7 * np.pi * XX) * np.cos(0.8 * np.pi * YY)

    return GridState(fields={
        "h": clip(H, BASE_H - 350.0, BASE_H + 350.0),
        "T": clip(T, 265.0, 315.0),
        "q": clip(Q, 1e-5, 0.025),
        "u": clip(U, -30.0, 30.0),
        "v": clip(V, -30.0, 30.0),
        "topography": topo,
    }, meta={"domain": "meteorology", "XX": XX, "YY": YY})

# =========================================================
# 6. Unified operator core
# =========================================================

def td_step(grid: GridState, candidate: Dict[str, Any], req: Dict[str, Any], gal: GridAbstractionLayer) -> GridState:
    spec = gal.spec
    eng = gal.engine
    domain = grid.meta["domain"]
    fields = {k: np.array(v, copy=True) for k, v in grid.fields.items()}
    p = candidate["params"]

    if domain == "plan":
        # same operator path, but different bound variables
        # route parameters act as field injections on abstract grid organs
        n = p["n"]
        rho = p["rho"]
        A = p["A"]
        sigma = p["sigma"]
        fam = candidate["family"]
        lock = family_lock(fam, n)

        fields["field_coherence"] = clip(eng.smooth(fields["field_coherence"] + 0.015 * A + 0.010 * lock - 0.012 * sigma), 0.0, 1.0)
        fields["network_amplification"] = clip(eng.smooth(fields["network_amplification"] + 0.012 * rho + (0.020 if fam == "network" else 0.0)), 0.0, 1.0)
        fields["phase_turbulence"] = clip(eng.smooth(fields["phase_turbulence"] + 0.010 * sigma - (0.020 if fam == "phase" else 0.0)), 0.0, 1.0)
        fields["resource_elasticity"] = clip(eng.smooth(fields["resource_elasticity"] - 0.010 * max(0.0, (n - 20000.0) / 10000.0)), 0.0, 1.0)
        fields["governance_drag"] = clip(eng.smooth(fields["governance_drag"]), 0.0, 1.0)

    elif domain == "meteorology":
        h = fields["h"]; T = fields["T"]; q = fields["q"]; u = fields["u"]; v = fields["v"]; topo = fields["topography"]

        def saturation_specific_humidity(T):
            return 0.0045 * np.exp(0.060 * (T - 273.15) / 10.0)

        h_adv = eng.semi_lagrangian(h, u, v, spec)
        T_adv = eng.semi_lagrangian(T, u, v, spec)
        q_adv = eng.semi_lagrangian(q, u, v, spec)
        u_adv = eng.semi_lagrangian(u, u, v, spec)
        v_adv = eng.semi_lagrangian(v, u, v, spec)

        geop = G * (h_adv + 0.18 * topo)
        pgx = p["pg_scale"] * eng.grad_x(geop, spec)
        pgy = p["pg_scale"] * eng.grad_y(geop, spec)
        topo_drag = 1.0 + 0.00035 * topo

        u_new = u_adv - spec.dt * pgx + spec.dt * F0 * v_adv - spec.dt * p["drag"] * topo_drag * u_adv + spec.dt * p["Kh"] * eng.lap(u_adv, spec)
        v_new = v_adv - spec.dt * pgy - spec.dt * F0 * u_adv - spec.dt * p["drag"] * topo_drag * v_adv + spec.dt * p["Kh"] * eng.lap(v_adv, spec)
        div = eng.grad_x(u_adv, spec) + eng.grad_y(v_adv, spec)
        h_new = h_adv - spec.dt * 0.55 * h_adv / BASE_H * div + spec.dt * p["Kh"] * 0.35 * eng.lap(h_adv, spec)

        qsat = saturation_specific_humidity(T_adv)
        excess = np.maximum(q_adv - qsat, 0.0)
        cond = 0.20 * excess * p["humid_couple"]
        latent = (LV / CP) * cond * 1.0e-4
        T_eq = 286.5 - 0.0032 * topo
        T_new = T_adv + spec.dt * p["Kt"] * eng.lap(T_adv, spec) + spec.dt * latent - spec.dt * 1.4e-5 * (T_adv - T_eq)
        q_source = 2.0e-6 * np.exp(-6.0 * (grid.meta["XX"] ** 2 + grid.meta["YY"] ** 2))
        q_new = q_adv + spec.dt * p["Kq"] * eng.lap(q_adv, spec) + spec.dt * q_source - spec.dt * cond

        # observation shell generated from same field family
        XX = grid.meta["XX"]; YY = grid.meta["YY"]
        H_obs = BASE_H + 200.0 * np.exp(-6.8 * ((XX + 0.18) ** 2 + (YY + 0.10) ** 2)) - 150.0 * np.exp(-8.0 * ((XX - 0.28) ** 2 + (YY - 0.14) ** 2)) - 0.23 * topo
        T_obs = 289.0 + 7.5 * np.exp(-8.2 * ((XX + 0.16) ** 2 + (YY + 0.11) ** 2)) - 5.8 * np.exp(-8.8 * ((XX - 0.24) ** 2 + (YY - 0.17) ** 2)) - 0.0038 * topo + 0.8 * np.sin(1.2 * np.pi * XX) * np.cos(0.8 * np.pi * YY)
        Q_obs = 0.010 + 0.011 * np.exp(-7.6 * ((XX - 0.10) ** 2 + (YY + 0.21) ** 2)) + 0.0016 * np.sin(np.pi * YY)
        U_obs = 12.0 * np.sin(0.9 * np.pi * YY) * np.cos(0.8 * np.pi * XX)
        V_obs = -8.5 * np.sin(0.8 * np.pi * XX) * np.cos(0.9 * np.pi * YY)

        nud = p["nudging"]
        h_new += spec.dt * nud * (H_obs - h_new)
        T_new += spec.dt * nud * (T_obs - T_new)
        q_new += spec.dt * nud * (Q_obs - q_new)
        u_new += spec.dt * nud * (U_obs - u_new)
        v_new += spec.dt * nud * (V_obs - v_new)

        fields["h"] = clip(eng.smooth(h_new, 0.06), BASE_H - 500.0, BASE_H + 500.0)
        fields["T"] = clip(eng.smooth(T_new, 0.05), 250.0, 320.0)
        fields["q"] = clip(eng.smooth(q_new, 0.05), 1e-5, 0.030)
        fields["u"] = clip(eng.smooth(u_new, 0.04), -40.0, 40.0)
        fields["v"] = clip(eng.smooth(v_new, 0.04), -40.0, 40.0)

    return GridState(fields=fields, meta=dict(grid.meta))

def td_rollout(initial: GridState, candidate: Dict[str, Any], req: Dict[str, Any], gal: GridAbstractionLayer) -> GridState:
    domain = initial.meta["domain"]
    state = GridState(fields={k: np.array(v, copy=True) for k, v in initial.fields.items()}, meta=dict(initial.meta))
    steps = 1 if domain == "plan" else int(req["runtime"]["weather_steps"])
    for _ in range(steps):
        state = td_step(state, candidate, req, gal)
    return state

def td_score(final_state: GridState, candidate: Dict[str, Any], req: Dict[str, Any]) -> Dict[str, float]:
    domain = final_state.meta["domain"]
    reward = req["reward"]["components"]
    fields = final_state.fields

    if domain == "plan":
        subj = req["subject"]
        fam = candidate["family"]
        p = candidate["params"]
        fc = float(np.mean(fields["field_coherence"]))
        na = float(np.mean(fields["network_amplification"]))
        gd = float(np.mean(fields["governance_drag"]))
        pt = float(np.mean(fields["phase_turbulence"]))
        re = float(np.mean(fields["resource_elasticity"]))
        lock = family_lock(fam, p["n"])

        family_bias = {
            "batch":{"yield":0.16,"stability":0.08,"risk":0.02},
            "network":{"yield":0.12,"stability":0.11,"risk":-0.01},
            "phase":{"yield":0.09,"stability":0.12,"risk":-0.02},
            "electrical":{"yield":0.11,"stability":0.04,"risk":0.08},
            "ascetic":{"yield":0.05,"stability":0.13,"risk":-0.03},
            "hybrid":{"yield":0.13,"stability":0.06,"risk":0.04},
            "composite":{"yield":0.14,"stability":0.09,"risk":0.03},
        }[fam]

        feasibility = 0.25*subj["output_power"] + 0.18*subj["aim_coupling"] + 0.12*re + 0.18*p["A"] + 0.15*lock + family_bias["yield"] - 0.08*p["sigma"]
        feasibility = max(0.0, min(1.2, feasibility))
        stability = 0.28*subj["control_precision"] + 0.18*subj["load_tolerance"] + 0.20*fc + 0.15*(1.0-pt) + 0.12*(1.0-p["sigma"]) + family_bias["stability"]
        stability = max(0.0, min(1.2, stability))
        field_fit = 0.32*na*(1.2 if fam=="network" else 1.0) + 0.22*fc + 0.18*subj["phase_proximity"] + 0.10*p["rho"] + 0.08*lock - 0.10*gd
        field_fit = max(0.0, min(1.2, field_fit))
        risk = 0.18*pt + 0.14*gd + 0.12*subj["instability_sensitivity"] + 0.10*subj["stress_level"] + 0.08*p["sigma"] + 0.05*max(0.0, (p["n"]-20000.0)/10000.0) + family_bias["risk"]
        risk = max(0.0, min(1.2, risk))
        spread = statistics.pstdev([feasibility, stability, field_fit])

        score = weighted_score(
            {
                "feasibility": feasibility,
                "stability": stability,
                "field_fit": field_fit,
                "risk": risk,
                "spread_penalty": spread,
            },
            reward,
        )

        nutrient_cfg = req["reward"]["nutrient"]
        route_bonus = 0.0
        if fam == "network":
            route_bonus += 0.14 * na + 0.06 * fc
        if fam == "phase":
            route_bonus += 0.07 * (1.0 - pt)
        if fam == "batch" and abs(p["n"] - 20000.0) <= 1e-6:
            route_bonus += 0.05
        if abs(p["n"] - 20000.0) <= 1e-6:
            route_bonus += 0.06

        nutrient = (
            nutrient_cfg["feasibility_threshold_gain"] * max(0.0, feasibility - 0.82) +
            nutrient_cfg["stability_threshold_gain"] * max(0.0, stability - 0.80) +
            nutrient_cfg["field_fit_threshold_gain"] * max(0.0, field_fit - 0.68) +
            route_bonus +
            nutrient_cfg["risk_penalty"] * risk +
            nutrient_cfg["oversize_penalty"] * max(0.0, (p["n"] - 20000.0) / 5000.0)
        )
        return {
            "score": float(score),
            "feasibility": round(feasibility, 6),
            "stability": round(stability, 6),
            "field_fit": round(field_fit, 6),
            "risk": round(risk, 6),
            "nutrient_gain": round(nutrient, 6),
        }

    # meteorology domain
    h = fields["h"]; T = fields["T"]; q = fields["q"]; u = fields["u"]; v = fields["v"]; topo = fields["topography"]
    XX = final_state.meta["XX"]; YY = final_state.meta["YY"]
    H_obs = BASE_H + 200.0 * np.exp(-6.8 * ((XX + 0.18) ** 2 + (YY + 0.10) ** 2)) - 150.0 * np.exp(-8.0 * ((XX - 0.28) ** 2 + (YY - 0.14) ** 2)) - 0.23 * topo
    T_obs = 289.0 + 7.5 * np.exp(-8.2 * ((XX + 0.16) ** 2 + (YY + 0.11) ** 2)) - 5.8 * np.exp(-8.8 * ((XX - 0.24) ** 2 + (YY - 0.17) ** 2)) - 0.0038 * topo + 0.8 * np.sin(1.2 * np.pi * XX) * np.cos(0.8 * np.pi * YY)
    Q_obs = 0.010 + 0.011 * np.exp(-7.6 * ((XX - 0.10) ** 2 + (YY + 0.21) ** 2)) + 0.0016 * np.sin(np.pi * YY)
    U_obs = 12.0 * np.sin(0.9 * np.pi * YY) * np.cos(0.8 * np.pi * XX)
    V_obs = -8.5 * np.sin(0.8 * np.pi * XX) * np.cos(0.9 * np.pi * YY)

    h_err = float(np.mean((h - H_obs) ** 2))
    t_err = float(np.mean((T - T_obs) ** 2))
    q_err = float(np.mean((q - Q_obs) ** 2))
    w_err = float(np.mean((u - U_obs) ** 2 + (v - V_obs) ** 2))
    eng = GridComputeEngine()
    spec = GridSpec(shape=(h.shape[1], h.shape[0]), dx=DX, dy=DY, dt=DEFAULT_REQUEST["runtime"]["weather_dt"])
    instability = float(
        np.mean(np.abs(eng.lap(T, spec))) +
        0.8 * np.mean(np.abs(eng.lap(q, spec))) +
        0.5 * np.mean(np.abs(eng.lap(u, spec))) +
        0.5 * np.mean(np.abs(eng.lap(v, spec))) +
        0.35 * np.mean(np.abs(eng.lap(h, spec)))
    )
    score = weighted_score(
        {
            "weather_h_err": h_err,
            "weather_t_err": t_err,
            "weather_q_err": q_err,
            "weather_w_err": w_err,
            "weather_instability": instability,
        },
        reward,
    )
    return {
        "score": float(score),
        "h_err": h_err,
        "t_err": t_err,
        "q_err": q_err,
        "w_err": w_err,
        "instability": instability,
    }

def td_adjudicate(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows = sorted(rows, key=lambda x: x["score"], reverse=True)
    scores = [r["score"] for r in rows]
    for i, row in enumerate(rows):
        row["branch_status"] = classify_relative(scores, i)
    return rows

def td_hydro_control(rows: List[Dict[str, Any]]) -> Dict[str, float]:
    ranked = sorted(rows, key=lambda x: x["score"], reverse=True)
    margin = ranked[0]["score"] - ranked[1]["score"] if len(ranked) > 1 else 0.0
    spread = ranked[0]["score"] - ranked[-1]["score"] if len(ranked) > 1 else 0.0
    pressure_balance = 1.0
    if margin < 0.08:
        pressure_balance += 0.04
    if spread > 1.4:
        pressure_balance -= 0.03
    pressure_balance = float(np.clip(pressure_balance, 0.94, 1.08))
    return {
        "pressure_balance": pressure_balance,
        "top_margin": float(margin),
        "score_spread": float(spread),
        "mean_score": float(np.mean([m["score"] for m in rows])) if rows else 0.0,
    }

# =========================================================
# 7. Domain runners via same operator
# =========================================================

def run_plan(req: Dict[str, Any], external_boost: Dict[str, float] | None = None) -> Dict[str, Any]:
    shape = tuple(req["runtime"]["plan_grid_shape"])
    spec = GridSpec(shape=shape, dx=1.0, dy=1.0, dt=1.0, engine=req["runtime"]["grid_engine"])
    gal = GridAbstractionLayer(spec)
    initial = encode_plan_field(req, spec, external_boost)
    candidates = gal.scheduler(generate_plan_candidates())

    rows = []
    for c in candidates:
        final_state = td_rollout(initial, c, req, gal)
        metrics = td_score(final_state, c, req)
        rows.append({
            "family": c["family"],
            "template": c["template"],
            "params": c["params"],
            **metrics
        })
    rows = td_adjudicate(rows)
    hydro = td_hydro_control(rows[:12])
    best = rows[0]
    return {
        "mapping": "plan",
        "best_worldline": best,
        "main_worldline_alive": best["branch_status"] in ("active", "restricted"),
        "main_worldline_active": best["branch_status"] == "active",
        "hydro_control_state": hydro,
        "branch_histogram": histogram_of_status(rows[:12]),
        "top_worldlines": rows[:5],
        "grid_summary": gal.aggregate(rows),
    }

def run_meteorology(req: Dict[str, Any]) -> Dict[str, Any]:
    # request stores [x, y]; convert to array shape (y, x)
    xw, yh = req["runtime"]["weather_grid_shape"]
    spec = GridSpec(shape=(xw, yh), dx=12000.0, dy=12000.0, dt=float(req["runtime"]["weather_dt"]), engine=req["runtime"]["grid_engine"])
    gal = GridAbstractionLayer(spec)
    initial = encode_weather_field(req, spec)
    candidates = gal.scheduler(generate_weather_candidates())

    # pass 1
    rows = []
    for c in candidates:
        final_state = td_rollout(initial, c, req, gal)
        metrics = td_score(final_state, c, req)
        rows.append({"family": c["family"], "template": c["template"], "params": c["params"], **metrics})
    rows = td_adjudicate(rows)
    hydro = td_hydro_control(rows)

    # pass 2 with hydro pressure_balance affecting pg_scale
    rows2 = []
    for c in candidates:
        c2 = {"family": c["family"], "template": c["template"], "params": dict(c["params"])}
        c2["params"]["pg_scale"] = c2["params"]["pg_scale"] * hydro["pressure_balance"]
        final_state = td_rollout(initial, c2, req, gal)
        metrics = td_score(final_state, c2, req)
        rows2.append({"family": c2["family"], "template": c2["template"], "params": c2["params"], **metrics})
    rows2 = td_adjudicate(rows2)
    best = rows2[0]

    return {
        "mapping": "meteorology",
        "best_worldline": best["family"],
        "best_status": best["branch_status"],
        "hydro_control": hydro,
        "branch_histogram": histogram_of_status(rows2),
        "ranking": rows2,
        "grid_summary": gal.aggregate(rows2),
    }

def weather_to_plan_boost(weather_oracle: Dict[str, Any]) -> Dict[str, float]:
    hist = weather_oracle["branch_histogram"]
    total = max(1, sum(hist.values()))
    active_ratio = hist["active"] / total
    restricted_ratio = hist["restricted"] / total
    score_spread = weather_oracle["hydro_control"].get("score_spread", 0.0)
    best_branch = weather_oracle["best_worldline"]
    return {
        "field_coherence": 0.06 * active_ratio - 0.02 * restricted_ratio,
        "network_amplification": 0.04 if best_branch in ("high_mix", "balanced", "humid_bias") else -0.03,
        "phase_turbulence": -0.04 * active_ratio + 0.03 * (best_branch == "strong_pg"),
        "resource_elasticity": 0.02 if score_spread < 1.0 else -0.01,
    }

# =========================================================
# 8. Unified orchestration
# =========================================================

def run_unified(req: Dict[str, Any]) -> Dict[str, Any]:
    routing = route_mappings(req)
    if routing["coupled"]:
        weather = run_meteorology(req)
        boost = weather_to_plan_boost(weather)
        plan = run_plan(req, boost)
        return {
            "mapping_mode": "auto_coupled",
            "routing": routing,
            "meteorology_shell": weather,
            "plan_kernel": plan,
            "best_worldline": plan["best_worldline"],
            "oracle_summary": {
                "dominant_mapping": "coupled",
                "main_worldline_alive": plan["main_worldline_alive"],
                "main_worldline_active": plan["main_worldline_active"],
            }
        }
    if routing["meteorology"]:
        weather = run_meteorology(req)
        return {
            "mapping_mode": "auto_meteorology",
            "routing": routing,
            "meteorology_shell": weather,
            "best_worldline": {
                "family": weather["best_worldline"],
                "branch_status": weather["best_status"],
            },
            "oracle_summary": {
                "dominant_mapping": "meteorology",
                "main_worldline_active": weather["best_status"] == "active",
            }
        }
    plan = run_plan(req)
    return {
        "mapping_mode": "auto_plan",
        "routing": routing,
        "plan_kernel": plan,
        "best_worldline": plan["best_worldline"],
        "oracle_summary": {
            "dominant_mapping": "plan",
            "main_worldline_alive": plan["main_worldline_alive"],
            "main_worldline_active": plan["main_worldline_active"],
        }
    }

# =========================================================
# 9. Main
# =========================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default=None)
    parser.add_argument("--outdir", default="./tree_diagram_unified_out_v3")
    args = parser.parse_args()

    req = load_request(args.input)
    oracle = run_unified(req)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    outpath = outdir / "unified_oracle.json"
    outpath.write_text(json.dumps(oracle, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(oracle, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
