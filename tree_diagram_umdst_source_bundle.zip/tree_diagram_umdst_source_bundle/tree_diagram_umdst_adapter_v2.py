
"""
Tree Diagram <-> UMDST Adapter v1
---------------------------------
This file makes Tree Diagram call the UMDST backend instead of pretending
to be the molecular dynamics engine itself.

Flow:
- build candidate worldlines
- for each worldline, build a UMDST config
- call umdst_backend_v1.run_umdst_backend(config)
- collect observables
- score / rank / prune worldlines
- export a unified oracle manifest
"""

from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Any, List
import importlib.util
import sys
import json
import math
import numpy as np


BACKEND_PATH = Path("/mnt/data/umdst_backend_v1.py")


def load_umdst_backend():
    spec = importlib.util.spec_from_file_location("umdst_backend_v1", BACKEND_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load backend from {BACKEND_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules["umdst_backend_v1"] = module
    spec.loader.exec_module(module)
    return module


UMDST = load_umdst_backend()


DEFAULT_REQUEST = {
    "problem": {
        "title": "Tree Diagram UMDST Coupled Oracle",
        "target": "Rank UMDST molecular worldlines for atmospheric-microdynamics style evolution.",
    },
    "reward": {
        "components": {
            "temp_err": -2.0,
            "pressure_err": -1.5,
            "energy_drift": -2.8,
            "density_var": -0.9,
            "temp_var": -0.7,
            "velocity_rms": -0.4,
        }
    },
    "runtime": {
        "seed": 430
    }
}


def deep_merge(base, override):
    out = dict(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def classify_relative(scores, idx):
    best = max(scores)
    worst = min(scores)
    span = max(1e-9, best - worst)
    rel = best - scores[idx]
    if rel <= max(0.20, 0.22 * span):
        return "active"
    if rel <= max(0.55, 0.45 * span):
        return "restricted"
    if rel <= max(1.20, 0.90 * span):
        return "starved"
    return "withered"


def histogram_of_status(rows, key="branch_status"):
    return {s: sum(r[key] == s for r in rows) for s in ["active", "restricted", "starved", "withered"]}


def td_hydro_control(rows):
    ranked = sorted(rows, key=lambda x: x["score"], reverse=True)
    margin = ranked[0]["score"] - ranked[1]["score"] if len(ranked) > 1 else 0.0
    spread = ranked[0]["score"] - ranked[-1]["score"] if len(ranked) > 1 else 0.0
    pressure_balance = 1.0 + (0.04 if margin < 0.08 else 0.0) - (0.03 if spread > 1.4 else 0.0)
    pressure_balance = float(np.clip(pressure_balance, 0.94, 1.08))
    return {
        "pressure_balance": pressure_balance,
        "top_margin": float(margin),
        "score_spread": float(spread),
        "mean_score": float(np.mean([m["score"] for m in rows])) if rows else 0.0,
    }


def default_worldlines() -> List[Dict[str, Any]]:
    return [
        {
            "family": "balanced_air",
            "template": "umdst_balanced_air",
            "target_temperature": 1.00,
            "dt": 0.0025,
            "steps": 400,
            "box_size": 14.0,
            "thermostat_tau": 0.08,
            "species": [
                {"name": "N2", "mass": 28.0, "epsilon": 1.00, "sigma": 1.00, "count": 48},
                {"name": "O2", "mass": 32.0, "epsilon": 0.95, "sigma": 0.98, "count": 28},
                {"name": "H2O", "mass": 18.0, "epsilon": 1.18, "sigma": 0.92, "count": 20},
            ],
        },
        {
            "family": "humid_dense",
            "template": "umdst_humid_dense",
            "target_temperature": 0.92,
            "dt": 0.0023,
            "steps": 420,
            "box_size": 13.5,
            "thermostat_tau": 0.07,
            "species": [
                {"name": "N2", "mass": 28.0, "epsilon": 1.00, "sigma": 1.00, "count": 42},
                {"name": "O2", "mass": 32.0, "epsilon": 0.95, "sigma": 0.98, "count": 24},
                {"name": "H2O", "mass": 18.0, "epsilon": 1.25, "sigma": 0.91, "count": 34},
            ],
        },
        {
            "family": "dry_hot",
            "template": "umdst_dry_hot",
            "target_temperature": 1.18,
            "dt": 0.0028,
            "steps": 380,
            "box_size": 14.8,
            "thermostat_tau": 0.09,
            "species": [
                {"name": "N2", "mass": 28.0, "epsilon": 0.96, "sigma": 1.00, "count": 54},
                {"name": "O2", "mass": 32.0, "epsilon": 0.92, "sigma": 0.98, "count": 30},
                {"name": "H2O", "mass": 18.0, "epsilon": 1.08, "sigma": 0.92, "count": 12},
            ],
        },
        {
            "family": "sticky_condense",
            "template": "umdst_sticky_condense",
            "target_temperature": 0.86,
            "dt": 0.0022,
            "steps": 430,
            "box_size": 13.2,
            "thermostat_tau": 0.06,
            "species": [
                {"name": "N2", "mass": 28.0, "epsilon": 1.02, "sigma": 1.00, "count": 40},
                {"name": "O2", "mass": 32.0, "epsilon": 1.00, "sigma": 0.98, "count": 22},
                {"name": "H2O", "mass": 18.0, "epsilon": 1.35, "sigma": 0.90, "count": 38},
            ],
        },
        {
            "family": "soft_gas",
            "template": "umdst_soft_gas",
            "target_temperature": 1.26,
            "dt": 0.0030,
            "steps": 360,
            "box_size": 15.2,
            "thermostat_tau": 0.11,
            "species": [
                {"name": "N2", "mass": 28.0, "epsilon": 0.88, "sigma": 1.02, "count": 50},
                {"name": "O2", "mass": 32.0, "epsilon": 0.86, "sigma": 1.00, "count": 28},
                {"name": "H2O", "mass": 18.0, "epsilon": 0.98, "sigma": 0.94, "count": 18},
            ],
        },
    ]


def build_backend_config(worldline: Dict[str, Any], seed: int) -> Dict[str, Any]:
    box_size = float(worldline["box_size"])
    return {
        "species": worldline["species"],
        "dt": float(worldline["dt"]),
        "steps": int(worldline["steps"]),
        "box_size": box_size,
        "rcut": 2.5,
        "thermostat_tau": float(worldline["thermostat_tau"]),
        "target_temperature": float(worldline["target_temperature"]),
        "seed": int(seed),
        "coarse_grid": {
            "nx": 10,
            "ny": 10,
            "nz": 6,
            "box_size": box_size,
        },
    }


def score_worldline(result: Dict[str, Any], worldline: Dict[str, Any], req: Dict[str, Any]) -> Dict[str, float]:
    weights = req["reward"]["components"]
    summary = result["summary"]
    coarse = result["coarse_fields"]
    target_T = float(worldline["target_temperature"])
    target_P = 0.55 * target_T

    metrics = {
        "temp_err": (summary["final_temperature"] - target_T) ** 2,
        "pressure_err": (summary["final_pressure"] - target_P) ** 2,
        "energy_drift": float(summary["energy_drift"]),
        "density_var": float(coarse["mass_density_var"]),
        "temp_var": float(coarse["temperature_var"]),
        "velocity_rms": float(coarse["velocity_rms"]),
    }

    score = 0.0
    for k, v in metrics.items():
        score += weights[k] * v
    metrics["score"] = score
    return metrics


def run_umdst_oracle(req: Dict[str, Any]) -> Dict[str, Any]:
    seed0 = int(req["runtime"].get("seed", 430))
    rows = []

    for i, worldline in enumerate(default_worldlines()):
        backend_cfg = build_backend_config(worldline, seed0 + i)
        backend_result = UMDST.run_umdst_backend(backend_cfg)
        scored = score_worldline(backend_result, worldline, req)

        row = {
            "family": worldline["family"],
            "template": worldline["template"],
            "params": {
                "target_temperature": worldline["target_temperature"],
                "dt": worldline["dt"],
                "steps": worldline["steps"],
                "box_size": worldline["box_size"],
                "thermostat_tau": worldline["thermostat_tau"],
                "composition": {s["name"]: s["count"] for s in worldline["species"]},
            },
            "backend_summary": backend_result["summary"],
            **scored,
        }
        rows.append(row)

    rows = sorted(rows, key=lambda x: x["score"], reverse=True)
    scores = [r["score"] for r in rows]
    for i, row in enumerate(rows):
        row["branch_status"] = classify_relative(scores, i)

    hydro = td_hydro_control(rows)
    best = rows[0]

    return {
        "meta": {
            "engine": "tree_diagram_umdst_adapter_v1",
            "backend": "umdst_backend_v1",
            "structure": "tree_diagram_orchestration -> umdst_backend.run(config) -> observables -> ranking",
        },
        "routing": {
            "plan": False,
            "meteorology": False,
            "umdst_backend": True,
            "coupled": False,
        },
        "domains": {
            "umdst_backend": {
                "name": "umdst_backend",
                "mode": "ranking",
                "best": {
                    "branch": best["family"],
                    "status": best["branch_status"],
                    "score": best["score"],
                    "template": best["template"],
                    "params": best["params"],
                },
                "status_histogram": histogram_of_status(rows),
                "hydro_control": hydro,
                "row_count": len(rows),
                "rows": rows,
            }
        },
        "selection": {
            "dominant_mapping": "umdst_backend",
            "best_domain": "umdst_backend",
            "best_branch": best["family"],
        },
        "oracle_summary": {
            "main_worldline_alive": best["branch_status"] in ("active", "restricted"),
            "main_worldline_active": best["branch_status"] == "active",
        },
    }


def main():
    req = DEFAULT_REQUEST
    oracle = run_umdst_oracle(req)
    outpath = Path("/mnt/data/tree_diagram_umdst_adapter_result.json")
    outpath.write_text(json.dumps(oracle, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "best_branch": oracle["selection"]["best_branch"],
        "oracle_summary": oracle["oracle_summary"],
        "status_histogram": oracle["domains"]["umdst_backend"]["status_histogram"],
    }, ensure_ascii=False, indent=2))
    print(f"saved: {outpath}")


if __name__ == "__main__":
    main()
