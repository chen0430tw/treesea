
# Tree Diagram Weather v2 - Mesoscopic Molecular Motion Version
# Colab-ready single file
# This is not exact all-molecule atmospheric simulation.
# It uses super-particles / mesoscopic kinetic packets to approximate molecular transport,
# then runs Tree-Diagram-style multi-worldline scoring + H-UTM-like tuning.

from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
from dataclasses import dataclass, asdict
import json

# =========================================================
# 0. Config
# =========================================================

NX, NY = 56, 56
DT = 0.06
STEPS = 90
PARTICLES = 2200
SEED = 430
RNG = np.random.default_rng(SEED)

X = np.linspace(-1, 1, NX)
Y = np.linspace(-1, 1, NY)
XX, YY = np.meshgrid(X, Y)

# =========================================================
# 1. Pseudo observation fields
# =========================================================

def make_observation():
    T_obs = (
        300
        + 8.0 * np.exp(-7.5 * ((XX + 0.22) ** 2 + (YY + 0.10) ** 2))
        - 3.6 * np.exp(-10.5 * ((XX - 0.32) ** 2 + (YY - 0.18) ** 2))
        + 1.2 * np.sin(1.5 * np.pi * XX) * np.cos(1.0 * np.pi * YY)
    )
    q_obs = (
        0.42
        + 0.17 * np.exp(-8.5 * ((XX - 0.10) ** 2 + (YY + 0.26) ** 2))
        + 0.03 * np.sin(np.pi * YY)
    )
    u_obs = 0.22 * np.sin(np.pi * YY) * np.cos(1.2 * np.pi * XX)
    v_obs = -0.18 * np.sin(1.1 * np.pi * XX) * np.cos(np.pi * YY)
    rho_obs = 1.18 + 0.025 * np.exp(-5.0 * (XX**2 + YY**2))
    return rho_obs, u_obs, v_obs, T_obs, q_obs

RHO_OBS, U_OBS, V_OBS, T_OBS, Q_OBS = make_observation()

# =========================================================
# 2. Branch specification
# =========================================================

BRANCHES = [
    {"name": "low_diff",  "thermal_kick": 0.55, "drag": 0.012, "pressure_push": 0.055, "humid_couple": 0.030, "mixing": 0.020},
    {"name": "mid_diff",  "thermal_kick": 0.75, "drag": 0.014, "pressure_push": 0.060, "humid_couple": 0.035, "mixing": 0.028},
    {"name": "high_diff", "thermal_kick": 1.00, "drag": 0.016, "pressure_push": 0.064, "humid_couple": 0.040, "mixing": 0.040},
    {"name": "humid_cpl", "thermal_kick": 0.78, "drag": 0.013, "pressure_push": 0.058, "humid_couple": 0.062, "mixing": 0.030},
    {"name": "strong_pg", "thermal_kick": 0.72, "drag": 0.011, "pressure_push": 0.082, "humid_couple": 0.033, "mixing": 0.024},
]

# =========================================================
# 3. Utilities
# =========================================================

def clip(x, lo, hi):
    return np.clip(x, lo, hi)

def grad_x(f):
    return (np.roll(f, -1, axis=1) - np.roll(f, 1, axis=1)) * 0.5

def grad_y(f):
    return (np.roll(f, -1, axis=0) - np.roll(f, 1, axis=0)) * 0.5

def lap(f):
    return (
        np.roll(f, -1, axis=0) + np.roll(f, 1, axis=0)
        + np.roll(f, -1, axis=1) + np.roll(f, 1, axis=1)
        - 4.0 * f
    )

def deposit_to_grid(px, py, values, nx=NX, ny=NY):
    gx = clip(((px + 1.0) * 0.5 * (nx - 1)).astype(int), 0, nx - 1)
    gy = clip(((py + 1.0) * 0.5 * (ny - 1)).astype(int), 0, ny - 1)
    grid = np.zeros((ny, nx), dtype=np.float64)
    count = np.zeros((ny, nx), dtype=np.float64)
    np.add.at(grid, (gy, gx), values)
    np.add.at(count, (gy, gx), 1.0)
    return grid, count

def safe_div(a, b, fill=0.0):
    out = np.full_like(a, fill, dtype=np.float64)
    mask = b > 1e-12
    out[mask] = a[mask] / b[mask]
    return out

# =========================================================
# 4. Mesoscopic molecular state
# =========================================================

def init_particles():
    px = RNG.uniform(-1.0, 1.0, PARTICLES)
    py = RNG.uniform(-1.0, 1.0, PARTICLES)

    # Mean wind backbone
    u0 = 0.20 * np.sin(np.pi * py) * np.cos(1.1 * np.pi * px)
    v0 = -0.16 * np.sin(1.1 * np.pi * px) * np.cos(np.pi * py)

    # Molecular thermal velocity packets (super-particles)
    temp_local = 300 + 7.0 * np.exp(-7.0 * ((px + 0.2) ** 2 + (py + 0.12) ** 2))
    thermal_sigma = 0.010 * np.sqrt(temp_local / 300.0)
    vx = u0 + RNG.normal(0.0, thermal_sigma)
    vy = v0 + RNG.normal(0.0, thermal_sigma)

    Tm = temp_local + RNG.normal(0.0, 0.9, PARTICLES)
    qm = 0.40 + 0.17 * np.exp(-8.0 * ((px - 0.1) ** 2 + (py + 0.24) ** 2)) + RNG.normal(0.0, 0.01, PARTICLES)
    m = np.ones(PARTICLES, dtype=np.float64)

    return {
        "px": px, "py": py,
        "vx": vx, "vy": vy,
        "Tm": clip(Tm, 280.0, 320.0),
        "qm": clip(qm, 0.0, 1.0),
        "m": m,
    }

# =========================================================
# 5. Mesoscopic step: super-particle atmospheric kinetics
# =========================================================

def reconstruct_fields(state):
    px, py = state["px"], state["py"]
    m, vx, vy, Tm, qm = state["m"], state["vx"], state["vy"], state["Tm"], state["qm"]

    mass_grid, count = deposit_to_grid(px, py, m)
    vx_grid, _ = deposit_to_grid(px, py, m * vx)
    vy_grid, _ = deposit_to_grid(px, py, m * vy)
    T_grid, _ = deposit_to_grid(px, py, m * Tm)
    q_grid, _ = deposit_to_grid(px, py, m * qm)

    rho = safe_div(mass_grid, count, fill=1.0)
    u = safe_div(vx_grid, mass_grid, fill=0.0)
    v = safe_div(vy_grid, mass_grid, fill=0.0)
    T = safe_div(T_grid, mass_grid, fill=300.0)
    q = safe_div(q_grid, mass_grid, fill=0.4)

    # light smoothing to reconstruct macro field from packets
    for _ in range(2):
        rho = 0.86 * rho + 0.14 * (rho + 0.18 * lap(rho))
        u   = 0.84 * u   + 0.16 * (u   + 0.18 * lap(u))
        v   = 0.84 * v   + 0.16 * (v   + 0.18 * lap(v))
        T   = 0.86 * T   + 0.14 * (T   + 0.20 * lap(T))
        q   = 0.86 * q   + 0.14 * (q   + 0.20 * lap(q))

    rho = clip(rho, 0.8, 1.5)
    u = clip(u, -1.2, 1.2)
    v = clip(v, -1.2, 1.2)
    T = clip(T, 270.0, 320.0)
    q = clip(q, 0.0, 1.0)
    return rho, u, v, T, q, count

def sample_grid(field, px, py):
    gx = clip(((px + 1.0) * 0.5 * (field.shape[1] - 1)).astype(int), 0, field.shape[1] - 1)
    gy = clip(((py + 1.0) * 0.5 * (field.shape[0] - 1)).astype(int), 0, field.shape[0] - 1)
    return field[gy, gx]

def step_branch(state, params, pressure_balance=1.0):
    rho, u, v, T, q, count = reconstruct_fields(state)

    # Pseudo-pressure from macro field
    p = rho * (T / 300.0)
    pgx = clip(grad_x(p), -0.5, 0.5)
    pgy = clip(grad_y(p), -0.5, 0.5)

    # sample macro fields back to particles
    pu = sample_grid(u, state["px"], state["py"])
    pv = sample_grid(v, state["px"], state["py"])
    pT = sample_grid(T, state["px"], state["py"])
    pq = sample_grid(q, state["px"], state["py"])
    ppgx = sample_grid(pgx, state["px"], state["py"])
    ppgy = sample_grid(pgy, state["px"], state["py"])

    # super-particle kinetics:
    # 1) relax toward macro wind
    # 2) pressure gradient push
    # 3) thermal random kick (molecular motion surrogate)
    # 4) humidity-temperature coupling
    # 5) drag
    sigma = 0.008 * params["thermal_kick"] * np.sqrt(np.maximum(pT, 270.0) / 300.0)
    kickx = RNG.normal(0.0, sigma)
    kicky = RNG.normal(0.0, sigma)

    state["vx"] = (
        0.82 * state["vx"] + 0.18 * pu
        - DT * pressure_balance * params["pressure_push"] * ppgx
        + kickx
        - DT * params["drag"] * state["vx"]
    )
    state["vy"] = (
        0.82 * state["vy"] + 0.18 * pv
        - DT * pressure_balance * params["pressure_push"] * ppgy
        + kicky
        - DT * params["drag"] * state["vy"]
    )

    # humidity/temperature packet transport
    state["Tm"] = (
        0.92 * state["Tm"] + 0.08 * pT
        + DT * params["humid_couple"] * pq
        - DT * 0.020 * (state["Tm"] - 298.0)
        + RNG.normal(0.0, 0.08 * params["thermal_kick"], PARTICLES)
    )
    state["qm"] = (
        0.94 * state["qm"] + 0.06 * pq
        - DT * np.maximum(0.0, state["Tm"] - 304.0) * 0.002
        + DT * 0.0012 * np.exp(-6.0 * (state["px"]**2 + state["py"]**2))
    )

    # weak mesoscale mixing
    state["vx"] += DT * params["mixing"] * (pu - state["vx"])
    state["vy"] += DT * params["mixing"] * (pv - state["vy"])

    # advance particles
    state["px"] += DT * state["vx"]
    state["py"] += DT * state["vy"]

    # periodic boundary
    state["px"] = np.where(state["px"] > 1.0, state["px"] - 2.0, state["px"])
    state["px"] = np.where(state["px"] < -1.0, state["px"] + 2.0, state["px"])
    state["py"] = np.where(state["py"] > 1.0, state["py"] - 2.0, state["py"])
    state["py"] = np.where(state["py"] < -1.0, state["py"] + 2.0, state["py"])

    # hard clamps
    state["vx"] = clip(state["vx"], -1.8, 1.8)
    state["vy"] = clip(state["vy"], -1.8, 1.8)
    state["Tm"] = clip(state["Tm"], 275.0, 320.0)
    state["qm"] = clip(state["qm"], 0.0, 1.0)

    return state

# =========================================================
# 6. Branch scoring + statuses
# =========================================================

def score_fields(rho, u, v, T, q):
    temp_err = float(np.mean((T - T_OBS) ** 2))
    humid_err = float(np.mean((q - Q_OBS) ** 2))
    wind_err = float(np.mean((u - U_OBS) ** 2 + (v - V_OBS) ** 2))
    dens_err = float(np.mean((rho - RHO_OBS) ** 2))

    instability = float(
        np.mean(np.abs(lap(T)))
        + 0.8 * np.mean(np.abs(lap(q)))
        + 0.5 * np.mean(np.abs(lap(u)))
        + 0.5 * np.mean(np.abs(lap(v)))
    )

    score = -(
        1.15 * temp_err +
        0.95 * humid_err +
        0.75 * wind_err +
        0.70 * dens_err +
        0.06 * instability
    )
    return {
        "temp_err": temp_err,
        "humid_err": humid_err,
        "wind_err": wind_err,
        "dens_err": dens_err,
        "instability": instability,
        "score": score,
    }

def classify_branch(metric):
    # Tree-Diagram-style branch state
    if metric["score"] > -0.300 and metric["instability"] < 0.030:
        return "active"
    if metric["score"] > -0.315 and metric["instability"] < 0.040:
        return "restricted"
    if metric["score"] > -0.340:
        return "starved"
    return "withered"

# =========================================================
# 7. Mini H-UTM-like retuning
# =========================================================

def hydro_recommend(metrics):
    ranked = sorted(metrics, key=lambda x: x["score"], reverse=True)
    top = ranked[0]
    second = ranked[1]
    margin = top["score"] - second["score"]
    pressure_balance = 1.0
    if top["instability"] > 0.030:
        pressure_balance -= 0.08
    if margin < 0.002:
        pressure_balance += 0.04
    pressure_balance = float(np.clip(pressure_balance, 0.90, 1.10))
    return {"pressure_balance": pressure_balance, "top_margin": margin}

# =========================================================
# 8. Run branches
# =========================================================

fields = {}
metrics = []

for br in BRANCHES:
    state = init_particles()
    for _ in range(STEPS):
        state = step_branch(state, br, pressure_balance=1.0)
    rho, u, v, T, q, count = reconstruct_fields(state)
    m = score_fields(rho, u, v, T, q)
    m["branch"] = br["name"]
    m["status"] = classify_branch(m)
    metrics.append(m)
    fields[br["name"]] = (rho, u, v, T, q)

hydro = hydro_recommend(metrics)

# optional second pass with hydro pressure balance
metrics2 = []
fields2 = {}
for br in BRANCHES:
    state = init_particles()
    for _ in range(STEPS):
        state = step_branch(state, br, pressure_balance=hydro["pressure_balance"])
    rho, u, v, T, q, count = reconstruct_fields(state)
    m = score_fields(rho, u, v, T, q)
    m["branch"] = br["name"]
    m["status"] = classify_branch(m)
    metrics2.append(m)
    fields2[br["name"]] = (rho, u, v, T, q)

metrics2 = sorted(metrics2, key=lambda x: x["score"], reverse=True)
best = metrics2[0]
best_name = best["branch"]
rho_b, u_b, v_b, T_b, q_b = fields2[best_name]

print("=== Tree Diagram Weather v2 (Mesoscopic Molecular Motion) ===")
for r in metrics2:
    print(r)
print("\nHydro control:", hydro)
print("\nBest worldline =", best_name)

# =========================================================
# 9. Visualization
# =========================================================

fig, axes = plt.subplots(2, 3, figsize=(14, 8))

im0 = axes[0, 0].imshow(T_b, origin="lower")
axes[0, 0].set_title("Best Branch Temperature")
plt.colorbar(im0, ax=axes[0, 0], fraction=0.046)

im1 = axes[0, 1].imshow(q_b, origin="lower")
axes[0, 1].set_title("Best Branch Humidity")
plt.colorbar(im1, ax=axes[0, 1], fraction=0.046)

im2 = axes[0, 2].imshow(rho_b, origin="lower")
axes[0, 2].set_title("Best Branch Density")
plt.colorbar(im2, ax=axes[0, 2], fraction=0.046)

skip = 4
axes[1, 0].quiver(u_b[::skip, ::skip], v_b[::skip, ::skip])
axes[1, 0].set_title("Best Branch Wind")

im4 = axes[1, 1].imshow(T_OBS, origin="lower")
axes[1, 1].set_title("Pseudo Observation T")
plt.colorbar(im4, ax=axes[1, 1], fraction=0.046)

names = [r["branch"] for r in metrics2]
scores = [r["score"] for r in metrics2]
axes[1, 2].bar(names, scores)
axes[1, 2].set_title("Branch Scores")
axes[1, 2].tick_params(axis="x", rotation=30)

plt.tight_layout()
plt.show()
