
"""
Tree Diagram Unified Operator v29
Updated to include the UMDST backend v2 branch as a first-class domain.
"""

from __future__ import annotations
from pathlib import Path
import importlib.util
import sys
import json
import math
import numpy as np

ADAPTER_PATH = Path("/mnt/data/tree_diagram_umdst_adapter_v3.py")

def load_adapter():
    spec = importlib.util.spec_from_file_location("tree_diagram_umdst_adapter_v3", ADAPTER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load adapter from {ADAPTER_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules["tree_diagram_umdst_adapter_v3"] = module
    spec.loader.exec_module(module)
    return module

ADAPTER = load_adapter()

DEFAULT_REQUEST = {
    "problem": {
        "title": "Tree Diagram Unified Oracle v29",
        "target": "Use the unified oracle shell while routing molecular dynamics work to UMDST backend v2."
    }
}

def route_mappings(req):
    text = (req["problem"]["title"] + " " + req["problem"]["target"]).lower()
    if any(k in text for k in ["umdst", "molecule", "molecular", "gas", "particle"]):
        return {"plan": False, "meteorology": False, "umdst_backend": True, "coupled": False}
    return {"plan": False, "meteorology": False, "umdst_backend": True, "coupled": False}

def run_unified(req=DEFAULT_REQUEST):
    routing = route_mappings(req)
    oracle = ADAPTER.run_umdst_oracle()
    return {
        "meta": {
            "engine": "tree_diagram_unified_operator_v29",
            "structure": "unified_oracle_manifest + umdst_backend_v2",
        },
        "routing": routing,
        "domains": oracle["domains"],
        "selection": oracle["selection"],
        "oracle_summary": oracle["oracle_summary"],
    }

def main():
    oracle = run_unified()
    outpath = Path("/mnt/data/tree_diagram_unified_result_v29.json")
    outpath.write_text(json.dumps(oracle, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "selection": oracle["selection"],
        "oracle_summary": oracle["oracle_summary"],
        "domains_present": list(oracle["domains"].keys()),
    }, ensure_ascii=False, indent=2))
    print(f"saved: {outpath}")

if __name__ == "__main__":
    main()
