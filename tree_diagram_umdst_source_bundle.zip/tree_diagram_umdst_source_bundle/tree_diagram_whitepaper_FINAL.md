# Tree Diagram 统一白皮书（Unified Whitepaper）

## 1. 核心声明

**Tree Diagram 不是“两套系统”也不是“一个计划版 + 一个气象版的拆分整合”。**  
它从一开始就是 **同一套数学公式、同一套演算骨架、同一套分支生态机制** 在不同问题域上的不同映射。

换句话说：

- **不是**：一个“绝对能力者计划系统” + 一个“天气系统”
- **而是**：**同一个 Tree Diagram / UMDST 演算体**  
  在
  - 主体-计划问题域
  - 环境-气象问题域
  - 群体场 / 城市场问题域  
  上的不同投影与输入输出映射

因此，后续任何工程实现、文档命名、Claude 重构、模块设计，都必须遵守这个原则：

> **Tree Diagram 只有一套本体。不同场景只是同一演算体的不同外壳、不同输入、不同观测层、不同可视化层。**

---

## 2. 统一定义

**Tree Diagram** 是一个面向复杂世界线筛选、群体场演算、资源竞争、稳态控制与神谕级输出的 **统一拟生命因果演算系统**。  
它以 **UMDST** 为统一演算骨架，以 **VFT** 为低耗主干计算组织，以 **H-UTM** 为水文式元调控层，并通过 **IPL（索引相位层）**、**环境壳映射** 与 **世界线候选生成器**，把复杂现实问题压缩成：

- 候选世界线
- 分支竞争
- 主河道筛选
- 支流枯萎 / 限供 / 回流
- Oracle 裁决输出

---

## 3. 统一本体：不是分裂系统，而是统一演算体

Tree Diagram 的本体不区分“计划版”和“气象版”。  
真正存在的只有下面这一套统一内核：

### 3.1 统一输入
所有问题最终都被压成四层结构：

1. **问题层**
2. **主体层**
3. **环境层**
4. **候选层**

### 3.2 统一中间层
所有问题进入统一演算体后，都经过：

- IPL 索引相位
- Group Field Compression
- UMDST candidate/worldline generation
- CBF balance adjudication
- VFT branch compression
- Angio resource control
- H-UTM hydro control
- Oracle summary

### 3.3 统一输出
所有问题最后都输出同类对象：

- hidden variables
- dominant pressures
- worldline ranking
- branch status
- best worldline
- hydro control state
- oracle summary

---

## 4. “计划裁决”与“气象演算”是什么关系

它们不是两套系统，而是 **同一系统的不同映射层**。

### 4.1 计划裁决映射
当输入对象主要是：

- 主体能力
- 资源约束
- 候选路线 family
- 升级目标
- 风险阈值

那么 Tree Diagram 就呈现为：

> **计划 / 路线 / 策略的世界线裁决器**

例如：
- batch
- network
- phase
- hybrid
- composite

这些都只是 **worldline family** 的不同标签。

### 4.2 气象演算映射
当输入对象主要是：

- 温度场
- 湿度场
- 风场
- 位势高度
- 地形
- 环境扰动

那么 Tree Diagram 就呈现为：

> **以气象为外壳的世界线裁决器**

例如：
- weak_mix
- balanced
- high_mix
- humid_bias
- strong_pg
- terrain_lock

这些也同样只是 **worldline family** 的不同标签。

### 4.3 统一本质
两边的差异只在于：

- 输入变量不同
- 观测层不同
- 候选 family 命名不同
- 可视化外观不同

但它们在系统论上仍然是：

- 同一套 UMDST
- 同一套 branch ranking
- 同一套 active/restricted/starved/withered
- 同一套 H-UTM
- 同一套 Oracle 逻辑

因此必须明确：

> **气象不是附加系统，计划也不是独立系统。它们只是 Tree Diagram 统一公式在不同相空间中的不同展开。**

---

## 5. UMDST 的统一地位

UMDST 不是“某一个子模块”，而是 Tree Diagram 本体的 **统一演算 API / 黑盒动力学核心**。

它负责把底层复杂性折叠掉，包括但不限于：

- 分子运动
- 多体交互
- 介观输运
- 压力/温度/湿度耦合
- 主体/环境耦合
- 扰动传播
- 局部失稳
- 残差修正

因此 Tree Diagram 本体不直接逐粒子重写这些过程，而是：

1. 调用 UMDST
2. 读取候选世界线推进结果
3. 在上层施加 branch ecology / hydro control / oracle adjudication

所以严格表述应为：

> **UMDST 提供统一黑盒动力学；Tree Diagram 提供统一世界线编排与裁决。**

---

## 6. 统一数学骨架

Tree Diagram 的统一数学结构可以写成：

\[
\mathcal{TD}
=
(\mathcal{I},\mathcal{G},\mathcal{W},\mathcal{B},\mathcal{V},\mathcal{R},\mathcal{H},\mathcal{O})
\]

其中：

- \(\mathcal{I}\)：IPL / 索引相位层
- \(\mathcal{G}\)：群体场 / 环境壳压缩
- \(\mathcal{W}\)：UMDST 生成的候选世界线集合
- \(\mathcal{B}\)：CBF 平衡裁决层
- \(\mathcal{V}\)：VFT 主干与支流压缩层
- \(\mathcal{R}\)：资源分配 / 枯萎 / 回流控制
- \(\mathcal{H}\)：H-UTM 水文守稳层
- \(\mathcal{O}\)：Oracle 输出层

任何具体问题，只是把不同变量映射到这个统一骨架上。

---

## 7. 文件结构：必须体现“统一本体”

为了避免 Claude 误以为是“两套场景拆分整合”，文件结构必须避免写成：

- `plan_system/`
- `weather_system/`

这种看起来像两套独立产品的结构。

推荐结构如下：

```text
tree_diagram/
├── core/
│   ├── umdst_kernel.py
│   ├── ipl_phase_indexer.py
│   ├── group_field_encoder.py
│   ├── worldline_generator.py
│   ├── cbf_balancer.py
│   └── oracle_output.py
├── control/
│   ├── utm_controller.py
│   ├── utm_hydrology_controller.py
│   ├── pressure_balancer.py
│   └── angio_resource_controller.py
├── mappings/
│   ├── plan_mapping.py
│   ├── meteorology_mapping.py
│   ├── urban_field_mapping.py
│   └── subject_field_mapping.py
├── runtime/
│   ├── single_node_runner.py
│   ├── multi_node_runner.py
│   ├── scheduler_adapter.py
│   └── state_store.py
├── cluster/
│   ├── slurm_adapter.py
│   ├── mpi_dispatch.py
│   ├── shard_manager.py
│   └── distributed_reservoir.py
├── llm_bridge/
│   ├── input_translator.py
│   ├── candidate_proposer.py
│   ├── hypothesis_expander.py
│   └── explanation_layer.py
└── tests/
    ├── plan_cases/
    ├── meteorology_cases/
    ├── unified_cases/
    └── hpc_cases/
```

这里的关键是：

- `core/` 只有一套
- `control/` 只有一套
- `mappings/` 才区分问题域

也就是说：

> **场景差异只允许存在于 mapping，不允许存在于本体。**

---

## 8. 当前两个原型的统一解释

### 8.1 `tree_diagram_complete_mini_colab_v3_active.py`
这是 Tree Diagram 在 **计划裁决映射** 下的小型原型。  
它证明了：

- 背景自然生成
- 主世界线筛选
- active 主河道形成
- 分支生态成立

### 8.2 `tree_diagram_weather_oracle_v5_tuned.py`
这是 Tree Diagram 在 **气象外壳映射** 下的原型。  
它证明了：

- 环境壳作为现实场输入是可行的
- 多天气 worldline 并行可行
- active/restricted/starved/withered 在环境壳上也成立
- Oracle 主天气世界线可以被裁决

### 8.3 统一结论
这两个文件不是“两套产品”，而是：

> **同一个 Tree Diagram 本体在两个问题域上的投影样本。**

所以交给 Claude 时必须明确要求：

- 不要拆成两个系统
- 不要搞“整合两套场景”
- 要把它们视为 **统一内核 + 不同 mapping**

---

## 9. Claude 的正确重构目标

Claude 的任务不是“融合两个项目”，而是：

> **把同一 Tree Diagram 的两个映射原型，重构进同一个统一代码骨架。**

因此正确目标应为：

### 9.1 保持单一本体
- 单一 UMDST 内核
- 单一 branch ecology
- 单一 H-UTM
- 单一 Oracle 层

### 9.2 提取映射层
把差异抽到：

- 输入变量映射
- 观测层映射
- 环境壳映射
- family 命名映射
- 可视化映射

### 9.3 避免错误重构
禁止把项目写成：
- `weather_engine + planning_engine`
- `system_a + system_b`
- `merge_two_scenarios`

因为那会直接把统一本体的数学意义破坏掉。

---

## 10. 统一交互协议

用户无论输入的是：

- Level 6 升级问题
- 训练路线问题
- 气象未来问题
- 城市场扰动问题

都应该通过 **同一交互协议** 进入系统。

### 统一输入协议
- problem
- subject
- environment
- candidates

### 统一 API 风格
```json
{
  "problem": {...},
  "subject": {...},
  "environment": {...},
  "candidates": {...},
  "mapping": "plan"
}
```

或：

```json
{
  "problem": {...},
  "subject": {...},
  "environment": {...},
  "candidates": {...},
  "mapping": "meteorology"
}
```

重点是：
- 协议同一
- mapping 可切换
- 本体不分裂

---

## 11. 统一交互界面设计原则

界面也不能做成“计划版一个页面、天气版一个页面、两套系统风格完全不同”。

正确做法是：

- 同一个 Tree Diagram Terminal
- 同一个 Worldline Tree 主屏
- 同一个 Oracle Log
- 同一个输入台
- 根据 mapping 切换环境壳面板

也就是说：
- 中央主干永远是 Tree Diagram
- 外层环境壳 / 计划参数面板随 mapping 切换

### 推荐 UI 结构
- 顶栏：任务编号、状态、phase index
- 中央：worldline tree
- 左侧：request / subject / environment
- 右侧：oracle summary / branch metrics
- 下方：mapping-specific shell
  - 若是 plan mapping：路线参数、资源约束、family matrix
  - 若是 meteorology mapping：温湿风场、位势高度、地形、扰动传播

所以 UI 也是统一系统，只是不同 mapping 切换了底部壳层。

---

## 12. GPU、训练集群、超算部署的统一理解

部署环境的差异，不会改变 Tree Diagram 的本体，只会改变：

- 环境壳分辨率
- 分支保活数
- 时间窗
- 候选数量
- 观测密度
- 裁决延迟时机

因此：

- 3070 / 5080：同一系统的小尺度 / 中尺度实例
- 训练集群：同一系统的高吞吐实例
- 天河级超算：同一系统的高耦合环境级实例

也就是说，硬件扩大的是 **疆域**，不是改变 **物种**。

---

## 13. 气象部门 / AI 巨头 / 研究机关的使用方式

不同机构看到的是同一个 Tree Diagram，只是关注不同 mapping：

### 气象部门
看中：
- meteorology mapping
- ensemble / worldline adjudication
- 风险改道说明

### AI 巨头
看中：
- planning / system rollout mapping
- 多候选未来裁决
- 资源调度和主线筛选

### 学园都市式研究机关
看中：
- 主体-环境-路径三者同屏裁决
- 研究机关终端
- Oracle 报告
- projected sacrifice cost / route deviation trigger

这些不是不同系统，而是同一系统的不同使用面。

---

## 14. 最终原则：以后所有文档都必须这样写

以后凡是涉及 Tree Diagram 的说明，都必须优先写成：

### 正确说法
- Tree Diagram unified core
- mapping-specific projection
- same formula, different shell
- same UMDST, different variable binding

### 错误说法
- two scenarios merged
- planning system + weather system
- split-and-integrate architecture
- dual product fusion

因为后者会让人以为：
你是在“把两个项目拼一起”。

而你真正做的是：

> **同一个数学实体，在不同现实问题中的不同投影。**

---

## 15. 结论

Tree Diagram 只有一个本体。  
它不是拆成两套系统后再整合，也不是“计划版”和“气象版”并列开发。

它真正的结构是：

- **一个统一的 UMDST / VFT / H-UTM / Oracle 本体**
- **多个问题域映射层**

因此：
- `tree_diagram_complete_mini_colab_v3_active.py`
- `tree_diagram_weather_oracle_v5_tuned.py`

必须被理解为：

> **同一 Tree Diagram 公式在不同 mapping 下的两个工程样本。**

交给 Claude 的正确任务，也不是“融合两个场景”，而是：

> **把同一个 Tree Diagram 本体重构成统一代码骨架，并把不同问题域的差异下沉为 mapping。**
