#!/usr/bin/env python3
"""
Unified gating wrapper for Tree Diagram Engine (TDE) kernels.

This module extends the functionality provided by ``tde_water_gate.py`` to
handle multiple simulation kernels via a common interface. It supports
fast/slow gating (M1), multi‑resolution refinement (M2) and posterior
estimation (M3) for any kernel that exposes a configuration dataclass
and a ``simulate(cfg, seed)`` function. The available kernels are:

  * ``water`` – the rigid water molecule MD kernel from ``tde_water_md_v1``.
  * ``gas``   – the DSMC gas exchange kernel from ``tde_gas_exchange_v1``.

The gating logic runs two fast simulations to estimate confidence. If
confidence drops below a threshold the slow simulation is invoked. A
refinement step optionally runs a higher resolution slow simulation and
extracts refined riskfield values for selected regions of interest.
Finally, a simple posterior over the ``entropy`` parameter is returned.

Example usage::

    python tde_gate_kernel.py --kernel gas --mode auto --entropy 2.0 \
      --fast-steps 160 --slow-steps 320 --grid 48 --refine-grid 96 \
      --roi 4 --threshold 0.6 --out gas_gated.json

This will run two fast DSMC simulations for confidence, possibly fall
back to a slow simulation, and output coarse and refined riskfields,
curve, graph, sample trajectories, confidence metrics and a posterior
summary.
"""

from __future__ import annotations

import argparse
import importlib
import json
import random
from dataclasses import dataclass
from typing import Dict, List, Tuple, Any, Optional


def _l1_diff(a: List[float], b: List[float]) -> float:
    """Compute the average L1 difference between two sequences."""
    n = min(len(a), len(b))
    if n == 0:
        return 0.0
    return sum(abs(a[i] - b[i]) for i in range(n)) / n


def _confidence_two(res1: Dict, res2: Dict) -> Dict[str, float]:
    """Estimate confidence and discrepancies from two simulation outputs.

    A simple metric is used: the average absolute difference of the
    riskfield and curve arrays. A weighted combination yields a
    confidence value in [0,1], where 1 indicates perfect agreement.
    """
    dr = _l1_diff(res1.get("riskfield", []), res2.get("riskfield", []))
    dc = _l1_diff(res1.get("curve", []), res2.get("curve", []))
    # Bound differences to [0,1]
    dr = min(1.0, max(0.0, dr))
    dc = min(1.0, max(0.0, dc))
    conf = max(0.0, 1.0 - (0.7 * dr + 0.3 * dc))
    return {"conf": conf, "dr": dr, "dc": dc}


def _top_k_cells(risk: List[float], k: int) -> List[int]:
    """Return indices of the k largest values in a list."""
    if k <= 0:
        return []
    idx = list(range(len(risk)))
    idx.sort(key=lambda i: risk[i], reverse=True)
    return idx[:k]


def _refine_extract(ref_risk: List[float], coarse_grid: int, refine_grid: int, roi: List[int]) -> Dict[int, List[float]]:
    """Map a refined riskfield back onto coarse ROI cells.

    ``ref_risk`` is a flattened 2D array of length ``refine_grid**2``.
    ``coarse_grid`` and ``refine_grid`` must divide evenly. The
    function returns a dict mapping each coarse cell index to a list
    of refined values covering that cell.
    """
    factor = refine_grid // coarse_grid
    out: Dict[int, List[float]] = {}
    for cell in roi:
        gx = cell % coarse_grid
        gy = cell // coarse_grid
        vals: List[float] = []
        for ry in range(gy * factor, (gy + 1) * factor):
            for rx in range(gx * factor, (gx + 1) * factor):
                vals.append(ref_risk[ry * refine_grid + rx])
        out[cell] = vals
    return out


def _posterior_stub(entropy: float) -> Dict[str, Any]:
    """Return a simple Gaussian posterior over entropy.

    This stub returns mean and 95% CI equal to ±0.5 around the
    supplied entropy and draws a handful of random samples from the
    distribution. Real implementations would use simulation‑based
    inference to estimate the posterior.
    """
    mean = entropy
    ci_low = entropy - 0.5
    ci_high = entropy + 0.5
    rng = random.Random(42)
    sigma = 0.25
    samples = [rng.gauss(mean, sigma) for _ in range(10)]
    return {
        "mean": {"entropy": mean},
        "ci95": {"entropy": [ci_low, ci_high]},
        "samples": samples,
    }


def _load_kernel(name: str) -> Tuple[str, Any, str]:
    """Dynamically import a simulation kernel by name.

    Returns a tuple (kernel_name, module, config_class_name). Supported
    kernel names are ``water`` and ``gas``. Raises ValueError for
    unknown names.
    """
    if name == "water":
        module = importlib.import_module("tde_water_md_v1")
        return "water", module, "SimConfig"
    if name == "gas":
        module = importlib.import_module("tde_gas_exchange_v1")
        return "gas", module, "GasConfig"
    raise ValueError(f"Unknown kernel '{name}' (expected 'water' or 'gas')")


def _build_cfg(mod: Any, cfg_cls: str, steps: int, dt: float, grid: int, entropy: float, temp_ramp: float, extra: Dict[str, Any]) -> Any:
    """Construct a configuration object for the given kernel.

    ``cfg_cls`` is the name of the dataclass to instantiate. The
    ``extra`` dict carries kernel‑specific settings (number of
    particles, collision probabilities, etc.).
    """
    cls = getattr(mod, cfg_cls)
    # Fill common parameters
    kwargs = dict(steps=steps, dt=dt, grid=grid, entropy=entropy, temp_ramp=temp_ramp)
    if cfg_cls == "SimConfig":  # water kernel
        # SimConfig signature: steps, dt, grid, entropy, temp_ramp, skin
        kwargs["skin"] = extra.get("skin", 0.05)
    elif cfg_cls == "GasConfig":  # gas kernel
        # GasConfig signature: steps, dt, xmin, xmax, ymin, ymax, n, mass,
        # gamma, kT, entropy, temp_ramp, cell_size, collide_prob, grid, topk_edges, sample_traces
        kwargs.update(
            n=extra.get("n", 2000),
            cell_size=extra.get("cell_size", 0.10),
            collide_prob=extra.get("collide_prob", 0.35),
            gamma=extra.get("gamma", 0.0),
        )
    return cls(**kwargs)


def _run_sim(mod: Any, cfg: Any, seed: int) -> Dict:
    """Invoke the ``simulate`` function on a kernel module."""
    try:
        return mod.simulate(cfg, seed=seed)
    except TypeError:
        # Support kernels where the seed is positional or optional
        return mod.simulate(cfg)


def run_gate(kernel: str,
             mode: str,
             entropy: float,
             temp_ramp: float,
             fast_steps: int,
             slow_steps: int,
             dt: float,
             grid: int,
             refine_grid: int,
             roi: int,
             threshold: float,
             extra: Dict[str, Any],
             seed: int = 123) -> Dict[str, Any]:
    """Execute a unified gated simulation run for a given kernel.

    Parameters
    ----------
    kernel : str
        Name of the simulation kernel (``water`` or ``gas``).
    mode : str
        ``auto``, ``fast`` or ``slow``. In auto mode a confidence test
        decides between fast and slow. ``fast`` forces the fast path.
        ``slow`` forces the slow path.
    entropy : float
        Entropy knob (temperature scaling) passed to kernels.
    temp_ramp : float
        Linear temperature ramp multiplier over the course of the run.
    fast_steps : int
        Number of steps in fast simulations.
    slow_steps : int
        Number of steps in slow simulations.
    dt : float
        Time step size.
    grid : int
        Coarse grid resolution.
    refine_grid : int
        Fine grid resolution for refinement (M2).
    roi : int
        Number of regions of interest to refine. 0 disables M2.
    threshold : float
        Confidence threshold; below triggers a slow run in auto mode.
    extra : dict
        Kernel‑specific parameters (n, cell_size, collide_prob, gamma, skin).
    seed : int
        Random seed for reproducibility.

    Returns
    -------
    dict
        Structured result with prediction, confidence, posterior and meta.
    """
    # Load kernel module and config class name
    k_name, module, cfg_cls_name = _load_kernel(kernel)
    # Build fast configuration
    fast_cfg = _build_cfg(module, cfg_cls_name, fast_steps, dt, grid, entropy, temp_ramp, extra)
    # Helper to run a fast replicate
    def _run_fast_rep(s: int) -> Dict:
        return _run_sim(module, fast_cfg, seed=s)
    result_rep = None
    conf_info: Dict[str, float] = {}
    if mode == "slow":
        # Forced slow run
        slow_cfg = _build_cfg(module, cfg_cls_name, slow_steps, dt, grid, entropy, temp_ramp, extra)
        result_rep = _run_sim(module, slow_cfg, seed + 99)
        conf_info = {"conf": 1.0, "dr": 0.0, "dc": 0.0, "decision": "slow_forced"}
    elif mode == "fast":
        # Forced fast run (take first replicate)
        res1 = _run_fast_rep(seed + 11)
        res2 = _run_fast_rep(seed + 22)
        conf_info = _confidence_two(res1, res2)
        conf_info["decision"] = "fast_forced"
        result_rep = res1
    else:
        # Auto mode: run two fast replicates to estimate confidence
        res1 = _run_fast_rep(seed + 11)
        res2 = _run_fast_rep(seed + 22)
        conf_info = _confidence_two(res1, res2)
        if conf_info["conf"] < threshold:
            # Run slow simulation
            slow_cfg = _build_cfg(module, cfg_cls_name, slow_steps, dt, grid, entropy, temp_ramp, extra)
            result_rep = _run_sim(module, slow_cfg, seed + 99)
            conf_info["decision"] = "slow_gated"
        else:
            result_rep = res1
            conf_info["decision"] = "fast_gated"
    # Multi‑resolution refinement (M2)
    refine = None
    if roi > 0 and refine_grid > grid and (refine_grid % grid == 0):
        # Only run refinement on slow simulation for accuracy
        # Determine ROI cells from coarse riskfield of result_rep
        coarse_risk = result_rep.get("riskfield", [])
        top_cells = _top_k_cells(coarse_risk, roi)
        # Run refine simulation with same slow parameters but finer grid
        refine_cfg = _build_cfg(module, cfg_cls_name, slow_steps, dt, refine_grid, entropy, temp_ramp, extra)
        ref_res = _run_sim(module, refine_cfg, seed + 777)
        refine = {
            "grid": refine_grid,
            "roi": top_cells,
            "data": _refine_extract(ref_res.get("riskfield", []), grid, refine_grid, top_cells)
        }
    # Posterior (M3)
    post = _posterior_stub(entropy)
    # Build output structure
    prediction = {
        "riskfield": result_rep.get("riskfield", []),
        "curve": result_rep.get("curve", []),
        "graph": result_rep.get("graph", []),
        "samples": result_rep.get("samples", {}),
    }
    if refine is not None:
        prediction["refine"] = refine
    return {
        "prediction": prediction,
        "confidence": conf_info,
        "posterior": post,
        "meta": {
            "kernel": k_name,
            "mode": mode,
            "entropy": entropy,
            "temp_ramp": temp_ramp,
            "grid": grid,
            "refine_grid": refine_grid,
            "roi": roi,
        },
    }


def main() -> None:
    """Entry point for command‑line execution."""
    parser = argparse.ArgumentParser(description="Run TDE unified gated simulation")
    parser.add_argument("--kernel", choices=["water", "gas"], default="gas", help="Simulation kernel to use")
    parser.add_argument("--mode", choices=["auto", "fast", "slow"], default="auto", help="Gating mode")
    parser.add_argument("--entropy", type=float, default=0.0, help="Entropy knob for temperature scaling")
    parser.add_argument("--temp-ramp", type=float, default=0.0, help="Linear temperature ramp factor")
    parser.add_argument("--fast-steps", type=int, default=160, help="Number of steps for fast simulations")
    parser.add_argument("--slow-steps", type=int, default=320, help="Number of steps for slow simulations")
    parser.add_argument("--dt", type=float, default=0.01, help="Time step size")
    parser.add_argument("--grid", type=int, default=48, help="Coarse grid resolution")
    parser.add_argument("--refine-grid", type=int, default=96, help="Refinement grid resolution")
    parser.add_argument("--roi", type=int, default=4, help="Number of top risk cells to refine")
    parser.add_argument("--threshold", type=float, default=0.6, help="Confidence threshold to trigger slow in auto mode")
    parser.add_argument("--seed", type=int, default=123, help="Random seed")
    # Gas specific extras
    parser.add_argument("--n", type=int, default=2000, help="Number of particles for gas kernel")
    parser.add_argument("--cell-size", type=float, default=0.10, help="Collision cell size for gas kernel")
    parser.add_argument("--collide-prob", type=float, default=0.35, help="Collision probability per pair for gas kernel")
    parser.add_argument("--gamma", type=float, default=0.0, help="Langevin friction for gas kernel")
    # Water specific extras
    parser.add_argument("--skin", type=float, default=0.05, help="Neighbour list skin for water kernel")
    parser.add_argument("--out", type=str, default="tde_gated_output.json", help="Output JSON file")
    args = parser.parse_args()
    extra = {
        "n": args.n,
        "cell_size": args.cell_size,
        "collide_prob": args.collide_prob,
        "gamma": args.gamma,
        "skin": args.skin,
    }
    result = run_gate(
        kernel=args.kernel,
        mode=args.mode,
        entropy=args.entropy,
        temp_ramp=args.temp_ramp,
        fast_steps=args.fast_steps,
        slow_steps=args.slow_steps,
        dt=args.dt,
        grid=args.grid,
        refine_grid=args.refine_grid,
        roi=args.roi,
        threshold=args.threshold,
        extra=extra,
        seed=args.seed,
    )
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False)
    print(f"Wrote {args.out}")
    print("decision:", result.get("confidence", {}).get("decision"), "conf:", result.get("confidence", {}).get("conf"))


if __name__ == "__main__":
    main()