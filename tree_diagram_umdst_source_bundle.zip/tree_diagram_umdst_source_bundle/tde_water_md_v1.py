#!/usr/bin/env python3
"""Tree Diagram Engine v1 - Water-molecule dynamics kernel

This is a self-contained test program that keeps the same *outputs* as the earlier
TDE v1 (curve/riskfield/graph/samples), but replaces the particle kernel with a
coarse-grained rigid water molecule model (TIP3P-like) in 2D.

Model:
- Each molecule is rigid triatomic: O, H1, H2 with fixed bond length and angle.
- Molecule state: COM position (x,y), COM velocity (vx,vy), orientation theta,
  angular velocity omega.
- Interactions:
  * Lennard-Jones between O-O.
  * Coulomb between all atom pairs across molecules.
- Thermostat: Langevin on COM and rotational DOF.

Note: This is a *toy* MD kernel meant for "can it run" and visual statistics,
not a physically faithful water simulation.
"""

from __future__ import annotations

import argparse
import json
import math
import random
from dataclasses import dataclass
from typing import Dict, List, Tuple


@dataclass
class SimConfig:
    steps: int = 200
    dt: float = 0.02
    grid: int = 32

    # world bounds (2D torus)
    xmin: float = -1.0
    xmax: float = 1.0
    ymin: float = -1.0
    ymax: float = 1.0

    # emission controls (keep small for O(n^2))
    fall_rate: int = 6
    burst_period: float = 0.6
    burst_count: int = 20

    # radii for hit tests / soft repulsion
    player_radius: float = 0.05
    boss_radius: float = 0.06

    # Langevin
    gamma: float = 0.35
    kT: float = 0.12

    # water geometry (2D approximation)
    r_OH: float = 0.06
    angle_HOH_deg: float = 104.52

    # TIP3P-ish charges (scaled)
    qO: float = -0.834
    qH: float = +0.417

    # O-O Lennard-Jones params (toy-scaled)
    sigma_OO: float = 0.10
    epsilon_OO: float = 0.15

    # Coulomb constant (toy-scaled)
    k_e: float = 0.08

    # cutoffs
    rc_lj: float = 0.35
    rc_coul: float = 0.50

    # WCN
    topk_edges: int = 20


def wrap_bounds(x: float, y: float, cfg: SimConfig) -> Tuple[float, float]:
    w = cfg.xmax - cfg.xmin
    h = cfg.ymax - cfg.ymin
    if x < cfg.xmin:
        x += w
    elif x >= cfg.xmax:
        x -= w
    if y < cfg.ymin:
        y += h
    elif y >= cfg.ymax:
        y -= h
    return x, y


def grid_index(x: float, y: float, cfg: SimConfig) -> int:
    gx = int((x - cfg.xmin) / (cfg.xmax - cfg.xmin) * cfg.grid)
    gy = int((y - cfg.ymin) / (cfg.ymax - cfg.ymin) * cfg.grid)
    gx = max(0, min(cfg.grid - 1, gx))
    gy = max(0, min(cfg.grid - 1, gy))
    return gy * cfg.grid + gx


def dist2(x1: float, y1: float, x2: float, y2: float) -> float:
    dx = x1 - x2
    dy = y1 - y2
    return dx * dx + dy * dy


def boss_pos(t: float) -> Tuple[float, float]:
    # gentle Lissajous-ish
    return (0.35 * math.cos(0.9 * t), 0.35 * math.sin(0.7 * t) + 0.35)


def player_pos(t: float) -> Tuple[float, float]:
    # slow orbit
    return (0.55 * math.cos(0.35 * t + 1.2), -0.45 * math.sin(0.33 * t) - 0.2)


def gauss(rng: random.Random) -> float:
    u1 = max(rng.random(), 1e-12)
    u2 = rng.random()
    return math.sqrt(-2.0 * math.log(u1)) * math.cos(2.0 * math.pi * u2)


def rot2(theta: float, x: float, y: float) -> Tuple[float, float]:
    c = math.cos(theta)
    s = math.sin(theta)
    return (c * x - s * y, s * x + c * y)


def water_sites(theta: float, cfg: SimConfig) -> Tuple[Tuple[float, float], Tuple[float, float], Tuple[float, float]]:
    """Return local offsets (relative to COM) for O, H1, H2 in 2D."""
    # Place O at origin in body frame.
    # Put H atoms at +/- half-angle around +x axis.
    ang = math.radians(cfg.angle_HOH_deg)
    a = 0.5 * ang
    # body-frame positions
    O = (0.0, 0.0)
    H1 = (cfg.r_OH * math.cos(a), cfg.r_OH * math.sin(a))
    H2 = (cfg.r_OH * math.cos(a), -cfg.r_OH * math.sin(a))
    # rotate to world frame by theta
    return (rot2(theta, *O), rot2(theta, *H1), rot2(theta, *H2))


def lj_force_OO(dx: float, dy: float, cfg: SimConfig) -> Tuple[float, float]:
    r2 = dx * dx + dy * dy
    if r2 <= 1e-12:
        return (0.0, 0.0)
    if r2 > cfg.rc_lj * cfg.rc_lj:
        return (0.0, 0.0)
    inv_r2 = 1.0 / r2
    s2_over_r2 = (cfg.sigma_OO * cfg.sigma_OO) * inv_r2
    s6 = s2_over_r2 ** 3
    s12 = s6 * s6
    # F = 24*eps*(2*s12 - s6)/r^2 * r_vec
    f_over_r = 24.0 * cfg.epsilon_OO * (2.0 * s12 - s6) * inv_r2
    return (f_over_r * dx, f_over_r * dy)


def coul_force(dx: float, dy: float, qi: float, qj: float, cfg: SimConfig) -> Tuple[float, float]:
    r2 = dx * dx + dy * dy
    if r2 <= 1e-12:
        return (0.0, 0.0)
    if r2 > cfg.rc_coul * cfg.rc_coul:
        return (0.0, 0.0)
    r = math.sqrt(r2)
    # F = k_e * qi*qj / r^2 * r_hat
    f = cfg.k_e * qi * qj / (r2)
    return (f * dx / r, f * dy / r)


def soft_repulse(x: float, y: float, cx: float, cy: float, strength: float, r0: float) -> Tuple[float, float]:
    dx = x - cx
    dy = y - cy
    r2 = dx * dx + dy * dy
    if r2 <= 1e-12:
        return (0.0, 0.0)
    r = math.sqrt(r2)
    if r >= r0:
        return (0.0, 0.0)
    s = strength * (1.0 - r / r0) / r
    return (s * dx, s * dy)


def simulate(cfg: SimConfig, seed: int = 123) -> Dict:
    rng = random.Random(seed)

    # molecule state: [x,y,vx,vy,theta,omega,alive,id]
    mols: List[List[float]] = []
    next_id = 1

    def spawn_from_boss(t: float, burst_n: int, v0: float = 0.7):
        nonlocal next_id
        bx, by = boss_pos(t)
        for k in range(burst_n):
            ang = 2.0 * math.pi * (k / max(1, burst_n))
            vx = v0 * math.cos(ang) + 0.08 * gauss(rng)
            vy = v0 * math.sin(ang) + 0.08 * gauss(rng)
            theta = 2.0 * math.pi * rng.random()
            omega = 0.5 * gauss(rng)
            mols.append([bx, by, vx, vy, theta, omega, 1.0, float(next_id)])
            next_id += 1

    # outputs
    occ = [0] * (cfg.grid * cfg.grid)
    collide_steps = [0] * cfg.steps
    trans_counts: Dict[Tuple[int, int], int] = {}
    sample_ids: set[int] = set()
    sample_traces: Dict[int, List[Tuple[float, float]]] = {}

    # sample first few ids as they appear
    def maybe_add_samples():
        if len(sample_ids) >= 16:
            return
        for m in mols:
            mid = int(m[7])
            if mid not in sample_ids:
                sample_ids.add(mid)
                sample_traces[mid] = []
                if len(sample_ids) >= 16:
                    break

    # thermostat scales
    noise_scale_v = math.sqrt(2.0 * cfg.gamma * cfg.kT)  # for dv: *sqrt(dt)
    noise_scale_w = math.sqrt(2.0 * cfg.gamma * cfg.kT)  # for domega

    rc_lj2 = cfg.rc_lj * cfg.rc_lj
    rc_c2 = cfg.rc_coul * cfg.rc_coul

    # charges & site list
    qi = [cfg.qO, cfg.qH, cfg.qH]

    t = 0.0
    next_burst_t = 0.0

    for step in range(cfg.steps):
        t = step * cfg.dt

        # emission: periodic bursts from boss
        if t + 1e-12 >= next_burst_t:
            spawn_from_boss(t, cfg.burst_count)
            next_burst_t += cfg.burst_period

        # optional slow "rain" from top
        rain_n = 1 if (rng.random() < cfg.fall_rate * cfg.dt) else 0
        if rain_n:
            bx, by = 0.0, cfg.ymax - 0.02
            vx = 0.05 * gauss(rng)
            vy = -0.6 + 0.05 * gauss(rng)
            theta = 2.0 * math.pi * rng.random()
            omega = 0.5 * gauss(rng)
            mols.append([bx, by, vx, vy, theta, omega, 1.0, float(next_id)])
            next_id += 1

        maybe_add_samples()

        # prepare active list
        active_idx = [idx for idx, m in enumerate(mols) if m[6] > 0.0]
        nA = len(active_idx)

        # store previous buckets for WCN transitions (COM based)
        prev_bucket: Dict[int, int] = {}
        for idx in active_idx:
            mid = int(mols[idx][7])
            prev_bucket[mid] = grid_index(mols[idx][0], mols[idx][1], cfg)

        # forces/torques per molecule
        Fx = [0.0] * nA
        Fy = [0.0] * nA
        Tau = [0.0] * nA

        # precompute site world positions for each active molecule
        # sites[a][s] = (x,y) for s in {0:O,1:H1,2:H2}
        sites: List[List[Tuple[float, float]]] = []
        for a in range(nA):
            i = active_idx[a]
            x, y, vx, vy, theta, omega, alive, midf = mols[i]
            offO, offH1, offH2 = water_sites(theta, cfg)
            sites.append([
                (x + offO[0], y + offO[1]),
                (x + offH1[0], y + offH1[1]),
                (x + offH2[0], y + offH2[1]),
            ])

        # pair interactions (O-O LJ, all-site Coulomb)
        for a in range(nA):
            i = active_idx[a]
            xi, yi = mols[i][0], mols[i][1]
            for b in range(a + 1, nA):
                j = active_idx[b]

                # O-O LJ
                xOi, yOi = sites[a][0]
                xOj, yOj = sites[b][0]
                dx = xOi - xOj
                dy = yOi - yOj
                r2 = dx * dx + dy * dy
                if 1e-12 < r2 <= rc_lj2:
                    fx, fy = lj_force_OO(dx, dy, cfg)
                    Fx[a] += fx
                    Fy[a] += fy
                    Fx[b] -= fx
                    Fy[b] -= fy
                    # torque from force at O relative to COM is ~0 (O at COM), so ignore

                # Coulomb between all sites
                for si in range(3):
                    for sj in range(3):
                        xai, yai = sites[a][si]
                        xbj, ybj = sites[b][sj]
                        dx = xai - xbj
                        dy = yai - ybj
                        r2 = dx * dx + dy * dy
                        if r2 <= 1e-12 or r2 > rc_c2:
                            continue
                        fx, fy = coul_force(dx, dy, qi[si], qi[sj], cfg)
                        # add to COM forces
                        Fx[a] += fx
                        Fy[a] += fy
                        Fx[b] -= fx
                        Fy[b] -= fy
                        # add torques: tau = r x F (2D scalar)
                        # r from COM to site
                        rix = xai - xi
                        riy = yai - yi
                        rjx = xbj - mols[j][0]
                        rjy = ybj - mols[j][1]
                        Tau[a] += (rix * fy - riy * fx)
                        Tau[b] -= (rjx * (-fy) - rjy * (-fx))  # equal and opposite

        # external soft repulsion (Boss/Player) on COM
        bx, by = boss_pos(t)
        px, py = player_pos(t)
        for a in range(nA):
            i = active_idx[a]
            x, y = mols[i][0], mols[i][1]
            fx1, fy1 = soft_repulse(x, y, bx, by, strength=1.0, r0=0.22)
            fx2, fy2 = soft_repulse(x, y, px, py, strength=0.8, r0=0.18)
            Fx[a] += fx1 + fx2
            Fy[a] += fy1 + fy2

        # integrate (semi-implicit Euler on COM + rotation, with Langevin)
        for a in range(nA):
            i = active_idx[a]
            x, y, vx, vy, theta, omega, alive, midf = mols[i]
            mid = int(midf)

            # Langevin noise
            nvx = noise_scale_v * math.sqrt(cfg.dt) * gauss(rng)
            nvy = noise_scale_v * math.sqrt(cfg.dt) * gauss(rng)
            nwo = noise_scale_w * math.sqrt(cfg.dt) * gauss(rng)

            # COM
            vx += (Fx[a] - cfg.gamma * vx) * cfg.dt + nvx
            vy += (Fy[a] - cfg.gamma * vy) * cfg.dt + nvy
            x += vx * cfg.dt
            y += vy * cfg.dt
            x, y = wrap_bounds(x, y, cfg)

            # rotation (toy moment of inertia)
            I = 0.0025
            omega += (Tau[a] / I - cfg.gamma * omega) * cfg.dt + nwo
            theta += omega * cfg.dt
            # keep angle bounded
            if theta > math.pi:
                theta -= 2.0 * math.pi
            elif theta < -math.pi:
                theta += 2.0 * math.pi

            mols[i][0], mols[i][1], mols[i][2], mols[i][3], mols[i][4], mols[i][5] = x, y, vx, vy, theta, omega

            # occupancy & collision use COM (cheap)
            occ[grid_index(x, y, cfg)] += 1
            rr = cfg.player_radius + 0.04
            if dist2(x, y, px, py) <= rr * rr:
                collide_steps[step] += 1

            if mid in sample_ids:
                sample_traces[mid].append((x, y))

        # transitions (u->v)
        for a in range(nA):
            i = active_idx[a]
            mid = int(mols[i][7])
            u = prev_bucket.get(mid, None)
            if u is None:
                continue
            v = grid_index(mols[i][0], mols[i][1], cfg)
            trans_counts[(u, v)] = trans_counts.get((u, v), 0) + 1

    # curve: hit rate per step
    curve = [c / max(1, len(mols)) for c in collide_steps]

    # riskfield: normalize by total occupancy
    total_occ = sum(occ) or 1
    riskfield = [v / total_occ for v in occ]

    # WCN graph: top-k edges
    edges = sorted(trans_counts.items(), key=lambda kv: kv[1], reverse=True)[: cfg.topk_edges]
    graph = [[u, v, w] for (u, v), w in edges]

    # samples
    samples = {str(k): pts for k, pts in sample_traces.items()}

    return {
        "curve": curve,
        "riskfield": riskfield,
        "graph": graph,
        "samples": samples,
        "meta": {
            "kernel": "water_md_tip3p_like_2d",
            "steps": cfg.steps,
            "dt": cfg.dt,
            "grid": cfg.grid,
            "molecules": len(mols),
        },
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--steps", type=int, default=200)
    ap.add_argument("--dt", type=float, default=0.02)
    ap.add_argument("--grid", type=int, default=32)
    ap.add_argument("--out", type=str, default="tde_water_outputs.json")
    args = ap.parse_args()

    cfg = SimConfig(steps=args.steps, dt=args.dt, grid=args.grid)
    out = simulate(cfg)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out, f)

    print(f"Wrote {args.out}")
    print("meta:", out["meta"])
    print("curve_len:", len(out["curve"]), "riskfield_len:", len(out["riskfield"]), "edges:", len(out["graph"]))


if __name__ == "__main__":
    main()
