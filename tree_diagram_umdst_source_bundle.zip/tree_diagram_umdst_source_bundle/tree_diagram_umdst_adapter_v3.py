
"""
Tree Diagram <-> UMDST Adapter v3
Uses umdst_backend_v2.py as the backend.
"""

from __future__ import annotations
from pathlib import Path
import importlib.util
import sys
import json
import math
import numpy as np

BACKEND_PATH = Path("/mnt/data/umdst_backend_v2.py")


def load_umdst_backend():
    spec = importlib.util.spec_from_file_location("umdst_backend_v2", BACKEND_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load backend from {BACKEND_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules["umdst_backend_v2"] = module
    spec.loader.exec_module(module)
    return module


UMDST = load_umdst_backend()

DEFAULT_REQUEST = {
    "problem": {
        "title": "Tree Diagram UMDST Coupled Oracle",
        "target": "Rank UMDST molecular worldlines for atmospheric-microdynamics style evolution.",
    },
    "reward": {
        "components": {
            "curve_err": -1.2,
            "blow_risk": -2.0,
            "risk_var": -0.8,
            "entropy": 0.6,
            "state_bonus_normal": 0.4,
            "state_bonus_negotiate": 0.1,
            "state_bonus_crackdown": -0.5,
        }
    },
    "runtime": {"seed": 430}
}


def classify_relative(scores, idx):
    best = max(scores)
    worst = min(scores)
    span = max(1e-9, best - worst)
    rel = best - scores[idx]
    if rel <= max(0.20, 0.22 * span):
        return "active"
    if rel <= max(0.55, 0.45 * span):
        return "restricted"
    if rel <= max(1.20, 0.90 * span):
        return "starved"
    return "withered"


def histogram_of_status(rows, key="branch_status"):
    return {s: sum(r[key] == s for r in rows) for s in ["active", "restricted", "starved", "withered"]}


def td_hydro_control(rows):
    ranked = sorted(rows, key=lambda x: x["score"], reverse=True)
    margin = ranked[0]["score"] - ranked[1]["score"] if len(ranked) > 1 else 0.0
    spread = ranked[0]["score"] - ranked[-1]["score"] if len(ranked) > 1 else 0.0
    pressure_balance = 1.0 + (0.04 if margin < 0.08 else 0.0) - (0.03 if spread > 1.4 else 0.0)
    pressure_balance = float(np.clip(pressure_balance, 0.94, 1.08))
    return {
        "pressure_balance": pressure_balance,
        "top_margin": float(margin),
        "score_spread": float(spread),
        "mean_score": float(np.mean([m["score"] for m in rows])) if rows else 0.0,
    }


def default_worldlines():
    return [
        {
            "family": "balanced_air",
            "template": "umdst_v2_balanced_air",
            "kernel": {"particle_count": 1800, "steps": 100, "base_temperature": 1.00, "collision_kappa": 0.12, "gamma": 0.03, "seed": 430},
            "governance": {"negotiate_th": 0.46, "crackdown_th": 0.67},
            "target_curve": 0.22,
        },
        {
            "family": "humid_dense",
            "template": "umdst_v2_humid_dense",
            "kernel": {"particle_count": 2200, "steps": 110, "base_temperature": 0.92, "collision_kappa": 0.15, "gamma": 0.04, "seed": 431},
            "governance": {"negotiate_th": 0.42, "crackdown_th": 0.63},
            "target_curve": 0.28,
        },
        {
            "family": "dry_hot",
            "template": "umdst_v2_dry_hot",
            "kernel": {"particle_count": 1600, "steps": 95, "base_temperature": 1.18, "collision_kappa": 0.10, "gamma": 0.025, "seed": 432},
            "governance": {"negotiate_th": 0.48, "crackdown_th": 0.70},
            "target_curve": 0.18,
        },
        {
            "family": "sticky_condense",
            "template": "umdst_v2_sticky_condense",
            "kernel": {"particle_count": 2400, "steps": 120, "base_temperature": 0.86, "collision_kappa": 0.17, "gamma": 0.05, "kappa_s": 0.06, "seed": 433},
            "governance": {"negotiate_th": 0.40, "crackdown_th": 0.60},
            "target_curve": 0.34,
        },
        {
            "family": "soft_gas",
            "template": "umdst_v2_soft_gas",
            "kernel": {"particle_count": 1500, "steps": 90, "base_temperature": 1.26, "collision_kappa": 0.09, "gamma": 0.02, "seed": 434},
            "governance": {"negotiate_th": 0.50, "crackdown_th": 0.72},
            "target_curve": 0.14,
        },
    ]


def score_worldline(result, worldline, req):
    weights = req["reward"]["components"]
    summary = result["summary"]
    target_curve = float(worldline["target_curve"])
    state = summary["final_state"]

    state_bonus = 0.0
    if state == "NORMAL":
        state_bonus = weights["state_bonus_normal"]
    elif state == "NEGOTIATE":
        state_bonus = weights["state_bonus_negotiate"]
    else:
        state_bonus = weights["state_bonus_crackdown"]

    metrics = {
        "curve_err": (summary["final_curve"] - target_curve) ** 2,
        "blow_risk": float(summary["final_p_blow"]),
        "risk_var": float(summary["riskfield_var"]),
        "entropy": float(summary["transition_entropy"]),
    }
    score = (
        weights["curve_err"] * metrics["curve_err"] +
        weights["blow_risk"] * metrics["blow_risk"] +
        weights["risk_var"] * metrics["risk_var"] +
        weights["entropy"] * metrics["entropy"] +
        state_bonus
    )
    metrics["score"] = float(score)
    return metrics


def run_umdst_oracle(req=DEFAULT_REQUEST):
    rows = []
    for worldline in default_worldlines():
        cfg = {"kernel": worldline["kernel"], "governance": worldline["governance"]}
        backend_result = UMDST.run_umdst_backend(cfg)
        scored = score_worldline(backend_result, worldline, req)
        row = {
            "family": worldline["family"],
            "template": worldline["template"],
            "params": worldline,
            "backend_summary": backend_result["summary"],
            "series_tail": backend_result["series_tail"],
            **scored,
        }
        rows.append(row)

    rows = sorted(rows, key=lambda x: x["score"], reverse=True)
    scores = [r["score"] for r in rows]
    for i, row in enumerate(rows):
        row["branch_status"] = classify_relative(scores, i)

    hydro = td_hydro_control(rows)
    best = rows[0]

    return {
        "meta": {
            "engine": "tree_diagram_umdst_adapter_v3",
            "backend": "umdst_backend_v2",
            "structure": "tree_diagram_orchestration -> umdst_backend_v2.run(config) -> observables -> ranking",
        },
        "routing": {"plan": False, "meteorology": False, "umdst_backend": True, "coupled": False},
        "domains": {
            "umdst_backend": {
                "name": "umdst_backend",
                "mode": "ranking",
                "best": {
                    "branch": best["family"],
                    "status": best["branch_status"],
                    "score": best["score"],
                    "template": best["template"],
                    "params": best["params"],
                },
                "status_histogram": histogram_of_status(rows),
                "hydro_control": hydro,
                "row_count": len(rows),
                "rows": rows,
            }
        },
        "selection": {
            "dominant_mapping": "umdst_backend",
            "best_domain": "umdst_backend",
            "best_branch": best["family"],
        },
        "oracle_summary": {
            "main_worldline_alive": best["branch_status"] in ("active", "restricted"),
            "main_worldline_active": best["branch_status"] == "active",
        },
    }


def main():
    oracle = run_umdst_oracle()
    outpath = Path("/mnt/data/tree_diagram_umdst_adapter_result_v3.json")
    outpath.write_text(json.dumps(oracle, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "best_branch": oracle["selection"]["best_branch"],
        "oracle_summary": oracle["oracle_summary"],
        "status_histogram": oracle["domains"]["umdst_backend"]["status_histogram"],
    }, ensure_ascii=False, indent=2))
    print(f"saved: {outpath}")


if __name__ == "__main__":
    main()
