
"""
Tree Diagram Canonical v30
--------------------------
Single canonical entry file.

Design:
- One main file for the user
- Internally contains:
  1) legacy unified route loader (plan / meteorology)
  2) UMDST route loader
  3) unified router / oracle shell

This is the canonical Tree Diagram entrypoint.
The auxiliary files may still exist as internal build artifacts,
but this is the only file the user needs to run.
"""

from __future__ import annotations
from pathlib import Path
import importlib.util
import sys
import json

LEGACY_V27_PATH = Path("/mnt/data/tree_diagram_unified_operator_v27.py")
UMDST_ADAPTER_V3_PATH = Path("/mnt/data/tree_diagram_umdst_adapter_v3.py")


def _load_module(path: Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load module from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


LEGACY = _load_module(LEGACY_V27_PATH, "td_legacy_v27_for_canonical_v30")
UMDST = _load_module(UMDST_ADAPTER_V3_PATH, "td_umdst_adapter_v3_for_canonical_v30")


DEFAULT_REQUEST = {
    "problem": {
        "title": "Tree Diagram Canonical v30",
        "target": "Single canonical Tree Diagram entrypoint with legacy unified routes and UMDST molecular route."
    }
}


def route_mappings(req):
    text = (req["problem"]["title"] + " " + req["problem"]["target"]).lower()
    if any(k in text for k in [
        "umdst", "molecule", "molecular", "gas", "particle",
        "dsmc", "collision exchange", "microdynamics"
    ]):
        return {
            "plan": False,
            "meteorology": False,
            "umdst_backend": True,
            "coupled": False,
        }

    legacy = LEGACY.route_mappings(req)
    legacy["umdst_backend"] = False
    return legacy


def _normalize_legacy(legacy_oracle):
    meta = dict(legacy_oracle.get("meta", {}))
    meta["engine"] = "tree_diagram_canonical_v30"
    meta["mode"] = "legacy_unified"
    meta["umdst_available"] = True
    legacy_oracle["meta"] = meta
    return legacy_oracle


def _normalize_umdst(umdst_oracle):
    return {
        "meta": {
            "engine": "tree_diagram_canonical_v30",
            "mode": "umdst_backend",
            "umdst_available": True,
            "legacy_available": True,
            "structure": "single_canonical_entrypoint",
        },
        "routing": {
            "plan": False,
            "meteorology": False,
            "umdst_backend": True,
            "coupled": False,
        },
        "domains": umdst_oracle["domains"],
        "selection": umdst_oracle["selection"],
        "oracle_summary": umdst_oracle["oracle_summary"],
    }


def run_unified(req=None):
    if req is None:
        req = DEFAULT_REQUEST
    routing = route_mappings(req)
    if routing.get("umdst_backend", False):
        return _normalize_umdst(UMDST.run_umdst_oracle())
    return _normalize_legacy(LEGACY.run_unified(req))


def main():
    oracle = run_unified()
    outpath = Path("/mnt/data/tree_diagram_canonical_v30_result.json")
    outpath.write_text(json.dumps(oracle, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "engine": oracle["meta"]["engine"],
        "mode": oracle["meta"]["mode"],
        "selection": oracle["selection"],
        "oracle_summary": oracle["oracle_summary"],
        "domains_present": list(oracle["domains"].keys()),
    }, ensure_ascii=False, indent=2))
    print(f"saved: {outpath}")


if __name__ == "__main__":
    main()
