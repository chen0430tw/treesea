# Tree Diagram 完全体白皮书

## 1. 系统定义

**Tree Diagram 完全体**，是一个面向复杂世界线筛选、群体场演算、资源竞争、稳态控制与神谕级输出的拟生命计算体 / 相位级因果演算系统。  
它以 **UMDST** 为统一演算骨架，以 **VFT** 为低耗主干计算架构，以 **H-UTM** 为水文式元调控层，并通过 **索引相位层 IPL**、**群体场图谱** 与 **世界线候选生成器**，把分散理论压缩成一个可在 Colab、工作站、超算与训练集群上扩展的整机系统。

---

## 2. 当前状态

当前已经完成的部分：

- Tree Diagram 小型原型可在 Colab 跑通
- PBL 反向路线已验证
- 问题背景可自然生成
- 主世界线可稳定筛出
- 主世界线已进入 `active` 主河道
- 小型生态分支已形成：
  - active
  - restricted
  - starved
  - withered

当前 Colab v3 原型的关键结果：

- `background_naturally_emerged = true`
- 最优 worldline：
  - family = network
  - n = 20000
  - rho = 1.2
  - A = 0.8
  - sigma = 0.02
- `main_worldline_alive = true`
- `main_worldline_active = true`

---

## 3. 总体架构

Tree Diagram 完全体分为 10 层：

1. Reality Input Layer
2. IPL 索引相位层
3. Group Field Compression Layer
4. UMDST Worldline Kernel
5. CBF Balance Layer
6. VFT Vein-Flow Compute Layer
7. Angio Resource Controller
8. H-UTM Hydro Control Layer
9. Oracle Output Layer
10. LLM / Human / Tool Outer Loop

---

## 4. 各层简介

### 4.1 Reality Input Layer
输入现实问题、主体状态、资源约束、环境变量、候选路径库与外部假设。

### 4.2 IPL 索引相位层
负责对象、路径、事件、群体场的索引、寻址与相位区分。  
这是工程版向神话版过渡的关键层。

### 4.3 Group Field Compression Layer
将城市级、群体级、网络级复杂环境压缩成可演算场表示。

### 4.4 UMDST Worldline Kernel
统一承载候选世界线生成、family 竞争、主体相图、路径演化与收敛。

### 4.5 CBF Balance Layer
负责零净驱动平衡、协方差复衡与去噪裁决，避免虚假赢家。

### 4.6 VFT Vein-Flow Compute Layer
负责低秩主干、稀疏支流、法向补偿与微专家协同。  
这一层决定 Tree Diagram 的高压缩、低耗、高组织度。

### 4.7 Angio Resource Controller
负责养分分配、枯萎、限供、饥饿、回流。

### 4.8 H-UTM Hydro Control Layer
负责状态抽象、误差流量、水压调节、支流分流、滞洪池、主河道守稳。

### 4.9 Oracle Output Layer
负责工程输出、研究输出与神谕式输出。

### 4.10 Outer Loop
允许大模型、人类研究员、工具链作为外环输入候选与解释，但不允许越权进入裁决核心。

---

## 5. 文件结构建议

```text
tree_diagram_complete/
├── core/
│   ├── umdst_kernel.py
│   ├── cbf_balancer.py
│   ├── ipl_phase_indexer.py
│   ├── worldline_generator.py
│   ├── subject_phase_mapper.py
│   └── group_field_encoder.py
├── vein/
│   ├── vein_backbone.py
│   ├── tri_vein_kernel.py
│   ├── veinlet_experts.py
│   └── angio_resource_controller.py
├── control/
│   ├── utm_controller.py
│   ├── utm_hydrology_controller.py
│   ├── pressure_balancer.py
│   └── stability_phase_mapper.py
├── oracle/
│   ├── oracle_output.py
│   ├── report_builder.py
│   ├── mythic_formatter.py
│   └── audit_logger.py
├── llm_bridge/
│   ├── candidate_proposer.py
│   ├── hypothesis_expander.py
│   └── explanation_layer.py
├── runtime/
│   ├── single_node_runner.py
│   ├── multi_node_runner.py
│   ├── scheduler_adapter.py
│   ├── cache_manager.py
│   └── state_store.py
├── cluster/
│   ├── slurm_adapter.py
│   ├── mpi_dispatch.py
│   ├── shard_manager.py
│   └── distributed_reservoir.py
└── tests/
    ├── smoke/
    ├── phase/
    ├── hydro/
    ├── worldline/
    └── cluster/
```

---

## 6. 当前 Colab 原型对应关系

当前小型 Colab 原型已经包含以下压缩映射：

- PBL reverse seed → Reality Input
- background emergence → IPL / problem background growth
- group field encoding → Group Field Compression
- worldline generation → UMDST candidate layer
- balanced selection → CBF-like mini balancing
- branch compression → VFT-like top branch compression
- hydro summary → H-UTM mini state
- oracle_output.json → Oracle Layer

也就是说，当前 Colab 原型不是玩具，而是完全体的胚胎版。

---

## 7. 原理关系

前期理论原料与 Tree Diagram 的关系如下：

- 弹幕动力学：局部路径运动模型
- NRP / IPL：表示与寻址结构
- CBF：平衡修正与裁决内核
- UTM / H-UTM：控制层与守稳层
- APC / TVA / VFT / VLE：计算组织学与低耗输运结构
- UMDST：统一演算骨架

**Tree Diagram 本身不是某一个理论，而是把这些理论编排成统一拟生命演算系统的系统层。**

---

## 8. 功能总览

Tree Diagram 完全体的核心功能：

1. 从问题 seed 反向生成背景
2. 识别 hidden variables 与 dominant pressures
3. 建立群体场 / 城市场压缩表示
4. 生成候选世界线
5. 对世界线进行平衡裁决
6. 建立 active / restricted / starved / withered 分支生态
7. 通过 H-UTM 保持主河道稳定
8. 输出工程报告、研究报告与神谕式结果

---

## 9. 当前原型结果解读

当前 v3 Colab 原型已经证明：

- 背景能够自然生成
- 主世界线能够被稳定识别
- 主世界线能够被养活到 `active`
- 系统已形成最基本的生态动力学分支分布

这说明 Tree Diagram 完全体路线是可行的，且适合继续扩到：

- 多 seed 测试
- 二维扫描
- 多主体实验
- 分模块化
- 工作站版
- 集群版

---

## 10. 开发路线

### Phase 1
整理目录骨架与模块边界

### Phase 2
独立 IPL 与 group field encoder

### Phase 3
写 worldline_generator

### Phase 4
写 oracle_output 与 report_builder

### Phase 5
写 single-node 与 multi-node runtime

### Phase 6
补 cluster 层与 distributed reservoir

### Phase 7
最后接 llm_bridge 外环

---

## 11. 设计原则

1. 主河道优先  
2. 候选可以膨胀，裁决必须严格  
3. 大模型只能做提案与解释，不能越权裁决  
4. 工程体与神话体分离  
5. Colab 原型先验证，再上工作站，再上集群

---

## 12. 结论

Tree Diagram 完全体不是单纯的软件程序，也不是普通求解器。  
它是一个：

- 以 UMDST 为骨架
- 以 VFT 为叶脉式组织
- 以 H-UTM 为水文控制中枢
- 以 IPL 与群体场图谱为扩展接口

构成的 **拟生命因果演算体**。

当前 Colab v3 原型已经证明这条路线是通的。  
后续工作重点不是重写方向，而是按模块化路线把胚胎版扩成可部署的完全体。
