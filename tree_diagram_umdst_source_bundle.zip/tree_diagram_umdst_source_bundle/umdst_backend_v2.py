
"""
UMDST Backend v2
----------------
Updated from the previous backend scaffold into an executable UMDST-Gas algorithm file.

Implemented pipeline:
X_t -> Obs -> IPL -> Prune -> Lookup/Approx -> A_t=(p_t,T_t,c_t)
    -> BMOL -> NRP -> CBF -> Execute -> Y_t

Current executable kernel:
- UMDST-Gas v0.2
- 2D particle advection + cell binning + stochastic collision exchange
- riskfield / WCN / curve output
- IPL embedding / smoothing / hierarchical keys
- BMOL metrics: E_cons, S_flux, I
- NRP state machine
- CBF channel reweighting
- unified per-window output

This is now an algorithm file, not just a generic MD scaffold.
"""

from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Any, List, Tuple
import json
import math
import numpy as np


# -------------------------
# Config
# -------------------------

@dataclass
class GasKernelConfig:
    particle_count: int = 2000
    steps: int = 120
    dt: float = 0.05
    box_x: float = 100.0
    box_y: float = 60.0
    cell_x: int = 20
    cell_y: int = 12
    display_x: int = 20
    display_y: int = 12
    gamma: float = 0.03
    base_temperature: float = 1.0
    kappa_s: float = 0.0
    kappa_I: float = 0.0
    collision_kappa: float = 0.12
    sample_count: int = 12
    ipl_alpha: float = 0.22
    ipl_levels: int = 3
    seed: int = 430

@dataclass
class GovernanceConfig:
    blow_a1: float = 2.0
    blow_a2: float = 1.4
    blow_a3: float = 1.2
    blow_a4: float = 0.5
    blow_a5: float = 0.5
    blow_a6: float = 0.5
    negotiate_th: float = 0.46
    crackdown_th: float = 0.67
    lambda_cost: float = 0.8
    emergence_keep: float = 0.09


# -------------------------
# Backend
# -------------------------

class UMDSTGasBackend:
    def __init__(self, kernel: GasKernelConfig, gov: GovernanceConfig | None = None):
        self.cfg = kernel
        self.gov = gov or GovernanceConfig()
        self.rng = np.random.default_rng(self.cfg.seed)

        self.pos = np.zeros((self.cfg.particle_count, 2), dtype=np.float64)
        self.vel = np.zeros((self.cfg.particle_count, 2), dtype=np.float64)

        self.prev_A: Dict[str, Any] | None = None
        self.prev_zs: np.ndarray | None = None
        self.prev_pi: Dict[str, float] | None = None
        self.prev_state: str = "NORMAL"

        self._init_particles()

    # ---- init ----

    def _init_particles(self):
        n = self.cfg.particle_count
        self.pos[:, 0] = self.rng.uniform(0.0, self.cfg.box_x, size=n)
        self.pos[:, 1] = self.rng.uniform(0.0, self.cfg.box_y, size=n)
        std = math.sqrt(self.cfg.base_temperature)
        self.vel = self.rng.normal(scale=std, size=(n, 2))
        self.vel -= self.vel.mean(axis=0, keepdims=True)

    # ---- dynamics ----

    def wrap(self):
        self.pos[:, 0] %= self.cfg.box_x
        self.pos[:, 1] %= self.cfg.box_y

    def effective_temperature(self, entropy_t: float, influence_t: float) -> float:
        return self.cfg.base_temperature * math.exp(entropy_t) * (1.0 + self.cfg.kappa_s) * (1.0 + self.cfg.kappa_I * influence_t)

    def update_velocity_ou(self, kT_t: float):
        a = math.exp(-self.cfg.gamma * self.cfg.dt)
        b = math.sqrt(max(1e-12, (1.0 - a * a) * kT_t))
        xi = self.rng.normal(size=self.vel.shape)
        self.vel = a * self.vel + b * xi

    def advect(self):
        self.pos = self.pos + self.vel * self.cfg.dt
        self.wrap()

    def cell_index(self, pos: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        ix = np.clip((pos[:, 0] / self.cfg.box_x * self.cfg.cell_x).astype(int), 0, self.cfg.cell_x - 1)
        iy = np.clip((pos[:, 1] / self.cfg.box_y * self.cfg.cell_y).astype(int), 0, self.cfg.cell_y - 1)
        return ix, iy

    def collide(self, p_blow: float):
        ix, iy = self.cell_index(self.pos)
        cells: Dict[Tuple[int, int], List[int]] = {}
        for i in range(self.cfg.particle_count):
            cells.setdefault((int(ix[i]), int(iy[i])), []).append(i)

        collision_count = 0
        base_kappa = self.cfg.collision_kappa * (1.0 + 0.35 * p_blow)

        for _, idxs in cells.items():
            if len(idxs) < 2:
                continue
            idxs = idxs.copy()
            self.rng.shuffle(idxs)
            for a, b in zip(idxs[0::2], idxs[1::2]):
                g = self.vel[a] - self.vel[b]
                gnorm = float(np.linalg.norm(g))
                p_coll = min(1.0, base_kappa * gnorm * self.cfg.dt)
                if self.rng.random() > p_coll:
                    continue

                v_cm = 0.5 * (self.vel[a] + self.vel[b])
                theta = self.rng.uniform(0.0, 2.0 * math.pi)
                g_new = gnorm * np.array([math.cos(theta), math.sin(theta)], dtype=np.float64)

                self.vel[a] = v_cm + 0.5 * g_new
                self.vel[b] = v_cm - 0.5 * g_new
                collision_count += 1

        return collision_count

    # ---- observation ----

    def observe(self, collision_count: int) -> Dict[str, Any]:
        n = self.cfg.particle_count
        samples_idx = np.linspace(0, n - 1, num=min(self.cfg.sample_count, n), dtype=int)

        # display grid for riskfield/WCN
        gx = np.clip((self.pos[:, 0] / self.cfg.box_x * self.cfg.display_x).astype(int), 0, self.cfg.display_x - 1)
        gy = np.clip((self.pos[:, 1] / self.cfg.box_y * self.cfg.display_y).astype(int), 0, self.cfg.display_y - 1)
        cells = gy * self.cfg.display_x + gx
        M = self.cfg.display_x * self.cfg.display_y

        counts = np.bincount(cells, minlength=M).astype(np.float64)

        # one-step migration estimate using current velocity
        next_pos = self.pos + self.vel * self.cfg.dt
        next_pos[:, 0] %= self.cfg.box_x
        next_pos[:, 1] %= self.cfg.box_y
        ngx = np.clip((next_pos[:, 0] / self.cfg.box_x * self.cfg.display_x).astype(int), 0, self.cfg.display_x - 1)
        ngy = np.clip((next_pos[:, 1] / self.cfg.box_y * self.cfg.display_y).astype(int), 0, self.cfg.display_y - 1)
        next_cells = ngy * self.cfg.display_x + ngx

        transitions = np.zeros((M, M), dtype=np.float64)
        for u, v in zip(cells, next_cells):
            transitions[int(u), int(v)] += 1.0

        samples = {
            "positions": self.pos[samples_idx].tolist(),
            "velocities": self.vel[samples_idx].tolist(),
            "ids": samples_idx.tolist(),
        }

        return {
            "samples": samples,
            "raw_counts": counts,
            "transitions": transitions,
            "collision_count": collision_count,
            "speed_mean": float(np.mean(np.linalg.norm(self.vel, axis=1))),
            "speed_var": float(np.var(np.linalg.norm(self.vel, axis=1))),
        }

    # ---- IPL ----

    def embed(self, O_t: Dict[str, Any]) -> np.ndarray:
        counts = O_t["raw_counts"]
        transitions = O_t["transitions"]
        total = max(1.0, counts.sum())
        p = counts / total

        row_sums = transitions.sum(axis=1, keepdims=True)
        T = transitions / np.maximum(row_sums, 1e-9)

        flux_entropy = 0.0
        for u in range(len(p)):
            if p[u] <= 0:
                continue
            flux_entropy += p[u] * (-np.sum(T[u] * np.log(T[u] + 1e-12)))

        z = np.array([
            float(np.mean(p)),
            float(np.var(p)),
            float(flux_entropy),
            float(O_t["collision_count"] / max(1, self.cfg.particle_count) / self.cfg.dt),
            float(O_t["speed_mean"]),
            float(O_t["speed_var"]),
        ], dtype=np.float64)
        return z

    def smooth_embed(self, z_t: np.ndarray) -> np.ndarray:
        if self.prev_zs is None:
            return z_t.copy()
        a = self.cfg.ipl_alpha
        return (1.0 - a) * self.prev_zs + a * z_t

    def project_hierarchy(self, z_s_t: np.ndarray) -> List[Tuple[int, ...]]:
        keys = []
        for level in range(self.cfg.ipl_levels):
            scale = 2 + level
            k = tuple(np.floor(z_s_t * scale).astype(int).tolist())
            keys.append(k)
        return keys

    def prune(self, keys_t: List[Tuple[int, ...]]) -> Dict[str, Any]:
        coarse = keys_t[0]
        mode = "refine" if coarse[1] > 0 or coarse[2] > 0 else "fast"
        return {"keys": keys_t, "mode": mode, "roi_budget": 1 if mode == "fast" else 3}

    # ---- Tree Diagram core object ----

    def lookup_or_approx(self, O_t: Dict[str, Any]) -> Dict[str, Any]:
        counts = O_t["raw_counts"]
        transitions = O_t["transitions"]
        p = counts / max(1.0, counts.sum())
        T = transitions / np.maximum(transitions.sum(axis=1, keepdims=True), 1e-9)
        curve = float(O_t["collision_count"] / max(1, self.cfg.particle_count) / self.cfg.dt)
        return {"p": p, "T": T, "c": curve}

    # ---- BMOL ----

    def biometrics(self, A_t: Dict[str, Any]) -> Dict[str, float]:
        p_t = A_t["p"]
        T_t = A_t["T"]

        if self.prev_A is None:
            return {
                "E_cons": 0.0,
                "S_flux": self._flux_entropy(p_t, T_t),
                "I": 0.0,
                "Var": float(np.var(p_t)),
                "Disagree": 0.0,
                "OOD": 0.0,
            }

        p_prev = self.prev_A["p"]
        T_prev = self.prev_A["T"]

        E_cons = float(np.sum(np.abs(p_t - p_prev @ T_prev)))
        S_flux = self._flux_entropy(p_t, T_t)

        I = 0.0
        for u in range(len(p_prev)):
            if p_prev[u] <= 0:
                continue
            I += p_prev[u] * np.sum(T_prev[u] * (np.log(T_prev[u] + 1e-12) - np.log(T_t[u] + 1e-12)))

        return {
            "E_cons": float(E_cons),
            "S_flux": float(S_flux),
            "I": float(I),
            "Var": float(np.var(p_t)),
            "Disagree": float(np.mean(np.abs(T_t - T_prev))),
            "OOD": float(max(0.0, np.max(p_t) - np.max(p_prev))),
        }

    @staticmethod
    def _flux_entropy(p: np.ndarray, T: np.ndarray) -> float:
        out = 0.0
        for u in range(len(p)):
            if p[u] <= 0:
                continue
            out += p[u] * (-np.sum(T[u] * np.log(T[u] + 1e-12)))
        return float(out)

    # ---- governance ----

    def nrp(self, M_t: Dict[str, float]) -> Tuple[str, float]:
        prev_S = 0.0 if self.prev_A is None else self._flux_entropy(self.prev_A["p"], self.prev_A["T"])
        dS = M_t["S_flux"] - prev_S
        x = (
            self.gov.blow_a1 * M_t["E_cons"]
            + self.gov.blow_a2 * dS
            + self.gov.blow_a3 * M_t["I"]
            + self.gov.blow_a4 * M_t["Var"]
            + self.gov.blow_a5 * M_t["Disagree"]
            + self.gov.blow_a6 * M_t["OOD"]
        )
        p_blow = 1.0 / (1.0 + math.exp(-x))

        if p_blow >= self.gov.crackdown_th:
            return "CRACKDOWN", float(p_blow)
        if p_blow >= self.gov.negotiate_th:
            return "NEGOTIATE", float(p_blow)
        return "NORMAL", float(p_blow)

    def cbf(self, state_t: str, M_t: Dict[str, float]) -> Dict[str, float]:
        channels = {
            "cheap":      np.array([0.20 + M_t["OOD"], 0.25], dtype=np.float64),
            "surrogate":  np.array([0.30 + M_t["Disagree"], 0.35], dtype=np.float64),
            "RML":        np.array([0.40 + M_t["I"], 0.55], dtype=np.float64),
            "refine":     np.array([0.55 + M_t["Var"], 0.80], dtype=np.float64),
            "slow":       np.array([0.75 + M_t["E_cons"], 1.00], dtype=np.float64),
            "implicit":   np.array([0.45 + M_t["Disagree"], 0.70], dtype=np.float64),
            "emergence":  np.array([0.60 + M_t["OOD"], 0.60], dtype=np.float64),
        }
        priors = {
            "cheap": 1.0,
            "surrogate": 1.0,
            "RML": 0.9,
            "refine": 0.8,
            "slow": 0.7,
            "implicit": 0.7,
            "emergence": self.gov.emergence_keep,
        }

        # one-step closed-form style update around theta0 = [0, 0]
        lam = self.gov.lambda_cost
        b = np.array([-lam, 1.0], dtype=np.float64)
        C = np.eye(2, dtype=np.float64)

        avg_cost = np.mean([phi[0] for phi in channels.values()])
        avg_gain = np.mean([phi[1] for phi in channels.values()])
        B0 = avg_gain - lam * avg_cost
        denom = float(b.T @ C @ b)
        theta = - (B0 / max(1e-9, denom)) * (C @ b)

        logits = {}
        for k, phi in channels.items():
            logits[k] = priors[k] * math.exp(float(theta @ phi))

        # NRP masking
        if state_t == "NEGOTIATE":
            for k in ["cheap"]:
                logits[k] = 0.0
        elif state_t == "CRACKDOWN":
            for k in ["cheap", "surrogate", "RML"]:
                logits[k] = 0.0

        s = sum(logits.values())
        if s <= 1e-12:
            return {k: 0.0 for k in logits}
        return {k: v / s for k, v in logits.items()}

    # ---- executor ----

    def execute(self, A_t: Dict[str, Any], state_t: str, pi_t: Dict[str, float], O_t: Dict[str, Any]) -> Dict[str, Any]:
        meta = {
            "state": state_t,
            "pi": pi_t,
            "allowed_channels": [k for k, v in pi_t.items() if v > 1e-6],
        }

        if state_t == "NEGOTIATE":
            # implicit stitch: mildly smooth p and T
            p = A_t["p"]
            T = A_t["T"]
            p2 = 0.75 * p + 0.25 * np.roll(p, 1)
            T2 = 0.85 * T + 0.15 * np.roll(T, 1, axis=1)
            T2 = T2 / np.maximum(T2.sum(axis=1, keepdims=True), 1e-9)
            A_t = {"p": p2, "T": T2, "c": A_t["c"]}
            meta["implicit_stitch"] = True

        if state_t == "CRACKDOWN":
            # degrade: cut drive-like behavior by damping velocities
            self.vel *= 0.82
            meta["degrade"] = True

        return {
            "p": A_t["p"],
            "T": A_t["T"],
            "c": A_t["c"],
            "samples": O_t["samples"],
            "meta": meta,
        }

    # ---- one window ----

    def run_window(self) -> Dict[str, Any]:
        entropy_t = 0.0 if self.prev_A is None else self._flux_entropy(self.prev_A["p"], self.prev_A["T"])
        influence_t = 0.0 if self.prev_A is None else 0.0

        kT_t = self.effective_temperature(entropy_t, influence_t)
        self.update_velocity_ou(kT_t)
        self.advect()

        # provisional observation before governance bump
        collision_count = self.collide(p_blow=0.0)
        O_t = self.observe(collision_count)

        z_t = self.embed(O_t)
        z_s_t = self.smooth_embed(z_t)
        keys_t = self.project_hierarchy(z_s_t)
        C_t = self.prune(keys_t)
        A_t = self.lookup_or_approx(O_t)

        M_t = self.biometrics(A_t)
        state_t, p_blow = self.nrp(M_t)
        pi_t = self.cbf(state_t, M_t)

        # re-run collision governance effect only as meta signal in v2, not second physics pass
        Y_t = self.execute(A_t, state_t, pi_t, O_t)

        self.prev_A = A_t
        self.prev_zs = z_s_t
        self.prev_pi = pi_t
        self.prev_state = state_t

        return {
            "O_t": {
                "collision_count": O_t["collision_count"],
                "speed_mean": O_t["speed_mean"],
                "speed_var": O_t["speed_var"],
            },
            "IPL_t": {
                "z_t": z_t.tolist(),
                "z_s_t": z_s_t.tolist(),
                "keys_t": [list(k) for k in keys_t],
                "prune_mode": C_t["mode"],
                "roi_budget": C_t["roi_budget"],
            },
            "A_t": {
                "riskfield": Y_t["p"].tolist(),
                "curve": Y_t["c"],
            },
            "BMOL_t": M_t,
            "state_t": state_t,
            "p_blow": p_blow,
            "pi_t": pi_t,
            "Y_t": {
                "curve": Y_t["c"],
                "meta": Y_t["meta"],
            },
        }

    # ---- full run ----

    def run(self) -> Dict[str, Any]:
        windows = []
        for _ in range(self.cfg.steps):
            windows.append(self.run_window())

        final = windows[-1]
        riskfield = np.array(final["A_t"]["riskfield"], dtype=np.float64)
        M = self.cfg.display_x * self.cfg.display_y
        T_last = self.prev_A["T"] if self.prev_A is not None else np.eye(M)

        out = {
            "config": {
                "kernel": asdict(self.cfg),
                "governance": asdict(self.gov),
            },
            "summary": {
                "window_count": len(windows),
                "final_state": final["state_t"],
                "final_p_blow": final["p_blow"],
                "final_curve": final["Y_t"]["curve"],
                "riskfield_mean": float(np.mean(riskfield)),
                "riskfield_var": float(np.var(riskfield)),
                "transition_entropy": float(self._flux_entropy(riskfield, T_last)),
            },
            "series_tail": {
                "curve": [w["Y_t"]["curve"] for w in windows[-20:]],
                "p_blow": [w["p_blow"] for w in windows[-20:]],
                "state": [w["state_t"] for w in windows[-20:]],
            },
            "last_window": final,
        }
        return out


# -------------------------
# Public API
# -------------------------

def default_backend_config() -> Dict[str, Any]:
    return {
        "kernel": asdict(GasKernelConfig()),
        "governance": asdict(GovernanceConfig()),
    }

def run_umdst_backend(config_dict: Dict[str, Any] | None = None) -> Dict[str, Any]:
    if config_dict is None:
        cfg = default_backend_config()
    else:
        cfg = config_dict

    kernel = GasKernelConfig(**cfg.get("kernel", {}))
    gov = GovernanceConfig(**cfg.get("governance", {}))
    backend = UMDSTGasBackend(kernel, gov)
    return backend.run()


def main():
    result = run_umdst_backend()
    outpath = Path("/mnt/data/umdst_backend_result_v2.json")
    outpath.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result["summary"], ensure_ascii=False, indent=2))
    print(f"saved: {outpath}")


if __name__ == "__main__":
    main()
