#!/usr/bin/env python3
"""
Gas molecule exchange kernel for Tree Diagram Engine (TDE).

This module implements a simple direct simulation Monte Carlo (DSMC)
approach for an idealised two‑dimensional gas. Particles move
ballistically (advection) within a periodic box. Collisions are
handled within fixed spatial cells by randomly pairing particles
and exchanging their relative velocities. This retains momentum
and kinetic energy on average and produces Maxwell‑molecule like
behaviour. A weak Langevin thermostat may optionally be applied
to maintain temperature.

The interface follows the pattern of the rigid water kernel so that
it can be used interchangeably in the gating wrapper. The
``simulate`` function accepts a ``GasConfig`` instance and returns
a dictionary containing:

  ``curve``     – the per‑step collision rate per particle
  ``riskfield`` – a normalised occupancy histogram on a coarse grid
  ``graph``     – the WCN transitions between grid cells (top‑k)
  ``samples``   – trajectories for a subset of particles (for
                   front‑end animation)
  ``meta``      – a dictionary of parameters used in the run

Entropy and temperature ramping are handled similarly to the water
kernel: ``kT_eff = kT * exp(entropy) * (1 + temp_ramp * frac)``
where ``frac`` is the fraction of the simulation duration completed.

Usage example::

    from tde_gas_exchange_v1 import GasConfig, simulate
    cfg = GasConfig(steps=200, dt=0.02, n=1000, entropy=0.0)
    res = simulate(cfg, seed=42)

"""

from __future__ import annotations

import argparse
import json
import math
import random
from dataclasses import dataclass
from typing import Dict, List, Tuple


@dataclass
class GasConfig:
    """Configuration for the gas exchange simulation."""

    # Simulation parameters
    steps: int = 400
    dt: float = 0.01

    # Box bounds (periodic)
    xmin: float = -1.0
    xmax: float = 1.0
    ymin: float = -1.0
    ymax: float = 1.0

    # Number of particles and mass
    n: int = 2000
    mass: float = 1.0

    # Thermal control parameters
    gamma: float = 0.0  # friction coefficient for optional Langevin term
    kT: float = 0.08    # base thermal energy
    entropy: float = 0.0  # entropy knob (exp scaling of kT)
    temp_ramp: float = 0.0  # linear ramp of temperature over time

    # DSMC collision settings
    cell_size: float = 0.10     # size of collision cells
    collide_prob: float = 0.35  # probability of collision per pair

    # Output controls
    grid: int = 48              # coarse grid resolution for riskfield and WCN
    topk_edges: int = 30        # number of WCN edges to return
    sample_traces: int = 16     # number of particle trajectories to record


def _wrap(x: float, lo: float, hi: float) -> float:
    """Wrap positions into the periodic box."""
    L = hi - lo
    while x < lo:
        x += L
    while x >= hi:
        x -= L
    return x


def _kT_eff(step: int, cfg: GasConfig) -> float:
    """Compute the effective thermal energy at a given time step."""
    base = cfg.kT * math.exp(cfg.entropy)
    if cfg.temp_ramp == 0.0 or cfg.steps <= 1:
        return base
    frac = step / (cfg.steps - 1)
    return base * (1.0 + cfg.temp_ramp * frac)


def _grid_index(x: float, y: float, cfg: GasConfig) -> int:
    """Map continuous coordinates to a coarse grid index."""
    gx = int((x - cfg.xmin) / (cfg.xmax - cfg.xmin) * cfg.grid)
    gy = int((y - cfg.ymin) / (cfg.ymax - cfg.ymin) * cfg.grid)
    gx = max(0, min(cfg.grid - 1, gx))
    gy = max(0, min(cfg.grid - 1, gy))
    return gy * cfg.grid + gx


def _cell_index(x: float, y: float, cfg: GasConfig, nx: int, ny: int, csx: float, csy: float) -> Tuple[int, int]:
    """Map coordinates to a collision cell index (periodic)."""
    cx = int((x - cfg.xmin) / csx) % nx
    cy = int((y - cfg.ymin) / csy) % ny
    return cx, cy


def _dsmc_collision(vxi: float, vyi: float, vxj: float, vyj: float, rng: random.Random) -> Tuple[float, float, float, float]:
    """Perform an elastic collision by randomising relative velocity direction.

    Conserves total momentum and kinetic energy on average.
    """
    # Centre of mass velocity
    vcmx = 0.5 * (vxi + vxj)
    vcmy = 0.5 * (vyi + vyj)
    # Relative velocity
    dvx = vxi - vxj
    dvy = vyi - vyj
    speed = math.hypot(dvx, dvy)
    if speed < 1e-12:
        # Avoid degeneracy by assigning a tiny relative velocity
        ang = 2.0 * math.pi * rng.random()
        dvx = 1e-6 * math.cos(ang)
        dvy = 1e-6 * math.sin(ang)
        speed = math.hypot(dvx, dvy)
    # Choose a new random direction for the relative velocity
    ang = 2.0 * math.pi * rng.random()
    ndvx = speed * math.cos(ang)
    ndvy = speed * math.sin(ang)
    # Construct post-collision velocities
    vxi2 = vcmx + 0.5 * ndvx
    vyi2 = vcmy + 0.5 * ndvy
    vxj2 = vcmx - 0.5 * ndvx
    vyj2 = vcmy - 0.5 * ndvy
    return vxi2, vyi2, vxj2, vyj2


def simulate(cfg: GasConfig, seed: int = 123) -> Dict:
    """Run a gas exchange simulation using DSMC.

    Parameters
    ----------
    cfg : GasConfig
        Simulation configuration parameters.
    seed : int, optional
        Random seed for reproducibility. Default is 123.

    Returns
    -------
    Dict
        Dictionary containing curve, riskfield, graph, samples and meta.
    """
    rng = random.Random(seed)

    # Initialise positions uniformly in the box
    xs = [rng.uniform(cfg.xmin, cfg.xmax) for _ in range(cfg.n)]
    ys = [rng.uniform(cfg.ymin, cfg.ymax) for _ in range(cfg.n)]

    # Initialise velocities from a Maxwellian distribution
    kT0 = _kT_eff(0, cfg)
    std = math.sqrt(kT0 / cfg.mass)
    vxs = [rng.gauss(0.0, std) for _ in range(cfg.n)]
    vys = [rng.gauss(0.0, std) for _ in range(cfg.n)]

    # Prepare output containers
    occ = [0] * (cfg.grid * cfg.grid)
    collide_counts = [0] * cfg.steps
    trans_counts: Dict[Tuple[int, int], int] = {}
    # Track previous grid index for WCN
    prev_bkt = [None] * cfg.n
    # Sample trajectories for the first ``sample_traces`` particles
    sample_ids = list(range(min(cfg.sample_traces, cfg.n)))
    samples: Dict[str, List[Tuple[float, float]]] = {str(i): [] for i in sample_ids}

    # Collision cell grid
    Lx = cfg.xmax - cfg.xmin
    Ly = cfg.ymax - cfg.ymin
    nx = max(1, int(Lx / cfg.cell_size))
    ny = max(1, int(Ly / cfg.cell_size))
    csx = Lx / nx
    csy = Ly / ny

    # OU coefficients for optional Langevin thermostat
    if cfg.gamma > 0.0:
        # Precompute OU factors (will vary with temperature ramp below)
        pass

    for step in range(cfg.steps):
        # Update temperature for Langevin noise if needed
        kT = _kT_eff(step, cfg)
        if cfg.gamma > 0.0:
            a = math.exp(-cfg.gamma * cfg.dt)
            b = math.sqrt(max(0.0, (1.0 - a * a) * (kT / cfg.mass)))
        else:
            a = 1.0
            b = 0.0
        # 1) Advection with optional OU thermostat on velocities
        for i in range(cfg.n):
            if cfg.gamma > 0.0:
                vxs[i] = a * vxs[i] + b * rng.gauss(0.0, 1.0)
                vys[i] = a * vys[i] + b * rng.gauss(0.0, 1.0)
            xs[i] = _wrap(xs[i] + vxs[i] * cfg.dt, cfg.xmin, cfg.xmax)
            ys[i] = _wrap(ys[i] + vys[i] * cfg.dt, cfg.ymin, cfg.ymax)
        # Record sample trajectories
        for sid in sample_ids:
            samples[str(sid)].append((xs[sid], ys[sid]))
        # Occupancy and WCN transitions
        for i in range(cfg.n):
            bkt = _grid_index(xs[i], ys[i], cfg)
            occ[bkt] += 1
            if prev_bkt[i] is not None:
                key = (prev_bkt[i], bkt)
                trans_counts[key] = trans_counts.get(key, 0) + 1
            prev_bkt[i] = bkt
        # 2) DSMC collisions: bin particles into cells and collide pairs
        bins: List[List[List[int]]] = [[[] for _ in range(ny)] for _ in range(nx)]
        for i in range(cfg.n):
            cx, cy = _cell_index(xs[i], ys[i], cfg, nx, ny, csx, csy)
            bins[cx][cy].append(i)
        collisions_this_step = 0
        for cx in range(nx):
            for cy in range(ny):
                cell = bins[cx][cy]
                m = len(cell)
                if m < 2:
                    continue
                rng.shuffle(cell)
                # Randomly collide pairs
                for k in range(0, m - 1, 2):
                    i = cell[k]
                    j = cell[k + 1]
                    if rng.random() < cfg.collide_prob:
                        vxi, vyi, vxj, vyj = _dsmc_collision(vxs[i], vys[i], vxs[j], vys[j], rng)
                        vxs[i], vys[i], vxs[j], vys[j] = vxi, vyi, vxj, vyj
                        collisions_this_step += 1
        collide_counts[step] = collisions_this_step
    # Compute curve as collisions per particle per unit time
    curve = [c / max(1, cfg.n) / max(cfg.dt, 1e-12) for c in collide_counts]
    # Normalise riskfield
    total_occ = sum(occ) or 1
    riskfield = [v / total_occ for v in occ]
    # Build WCN graph (top‑k transitions)
    edges = sorted(trans_counts.items(), key=lambda kv: kv[1], reverse=True)[: cfg.topk_edges]
    graph = [[u, v, w] for (u, v), w in edges]
    meta = {
        "kernel": "gas_exchange_dsmc_2d",
        "steps": cfg.steps,
        "dt": cfg.dt,
        "grid": cfg.grid,
        "particles": cfg.n,
        "nx": nx,
        "ny": ny,
        "cell_size": cfg.cell_size,
        "collide_prob": cfg.collide_prob,
        "entropy": cfg.entropy,
        "temp_ramp": cfg.temp_ramp,
    }
    return {
        "curve": curve,
        "riskfield": riskfield,
        "graph": graph,
        "samples": samples,
        "meta": meta,
    }


def main() -> None:
    """Command-line interface for running the gas simulation standalone."""
    parser = argparse.ArgumentParser(description="Run gas exchange DSMC simulation")
    parser.add_argument("--steps", type=int, default=400, help="Number of simulation steps")
    parser.add_argument("--dt", type=float, default=0.01, help="Time step")
    parser.add_argument("--n", type=int, default=2000, help="Number of particles")
    parser.add_argument("--grid", type=int, default=48, help="Grid resolution for riskfield/WCN")
    parser.add_argument("--entropy", type=float, default=0.0, help="Entropy knob (scales temperature)")
    parser.add_argument("--temp-ramp", type=float, default=0.0, help="Temperature ramp factor")
    parser.add_argument("--cell-size", type=float, default=0.10, help="Collision cell size")
    parser.add_argument("--collide-prob", type=float, default=0.35, help="Collision probability per pair")
    parser.add_argument("--gamma", type=float, default=0.0, help="Langevin friction coefficient")
    parser.add_argument("--out", type=str, default="tde_gas_outputs.json", help="Output JSON file")
    args = parser.parse_args()
    cfg = GasConfig(
        steps=args.steps,
        dt=args.dt,
        n=args.n,
        grid=args.grid,
        entropy=args.entropy,
        temp_ramp=args.temp_ramp,
        cell_size=args.cell_size,
        collide_prob=args.collide_prob,
        gamma=args.gamma,
    )
    res = simulate(cfg)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False)
    print(f"Wrote {args.out}")
    print("meta:", res["meta"])
    print("curve len:", len(res["curve"]), "riskfield len:", len(res["riskfield"]), "edges:", len(res["graph"]))


if __name__ == "__main__":
    main()