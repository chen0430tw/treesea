
"""
UMDST Backend v1
----------------
A practical UMDST-style backend for Tree Diagram integration.

What this implements:
- 3D multi-species particle dynamics
- Pairwise Lennard-Jones interactions with per-species mixing
- Periodic boundary conditions
- Velocity-Verlet integrator
- Optional Berendsen thermostat
- Coarse-graining from particles to grid fields
- Observable export for Tree Diagram / oracle ranking

What this does NOT claim:
- Full real-Earth atmospheric molecular truth
- Full reactive chemistry / ionization / radiative transfer
- Production HPC MPI/CUDA implementation

This is the missing "backend" layer that Tree Diagram should call.
"""

from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Any, List, Tuple, Optional
import json
import math
from pathlib import Path
import numpy as np


# -------------------------
# Data structures
# -------------------------

@dataclass
class Species:
    name: str
    mass: float
    epsilon: float
    sigma: float
    count: int


@dataclass
class GridSpec:
    nx: int
    ny: int
    nz: int
    box_size: float


@dataclass
class UMDSTConfig:
    species: List[Species]
    dt: float = 0.0025
    steps: int = 400
    box_size: float = 14.0
    rcut: float = 2.5
    thermostat_tau: float = 0.08
    target_temperature: float = 1.0
    seed: int = 430
    coarse_grid: GridSpec = None

    def __post_init__(self):
        if self.coarse_grid is None:
            self.coarse_grid = GridSpec(nx=10, ny=10, nz=6, box_size=self.box_size)


# -------------------------
# Helpers
# -------------------------

def minimum_image(delta: np.ndarray, box_size: float) -> np.ndarray:
    return delta - box_size * np.round(delta / box_size)


def kinetic_energy(vel: np.ndarray, masses: np.ndarray) -> float:
    return float(0.5 * np.sum(masses[:, None] * vel * vel))


def temperature_from_ke(ke: float, n_particles: int) -> float:
    # 3D, k_B = 1
    dof = max(1, 3 * n_particles - 3)
    return float(2.0 * ke / dof)


def mixing_epsilon(ei: float, ej: float) -> float:
    return math.sqrt(ei * ej)


def mixing_sigma(si: float, sj: float) -> float:
    return 0.5 * (si + sj)


# -------------------------
# Core backend
# -------------------------

class UMDSTBackend:
    def __init__(self, config: UMDSTConfig):
        self.cfg = config
        self.rng = np.random.default_rng(config.seed)

        self.species_names: List[str] = []
        self.species_id: List[int] = []
        self.mass_list: List[float] = []
        self.epsilon_list: List[float] = []
        self.sigma_list: List[float] = []

        for sid, sp in enumerate(config.species):
            for _ in range(sp.count):
                self.species_names.append(sp.name)
                self.species_id.append(sid)
                self.mass_list.append(sp.mass)
                self.epsilon_list.append(sp.epsilon)
                self.sigma_list.append(sp.sigma)

        self.species_id = np.asarray(self.species_id, dtype=np.int32)
        self.masses = np.asarray(self.mass_list, dtype=np.float64)
        self.eps = np.asarray(self.epsilon_list, dtype=np.float64)
        self.sig = np.asarray(self.sigma_list, dtype=np.float64)

        self.n = len(self.masses)
        self.pos = np.zeros((self.n, 3), dtype=np.float64)
        self.vel = np.zeros((self.n, 3), dtype=np.float64)
        self.force = np.zeros((self.n, 3), dtype=np.float64)

        self._initialize_state()

    def _initialize_state(self) -> None:
        n_side = int(math.ceil(self.n ** (1 / 3)))
        xs = np.linspace(0.0, 1.0, n_side, endpoint=False)
        ys = np.linspace(0.0, 1.0, n_side, endpoint=False)
        zs = np.linspace(0.0, 1.0, n_side, endpoint=False)
        lattice = np.array(np.meshgrid(xs, ys, zs, indexing="ij")).reshape(3, -1).T[: self.n]

        jitter = 0.03 * self.rng.normal(size=(self.n, 3))
        self.pos = (lattice * self.cfg.box_size + 0.5 * self.cfg.box_size / n_side + jitter) % self.cfg.box_size

        for i in range(self.n):
            std = math.sqrt(self.cfg.target_temperature / self.masses[i])
            self.vel[i] = self.rng.normal(scale=std, size=3)

        # zero net momentum
        p = np.sum(self.masses[:, None] * self.vel, axis=0)
        self.vel -= p[None, :] / np.sum(self.masses)

        self.force, _, _ = self.compute_forces()

    def compute_forces(self) -> Tuple[np.ndarray, float, float]:
        f = np.zeros_like(self.pos)
        pe = 0.0
        virial = 0.0

        for i in range(self.n - 1):
            rij = self.pos[i + 1 :] - self.pos[i]
            rij = minimum_image(rij, self.cfg.box_size)
            r2 = np.sum(rij * rij, axis=1)

            eps_ij = np.sqrt(self.eps[i] * self.eps[i + 1 :])
            sig_ij = 0.5 * (self.sig[i] + self.sig[i + 1 :])

            rcut_ij = self.cfg.rcut * sig_ij
            mask = (r2 > 1e-12) & (r2 < rcut_ij * rcut_ij)
            if not np.any(mask):
                continue

            rij_m = rij[mask]
            r2_m = r2[mask]
            eps_m = eps_ij[mask]
            sig_m = sig_ij[mask]

            inv_r2 = 1.0 / r2_m
            sr2 = (sig_m * sig_m) * inv_r2
            sr6 = sr2 ** 3
            sr12 = sr6 ** 2

            rc2 = (self.cfg.rcut * sig_m) ** 2
            src2 = (sig_m * sig_m) / rc2
            src6 = src2 ** 3
            src12 = src6 ** 2
            e_shift = 4.0 * eps_m * (src12 - src6)

            pair_pe = 4.0 * eps_m * (sr12 - sr6) - e_shift
            pe += float(np.sum(pair_pe))

            coef = 24.0 * eps_m * inv_r2 * (2.0 * sr12 - sr6)
            fij = rij_m * coef[:, None]

            virial += float(np.sum(np.sum(rij_m * fij, axis=1)))
            f[i] += np.sum(fij, axis=0)

            js = np.nonzero(mask)[0] + (i + 1)
            for local_idx, j in enumerate(js):
                f[j] -= fij[local_idx]

        return f, float(pe), float(virial)

    def thermostat(self) -> None:
        ke = kinetic_energy(self.vel, self.masses)
        t_inst = temperature_from_ke(ke, self.n)
        if t_inst <= 1e-12:
            return
        lam = math.sqrt(max(1e-8, 1.0 + (self.cfg.dt / self.cfg.thermostat_tau) * (self.cfg.target_temperature / t_inst - 1.0)))
        self.vel *= lam

    def step(self) -> Dict[str, float]:
        dt = self.cfg.dt

        self.pos = (self.pos + self.vel * dt + 0.5 * (self.force / self.masses[:, None]) * dt * dt) % self.cfg.box_size

        f_new, pe, virial = self.compute_forces()
        self.vel = self.vel + 0.5 * ((self.force + f_new) / self.masses[:, None]) * dt
        self.force = f_new

        self.thermostat()

        ke = kinetic_energy(self.vel, self.masses)
        temp = temperature_from_ke(ke, self.n)
        volume = self.cfg.box_size ** 3
        rho = self.n / volume
        pressure = rho * temp + virial / (3.0 * volume)

        return {
            "kinetic_energy": ke,
            "potential_energy": pe,
            "total_energy": ke + pe,
            "temperature": temp,
            "pressure": pressure,
            "density": rho,
        }

    def coarse_grain(self) -> Dict[str, np.ndarray]:
        g = self.cfg.coarse_grid
        nx, ny, nz = g.nx, g.ny, g.nz
        L = self.cfg.box_size

        count = np.zeros((nx, ny, nz), dtype=np.float64)
        mass = np.zeros((nx, ny, nz), dtype=np.float64)
        momentum = np.zeros((nx, ny, nz, 3), dtype=np.float64)
        temp_acc = np.zeros((nx, ny, nz), dtype=np.float64)

        ix = np.clip((self.pos[:, 0] / L * nx).astype(int), 0, nx - 1)
        iy = np.clip((self.pos[:, 1] / L * ny).astype(int), 0, ny - 1)
        iz = np.clip((self.pos[:, 2] / L * nz).astype(int), 0, nz - 1)

        for i in range(self.n):
            x, y, z = ix[i], iy[i], iz[i]
            count[x, y, z] += 1.0
            mass[x, y, z] += self.masses[i]
            momentum[x, y, z] += self.masses[i] * self.vel[i]
            temp_acc[x, y, z] += 0.5 * self.masses[i] * np.dot(self.vel[i], self.vel[i])

        vel_field = np.zeros_like(momentum)
        nz_mask = mass > 1e-12
        vel_field[nz_mask] = momentum[nz_mask] / mass[nz_mask, None]

        temp_field = np.zeros_like(count)
        temp_field[nz_mask] = 2.0 * temp_acc[nz_mask] / np.maximum(1.0, 3.0 * count[nz_mask])

        cell_vol = (L / nx) * (L / ny) * (L / nz)
        rho_field = mass / cell_vol

        return {
            "count_field": count,
            "mass_density_field": rho_field,
            "velocity_field": vel_field,
            "temperature_field": temp_field,
        }

    def composition_counts(self) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for name in self.species_names:
            out[name] = out.get(name, 0) + 1
        return out

    def run(self) -> Dict[str, Any]:
        series = []
        initial_energy = None

        for step_idx in range(self.cfg.steps):
            obs = self.step()
            if initial_energy is None:
                initial_energy = obs["total_energy"]
            series.append(obs)

        final_fields = self.coarse_grain()

        total_energy_series = np.array([x["total_energy"] for x in series], dtype=np.float64)
        temp_series = np.array([x["temperature"] for x in series], dtype=np.float64)
        pressure_series = np.array([x["pressure"] for x in series], dtype=np.float64)

        energy_drift = float(abs(total_energy_series[-1] - total_energy_series[0]) / max(1e-8, abs(total_energy_series[0])))

        return {
            "config": {
                "dt": self.cfg.dt,
                "steps": self.cfg.steps,
                "box_size": self.cfg.box_size,
                "rcut": self.cfg.rcut,
                "target_temperature": self.cfg.target_temperature,
                "species": [asdict(s) for s in self.cfg.species],
            },
            "summary": {
                "particle_count": self.n,
                "composition": self.composition_counts(),
                "mean_temperature": float(np.mean(temp_series)),
                "final_temperature": float(temp_series[-1]),
                "mean_pressure": float(np.mean(pressure_series)),
                "final_pressure": float(pressure_series[-1]),
                "energy_drift": energy_drift,
            },
            "series_tail": {
                "temperature": temp_series[-10:].tolist(),
                "pressure": pressure_series[-10:].tolist(),
                "total_energy": total_energy_series[-10:].tolist(),
            },
            "coarse_fields": {
                "count_field_shape": list(final_fields["count_field"].shape),
                "mass_density_mean": float(np.mean(final_fields["mass_density_field"])),
                "mass_density_var": float(np.var(final_fields["mass_density_field"])),
                "temperature_mean": float(np.mean(final_fields["temperature_field"])),
                "temperature_var": float(np.var(final_fields["temperature_field"])),
                "velocity_rms": float(np.sqrt(np.mean(final_fields["velocity_field"] ** 2))),
            },
        }


# -------------------------
# Tree Diagram adapter
# -------------------------

def default_species_mix() -> List[Species]:
    return [
        Species(name="N2", mass=28.0, epsilon=1.00, sigma=1.00, count=48),
        Species(name="O2", mass=32.0, epsilon=0.95, sigma=0.98, count=28),
        Species(name="H2O", mass=18.0, epsilon=1.18, sigma=0.92, count=20),
    ]


def run_umdst_backend(config_dict: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if config_dict is None:
        cfg = UMDSTConfig(species=default_species_mix())
    else:
        species = [Species(**s) for s in config_dict["species"]]
        coarse_grid = GridSpec(**config_dict["coarse_grid"]) if "coarse_grid" in config_dict else None
        cfg = UMDSTConfig(
            species=species,
            dt=config_dict.get("dt", 0.0025),
            steps=config_dict.get("steps", 400),
            box_size=config_dict.get("box_size", 14.0),
            rcut=config_dict.get("rcut", 2.5),
            thermostat_tau=config_dict.get("thermostat_tau", 0.08),
            target_temperature=config_dict.get("target_temperature", 1.0),
            seed=config_dict.get("seed", 430),
            coarse_grid=coarse_grid,
        )
    backend = UMDSTBackend(cfg)
    return backend.run()


def main():
    out = run_umdst_backend()
    outpath = Path("/mnt/data/umdst_backend_result.json")
    outpath.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(out["summary"], ensure_ascii=False, indent=2))
    print(f"saved: {outpath}")


if __name__ == "__main__":
    main()
