
# Tree Diagram Unified Operator Core v15
# Incremental compression:
# - nutrient policy moved into reward_schema
# - plan / meteorology now both go through:
#   tensor bundle -> metric bundle -> reward bundle
# - reward bundle reads a generic schema with:
#   family, metric_keys, output_map, optional policy
#
# Usage:
#   python tree_diagram_unified_operator_v15.py
#   python tree_diagram_unified_operator_v15.py --input request.json
#
# Output:
#   ./tree_diagram_unified_out_v15/unified_oracle.json

from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Any, Tuple
import argparse, itertools, json, math
import numpy as np

DEFAULT_REQUEST = {
    "problem": {
        "title": "Urban Resonance Upgrade Program",
        "target": "Find the most viable route to upgrade a city-scale resonance system from Level-5-equivalent stability to Level-6-equivalent stability.",
        "constraints": [
            "must remain under city-level safety threshold",
            "must avoid irreversible collapse of field stability",
            "must be scalable under limited infrastructure budget",
            "must remain reproducible across repeated trials",
        ],
        "time_horizon": "medium"
    },
    "subject": {
        "output_power": 0.93,
        "control_precision": 0.88,
        "load_tolerance": 0.61,
        "aim_coupling": 0.97,
        "stress_level": 0.22,
        "phase_proximity": 0.69,
        "marginal_decay": 0.11,
        "instability_sensitivity": 0.28,
    },
    "environment": {
        "budget": 0.62, "infrastructure": 0.71, "data_coverage": 0.66,
        "population_coupling": 0.83, "field_noise": 0.34, "social_pressure": 0.58,
        "regulatory_friction": 0.47, "network_density": 0.76, "phase_instability": 0.41,
        "weather_relevance": 0.70, "terrain_relevance": 0.62,
    },
    "candidates": {"mode": "auto_generate", "families_hint": ["batch", "network", "phase", "hybrid", "composite"]},
    "reward": {
        "components": {
            "feasibility": 1.15, "stability": 1.00, "field_fit": 0.95, "risk": -1.10, "spread_penalty": -0.25,
            "weather_h_err": -0.80 / 1.0e4, "weather_t_err": -1.20, "weather_q_err": -280.0,
            "weather_w_err": -0.020, "weather_instability": -0.030,
        },
        "nutrient": {
            "feasibility_threshold_gain": 1.00, "stability_threshold_gain": 0.88,
            "field_fit_threshold_gain": 0.84, "risk_penalty": -0.74, "oversize_penalty": -0.05,
        }
    },
    "runtime": {
        "plan_grid_shape": [8, 8], "weather_grid_shape": [112, 84],
        "weather_steps": 180, "weather_dt": 45.0, "grid_engine": "numpy_local"
    }
}

BASE_H = 5400.0
G = 9.81
F0 = 8.0e-5
CP = 1004.0
LV = 2.5e6
DX = 12000.0
DY = 12000.0

def deep_merge(base, override):
    out = dict(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out

def load_request(path=None):
    if path is None:
        return DEFAULT_REQUEST
    return deep_merge(DEFAULT_REQUEST, json.loads(Path(path).read_text(encoding="utf-8")))

def classify_relative(scores, idx):
    best = max(scores); worst = min(scores); span = max(1e-9, best - worst); rel = best - scores[idx]
    if rel <= max(0.20, 0.22 * span): return "active"
    if rel <= max(0.55, 0.45 * span): return "restricted"
    if rel <= max(1.20, 0.90 * span): return "starved"
    return "withered"

def histogram_of_status(rows, key="branch_status"):
    return {
        "active": sum(r[key] == "active" for r in rows),
        "restricted": sum(r[key] == "restricted" for r in rows),
        "starved": sum(r[key] == "starved" for r in rows),
        "withered": sum(r[key] == "withered" for r in rows),
    }

def clip(a, lo, hi):
    return np.clip(a, lo, hi)

@dataclass
class GridSpec:
    shape: Tuple[int, int]
    dx: float = 1.0
    dy: float = 1.0
    dt: float = 1.0
    engine: str = "numpy_local"

@dataclass
class UnifiedState:
    dyn: Dict[str, np.ndarray]
    aux: Dict[str, np.ndarray]
    meta: Dict[str, Any]

class GridComputeEngine:
    def lap(self, f, spec):
        return ((np.roll(f, -1, axis=-2) - 2.0 * f + np.roll(f, 1, axis=-2)) / (spec.dy ** 2)
                + (np.roll(f, -1, axis=-1) - 2.0 * f + np.roll(f, 1, axis=-1)) / (spec.dx ** 2))
    def grad_x(self, f, spec):
        return (np.roll(f, -1, axis=-1) - np.roll(f, 1, axis=-1)) / (2.0 * spec.dx)
    def grad_y(self, f, spec):
        return (np.roll(f, -1, axis=-2) - np.roll(f, 1, axis=-2)) / (2.0 * spec.dy)
    def smooth(self, f, alpha=0.10):
        return (1.0 - alpha) * f + alpha * (np.roll(f, 1, -2) + np.roll(f, -1, -2) + np.roll(f, 1, -1) + np.roll(f, -1, -1)) / 4.0
    def bilinear_sample(self, field, px, py):
        px = np.clip(px, 0.0, field.shape[-1] - 1.001); py = np.clip(py, 0.0, field.shape[-2] - 1.001)
        x0 = np.floor(px).astype(int); y0 = np.floor(py).astype(int)
        x1 = np.clip(x0 + 1, 0, field.shape[-1] - 1); y1 = np.clip(y0 + 1, 0, field.shape[-2] - 1)
        wx = px - x0; wy = py - y0
        f00 = field[:, y0, x0]; f10 = field[:, y0, x1]; f01 = field[:, y1, x0]; f11 = field[:, y1, x1]
        return ((1.0 - wx) * (1.0 - wy) * f00 + wx * (1.0 - wy) * f10 + (1.0 - wx) * wy * f01 + wx * wy * f11)
    def semi_lagrangian(self, field, u, v, spec):
        H, W = field.shape[-2], field.shape[-1]
        jj, ii = np.meshgrid(np.arange(H), np.arange(W), indexing="ij")
        dep_x = ii[None, ...] - (u * spec.dt / spec.dx)
        dep_y = jj[None, ...] - (v * spec.dt / spec.dy)
        return self.bilinear_sample(field, dep_x, dep_y)

class GridAbstractionLayer:
    def __init__(self, spec):
        self.spec = spec
        self.engine = GridComputeEngine()
    def scheduler(self, candidates):
        return candidates
    def aggregate(self, rows):
        return {
            "count": len(rows),
            "mean_score": float(np.mean([r["score"] for r in rows])) if rows else 0.0,
            "score_span": float(max(r["score"] for r in rows) - min(r["score"] for r in rows)) if rows else 0.0,
        }

def route_mappings(req):
    env = req["environment"]
    text = (req["problem"]["title"] + " " + req["problem"]["target"]).lower()
    kws = ["weather", "meteorology", "storm", "climate", "atmosphere", "city-scale", "urban", "environment"]
    keyword_hit = any(k in text for k in kws)
    weather_signal = max(env.get("weather_relevance", 0.0), env.get("terrain_relevance", 0.0))
    needs_meteorology = keyword_hit or weather_signal >= 0.55 or env.get("field_noise", 0.0) >= 0.30
    return {"plan": True, "meteorology": needs_meteorology, "coupled": needs_meteorology}

def family_lock(family, n):
    nc_map = {"batch":18000.0,"network":15000.0,"phase":17000.0,"electrical":16000.0,"ascetic":20000.0,"hybrid":18000.0,"composite":18500.0,
              "weak_mix":15000.0,"balanced":15000.0,"high_mix":15000.0,"humid_bias":15000.0,"strong_pg":15000.0,"terrain_lock":15000.0}
    sharp_map = {"batch":2200.0,"network":2000.0,"phase":2400.0,"electrical":2200.0,"ascetic":2600.0,"hybrid":2300.0,"composite":2500.0,
                 "weak_mix":2500.0,"balanced":2500.0,"high_mix":2500.0,"humid_bias":2500.0,"strong_pg":2500.0,"terrain_lock":2500.0}
    x = (n - nc_map[family]) / sharp_map[family]
    return 1.0 / (1.0 + math.exp(-x))

def generate_plan_candidates():
    family_params = {
        "batch":{"n":[12000,18000,20000,24000],"rho":[0.5,1.0],"A":[0.7,0.9],"sigma":[0.01,0.03]},
        "network":{"n":[10000,16000,20000],"rho":[0.8,1.2],"A":[0.6,0.8],"sigma":[0.02]},
        "phase":{"n":[10000,18000],"rho":[0.5,1.0],"A":[0.6,0.75],"sigma":[0.04]},
        "electrical":{"n":[10000,16000,20000],"rho":[0.6,1.0],"A":[0.7],"sigma":[0.05]},
        "ascetic":{"n":[10000,20000],"rho":[0.2,0.4],"A":[0.4,0.55],"sigma":[0.03]},
        "hybrid":{"n":[14000,18000,22000],"rho":[0.7,1.0],"A":[0.75],"sigma":[0.08]},
        "composite":{"n":[18000,22000],"rho":[0.8,1.0],"A":[0.8],"sigma":[0.04]},
    }
    out = []
    for fam, spec in family_params.items():
        for n, rho, A, sigma in itertools.product(spec["n"], spec["rho"], spec["A"], spec["sigma"]):
            out.append({"family": fam, "template": f"{fam}_route", "params": {"n": float(n), "rho": float(rho), "A": float(A), "sigma": float(sigma)}, "domain": "plan"})
    return out

def generate_weather_candidates():
    return [
        {"family":"weak_mix","template":"weak_mix_route","params":{"Kh":240.0,"Kt":120.0,"Kq":95.0,"drag":1.2e-5,"humid_couple":0.80,"nudging":0.00014,"pg_scale":1.00},"domain":"meteorology"},
        {"family":"balanced","template":"balanced_route","params":{"Kh":360.0,"Kt":180.0,"Kq":130.0,"drag":1.5e-5,"humid_couple":1.00,"nudging":0.00016,"pg_scale":1.00},"domain":"meteorology"},
        {"family":"high_mix","template":"high_mix_route","params":{"Kh":520.0,"Kt":260.0,"Kq":180.0,"drag":1.8e-5,"humid_couple":1.05,"nudging":0.00017,"pg_scale":1.00},"domain":"meteorology"},
        {"family":"humid_bias","template":"humid_bias_route","params":{"Kh":340.0,"Kt":175.0,"Kq":220.0,"drag":1.5e-5,"humid_couple":1.24,"nudging":0.00016,"pg_scale":1.00},"domain":"meteorology"},
        {"family":"strong_pg","template":"strong_pg_route","params":{"Kh":300.0,"Kt":150.0,"Kq":125.0,"drag":1.2e-5,"humid_couple":0.95,"nudging":0.00015,"pg_scale":1.18},"domain":"meteorology"},
        {"family":"terrain_lock","template":"terrain_lock_route","params":{"Kh":330.0,"Kt":170.0,"Kq":135.0,"drag":1.6e-5,"humid_couple":1.02,"nudging":0.00015,"pg_scale":1.04},"domain":"meteorology"},
    ]

def repeat_batch(arr2d, B):
    return np.repeat(arr2d[None, ...], B, axis=0)

def expand_scalar_to_field(arr1d, H, W):
    return np.repeat(np.repeat(arr1d[:, None, None], H, axis=1), W, axis=2)

def encode_plan_state_batch(req, spec, B, external_boost=None):
    env = req["environment"]; subj = req["subject"]; H, W = spec.shape[1], spec.shape[0]; ones = np.ones((H, W), dtype=np.float64)
    primary = 0.42 * subj["aim_coupling"] + 0.18 * subj["control_precision"] + 0.12 * subj["phase_proximity"] + 0.18 * env["population_coupling"] + 0.06 * env["data_coverage"] - 0.14 * env["field_noise"] - 0.08 * env["phase_instability"]
    secondary = 0.60 * env["network_density"] + 0.20 * env["infrastructure"] + 0.20 * env["data_coverage"]
    tertiary = 0.75 * env["phase_instability"] + 0.25 * env["field_noise"]
    resource = 0.60 * env["budget"] + 0.40 * env["infrastructure"]
    dyn = {"primary": clip(repeat_batch(ones * primary, B), 0.0, 1.0), "secondary": clip(repeat_batch(ones * secondary, B), 0.0, 1.0), "tertiary": clip(repeat_batch(ones * tertiary, B), 0.0, 1.0), "resource": clip(repeat_batch(ones * resource, B), 0.0, 1.0), "u": np.zeros((B, H, W)), "v": np.zeros((B, H, W))}
    if external_boost:
        for key, ch in [("field_coherence","primary"),("network_amplification","secondary"),("phase_turbulence","tertiary"),("resource_elasticity","resource")]:
            if key in external_boost:
                dyn[ch] = clip(dyn[ch] + external_boost[key], 0.0, 1.0)
    aux = {"governance": clip(repeat_batch(ones * (0.65 * env["regulatory_friction"] + 0.35 * env["social_pressure"]), B), 0.0, 1.0)}
    return UnifiedState(dyn=dyn, aux=aux, meta={"domain":"plan", "batch":B})

def encode_meteorology_state_batch(req, spec, B):
    H, W = spec.shape[1], spec.shape[0]
    x = np.linspace(-1.0, 1.0, W); y = np.linspace(-1.0, 1.0, H); XX, YY = np.meshgrid(x, y)
    topo = 1400.0*np.exp(-7.0*((XX+0.36)**2+(YY-0.06)**2)) + 720.0*np.exp(-10.5*((XX-0.18)**2+(YY+0.24)**2)) + 350.0*np.exp(-14.0*((XX+0.05)**2+(YY+0.28)**2))
    dyn = {"primary": repeat_batch(clip(BASE_H + 170.0*np.exp(-7.0*((XX+0.25)**2+(YY+0.02)**2)) - 105.0*np.exp(-7.8*((XX-0.25)**2+(YY-0.18)**2)) - 0.18*topo, BASE_H-350.0, BASE_H+350.0), B),
           "secondary": repeat_batch(clip(288.0 + 6.2*np.exp(-7.5*((XX+0.23)**2+(YY+0.04)**2)) - 4.3*np.exp(-9.2*((XX-0.29)**2+(YY-0.16)**2)) - 0.0032*topo, 265.0, 315.0), B),
           "tertiary": repeat_batch(clip(0.009 + 0.0085*np.exp(-8.0*((XX-0.08)**2+(YY+0.20)**2)), 1e-5, 0.025), B),
           "resource": np.zeros((B, H, W)),
           "u": repeat_batch(clip(10.5*np.sin(0.8*np.pi*YY)*np.cos(0.7*np.pi*XX), -30.0, 30.0), B),
           "v": repeat_batch(clip(-7.2*np.sin(0.7*np.pi*XX)*np.cos(0.8*np.pi*YY), -30.0, 30.0), B)}
    aux = {"topography": repeat_batch(topo, B), "XX": repeat_batch(XX, B), "YY": repeat_batch(YY, B)}
    return UnifiedState(dyn=dyn, aux=aux, meta={"domain":"meteorology", "batch":B})

def prepare_candidate_arrays(candidates):
    fams = [c["family"] for c in candidates]; params = [c["params"] for c in candidates]
    out = {"family": np.array(fams, dtype=object)}
    keys = sorted(set().union(*[p.keys() for p in params]))
    for k in keys:
        out[k] = np.array([p.get(k, 0.0) for p in params], dtype=np.float64)[:, None, None]
    return out

def operator_config(domain):
    if domain == "plan":
        return {"smooth_alpha": {"primary":0.10,"secondary":0.10,"tertiary":0.10,"resource":0.10},
                "bounds": {"primary":(0.0,1.0),"secondary":(0.0,1.0),"tertiary":(0.0,1.0),"resource":(0.0,1.0),"u":(-1e9,1e9),"v":(-1e9,1e9)}}
    return {"smooth_alpha": {"primary":0.06,"secondary":0.05,"tertiary":0.05,"u":0.04,"v":0.04},
            "bounds": {"primary":(BASE_H-500.0,BASE_H+500.0),"secondary":(250.0,320.0),"tertiary":(1e-5,0.030),"resource":(-1e9,1e9),"u":(-40.0,40.0),"v":(-40.0,40.0)}}

def family_bias_table(families):
    table = {"batch":(0.16,0.08,0.02),"network":(0.12,0.11,-0.01),"phase":(0.09,0.12,-0.02),"electrical":(0.11,0.04,0.08),"ascetic":(0.05,0.13,-0.03),"hybrid":(0.13,0.06,0.04),"composite":(0.14,0.09,0.03)}
    y = np.array([table.get(f,(0.0,0.0,0.0))[0] for f in families]); s = np.array([table.get(f,(0.0,0.0,0.0))[1] for f in families]); r = np.array([table.get(f,(0.0,0.0,0.0))[2] for f in families])
    return y, s, r

def operator_terms(state, carr, req, gal):
    spec = gal.spec; eng = gal.engine; domain = state.meta["domain"]; dyn = state.dyn; aux = state.aux
    zero = {k: np.zeros_like(v) for k, v in dyn.items()}
    terms = {name: {k: np.array(v, copy=True) for k, v in zero.items()} for name in ["advection","drift","diffusion","correction","observation"]}
    if domain == "plan":
        A = carr["A"]; rho = carr["rho"]; sigma = carr["sigma"]; n = carr["n"]; fams = carr["family"]
        locks = np.array([family_lock(f, float(nn)) for f, nn in zip(fams, n[:,0,0])], dtype=np.float64)[:,None,None]
        is_network = np.array([1.0 if f=="network" else 0.0 for f in fams])[:,None,None]
        is_phase = np.array([1.0 if f=="phase" else 0.0 for f in fams])[:,None,None]
        terms["drift"]["primary"] = 0.015*A + 0.010*locks - 0.012*sigma
        terms["drift"]["secondary"] = 0.012*rho + 0.020*is_network
        terms["drift"]["tertiary"] = 0.010*sigma - 0.020*is_phase
        terms["drift"]["resource"] = 0.010*A - 0.010*np.maximum(0.0, (n-20000.0)/10000.0)
        for k in ["primary","secondary","tertiary","resource"]:
            terms["diffusion"][k] = 0.10*(eng.smooth(dyn[k], 0.10)-dyn[k])
        return terms
    h = dyn["primary"]; T = dyn["secondary"]; q = dyn["tertiary"]; u = dyn["u"]; v = dyn["v"]; topo = aux["topography"]
    Kh = carr["Kh"]; Kt = carr["Kt"]; Kq = carr["Kq"]; drag = carr["drag"]; humid_couple = carr["humid_couple"]; nudging = carr["nudging"]; pg_scale = carr["pg_scale"]
    def saturation_specific_humidity(Tv): return 0.0045*np.exp(0.060*(Tv-273.15)/10.0)
    h_adv = eng.semi_lagrangian(h,u,v,spec); T_adv = eng.semi_lagrangian(T,u,v,spec); q_adv = eng.semi_lagrangian(q,u,v,spec); u_adv = eng.semi_lagrangian(u,u,v,spec); v_adv = eng.semi_lagrangian(v,u,v,spec)
    terms["advection"]["primary"] = h_adv-h; terms["advection"]["secondary"] = T_adv-T; terms["advection"]["tertiary"] = q_adv-q; terms["advection"]["u"] = u_adv-u; terms["advection"]["v"] = v_adv-v
    geop = G*(h_adv+0.18*topo); pgx = pg_scale*eng.grad_x(geop,spec); pgy = pg_scale*eng.grad_y(geop,spec); topo_drag = 1.0+0.00035*topo
    terms["drift"]["u"] = -spec.dt*pgx + spec.dt*F0*v_adv - spec.dt*drag*topo_drag*u_adv
    terms["drift"]["v"] = -spec.dt*pgy - spec.dt*F0*u_adv - spec.dt*drag*topo_drag*v_adv
    div = eng.grad_x(u_adv,spec)+eng.grad_y(v_adv,spec); terms["drift"]["primary"] = -spec.dt*0.55*h_adv/BASE_H*div
    qsat = saturation_specific_humidity(T_adv); excess = np.maximum(q_adv-qsat,0.0); cond = 0.20*excess*humid_couple; latent = (LV/CP)*cond*1.0e-4
    T_eq = 286.5-0.0032*topo; q_source = 2.0e-6*np.exp(-6.0*(aux["XX"]**2+aux["YY"]**2))
    terms["correction"]["secondary"] = spec.dt*latent - spec.dt*1.4e-5*(T_adv-T_eq); terms["correction"]["tertiary"] = spec.dt*q_source - spec.dt*cond
    terms["diffusion"]["u"] = spec.dt*Kh*eng.lap(u_adv,spec); terms["diffusion"]["v"] = spec.dt*Kh*eng.lap(v_adv,spec)
    terms["diffusion"]["primary"] = spec.dt*Kh*0.35*eng.lap(h_adv,spec); terms["diffusion"]["secondary"] = spec.dt*Kt*eng.lap(T_adv,spec); terms["diffusion"]["tertiary"] = spec.dt*Kq*eng.lap(q_adv,spec)
    H_obs = BASE_H + 200.0*np.exp(-6.8*((aux["XX"]+0.18)**2+(aux["YY"]+0.10)**2)) - 150.0*np.exp(-8.0*((aux["XX"]-0.28)**2+(aux["YY"]-0.14)**2)) - 0.23*topo
    T_obs = 289.0 + 7.5*np.exp(-8.2*((aux["XX"]+0.16)**2+(aux["YY"]+0.11)**2)) - 5.8*np.exp(-8.8*((aux["XX"]-0.24)**2+(aux["YY"]-0.17)**2)) - 0.0038*topo + 0.8*np.sin(1.2*np.pi*aux["XX"])*np.cos(0.8*np.pi*aux["YY"])
    Q_obs = 0.010 + 0.011*np.exp(-7.6*((aux["XX"]-0.10)**2+(aux["YY"]+0.21)**2)) + 0.0016*np.sin(np.pi*aux["YY"])
    U_obs = 12.0*np.sin(0.9*np.pi*aux["YY"])*np.cos(0.8*np.pi*aux["XX"]); V_obs = -8.5*np.sin(0.8*np.pi*aux["XX"])*np.cos(0.9*np.pi*aux["YY"])
    terms["observation"]["primary"] = spec.dt*nudging*(H_obs-h_adv); terms["observation"]["secondary"] = spec.dt*nudging*(T_obs-T_adv); terms["observation"]["tertiary"] = spec.dt*nudging*(Q_obs-q_adv); terms["observation"]["u"] = spec.dt*nudging*(U_obs-u_adv); terms["observation"]["v"] = spec.dt*nudging*(V_obs-v_adv)
    return terms

def td_step(state, carr, req, gal):
    eng = gal.engine; dyn = {k: np.array(v, copy=True) for k, v in state.dyn.items()}; aux = {k: np.array(v, copy=True) for k, v in state.aux.items()}
    cfg = operator_config(state.meta["domain"]); terms = operator_terms(state, carr, req, gal)
    for k in dyn:
        dyn[k] = dyn[k] + terms["advection"][k] + terms["drift"][k] + terms["diffusion"][k] + terms["correction"][k] + terms["observation"][k]
    for k, alpha in cfg["smooth_alpha"].items(): dyn[k] = eng.smooth(dyn[k], alpha)
    for k, (lo, hi) in cfg["bounds"].items(): dyn[k] = clip(dyn[k], lo, hi)
    return UnifiedState(dyn=dyn, aux=aux, meta=dict(state.meta))

def td_rollout(initial, carr, req, gal):
    state = UnifiedState(dyn={k: np.array(v, copy=True) for k, v in initial.dyn.items()}, aux={k: np.array(v, copy=True) for k, v in initial.aux.items()}, meta=dict(initial.meta))
    steps = 1 if state.meta["domain"] == "plan" else int(req["runtime"]["weather_steps"])
    for _ in range(steps): state = td_step(state, carr, req, gal)
    return state

def build_tensor_bundle(final_state, carr, req):
    domain = final_state.meta["domain"]
    if domain == "plan":
        B, H, W = final_state.dyn["primary"].shape
        subj = req["subject"]; fams = carr["family"]; n = carr["n"][:,0,0]; rho = carr["rho"][:,0,0]; A = carr["A"][:,0,0]; sigma = carr["sigma"][:,0,0]
        primary = final_state.dyn["primary"].mean(axis=(1,2)); secondary = final_state.dyn["secondary"].mean(axis=(1,2)); tertiary = final_state.dyn["tertiary"].mean(axis=(1,2)); resource = final_state.dyn["resource"].mean(axis=(1,2)); governance = final_state.aux["governance"].mean(axis=(1,2))
        locks = np.array([family_lock(f, float(nn)) for f, nn in zip(fams, n)]); yb, sb, rb = family_bias_table(fams)
        predictions_scalar = {
            "feasibility": np.clip(0.25*subj["output_power"] + 0.18*subj["aim_coupling"] + 0.12*resource + 0.18*A + 0.15*locks + yb - 0.08*sigma, 0.0, 1.2),
            "stability": np.clip(0.28*subj["control_precision"] + 0.18*subj["load_tolerance"] + 0.20*primary + 0.15*(1.0-tertiary) + 0.12*(1.0-sigma) + sb, 0.0, 1.2),
            "field_fit": np.clip(0.32*secondary*np.where(fams=="network", 1.2, 1.0) + 0.22*primary + 0.18*subj["phase_proximity"] + 0.10*rho + 0.08*locks - 0.10*governance, 0.0, 1.2),
            "risk": np.clip(0.18*tertiary + 0.14*governance + 0.12*subj["instability_sensitivity"] + 0.10*subj["stress_level"] + 0.08*sigma + 0.05*np.maximum(0.0, (n-20000.0)/10000.0) + rb, 0.0, 1.2),
        }
        predictions = {k: expand_scalar_to_field(v, H, W) for k, v in predictions_scalar.items()}
        targets = {k: np.zeros_like(v) for k, v in predictions.items()}
        metric_specs = {
            "feasibility": {"family":"field_mse", "pred":"feasibility", "target":"feasibility"},
            "stability": {"family":"field_mse", "pred":"stability", "target":"stability"},
            "field_fit": {"family":"field_mse", "pred":"field_fit", "target":"field_fit"},
            "risk": {"family":"field_mse", "pred":"risk", "target":"risk"},
            "spread_penalty": {"family":"field_spread", "channels":["feasibility","stability","field_fit"]},
        }
        reward_schema = {
            "family":"weighted_linear",
            "metric_keys":["feasibility","stability","field_fit","risk","spread_penalty"],
            "output_map":{"feasibility":"feasibility","stability":"stability","field_fit":"field_fit","risk":"risk"},
            "policy":{"name":"plan_nutrient"}
        }
        return {"mode":"tensor", "predictions":predictions, "targets":targets, "metric_specs":metric_specs, "reward_schema":reward_schema, "meta":{"family":fams, "n":n, "domain":"plan"}}
    h = final_state.dyn["primary"]; T = final_state.dyn["secondary"]; q = final_state.dyn["tertiary"]; u = final_state.dyn["u"]; v = final_state.dyn["v"]
    topo = final_state.aux["topography"]; XX = final_state.aux["XX"]; YY = final_state.aux["YY"]
    predictions = {"weather_h":h, "weather_T":T, "weather_q":q, "weather_u":u, "weather_v":v}
    targets = {
        "weather_h": BASE_H + 200.0*np.exp(-6.8*((XX+0.18)**2+(YY+0.10)**2)) - 150.0*np.exp(-8.0*((XX-0.28)**2+(YY-0.14)**2)) - 0.23*topo,
        "weather_T": 289.0 + 7.5*np.exp(-8.2*((XX+0.16)**2+(YY+0.11)**2)) - 5.8*np.exp(-8.8*((XX-0.24)**2+(YY-0.17)**2)) - 0.0038*topo + 0.8*np.sin(1.2*np.pi*XX)*np.cos(0.8*np.pi*YY),
        "weather_q": 0.010 + 0.011*np.exp(-7.6*((XX-0.10)**2+(YY+0.21)**2)) + 0.0016*np.sin(np.pi*YY),
        "weather_u": 12.0*np.sin(0.9*np.pi*YY)*np.cos(0.8*np.pi*XX),
        "weather_v": -8.5*np.sin(0.8*np.pi*XX)*np.cos(0.9*np.pi*YY),
    }
    metric_specs = {
        "weather_h_err": {"family":"field_mse", "pred":"weather_h", "target":"weather_h"},
        "weather_t_err": {"family":"field_mse", "pred":"weather_T", "target":"weather_T"},
        "weather_q_err": {"family":"field_mse", "pred":"weather_q", "target":"weather_q"},
        "weather_w_err": {"family":"field_vector_mse", "pred":["weather_u","weather_v"], "target":["weather_u","weather_v"]},
        "weather_instability": {"family":"field_laplacian_energy", "channels":["weather_h","weather_T","weather_q","weather_u","weather_v"]},
    }
    reward_schema = {
        "family":"weighted_linear",
        "metric_keys":["weather_h_err","weather_t_err","weather_q_err","weather_w_err","weather_instability"],
        "output_map":{"weather_h_err":"h_err","weather_t_err":"t_err","weather_q_err":"q_err","weather_w_err":"w_err","weather_instability":"instability"}
    }
    return {"mode":"tensor", "predictions":predictions, "targets":targets, "metric_specs":metric_specs, "reward_schema":reward_schema, "meta":{"domain":"meteorology"}}

def build_metric_bundle(bundle, req):
    specs = bundle["metric_specs"]; preds = bundle["predictions"]; tgts = bundle["targets"]; out = {}
    gspec = None; eng = None
    for name, spec in specs.items():
        family = spec["family"]
        if family == "field_mse":
            out[name] = ((preds[spec["pred"]] - tgts[spec["target"]])**2).mean(axis=(1,2))
        elif family == "field_vector_mse":
            a = (preds[spec["pred"][0]] - tgts[spec["target"][0]])**2
            b = (preds[spec["pred"][1]] - tgts[spec["target"][1]])**2
            out[name] = (a + b).mean(axis=(1,2))
        elif family == "field_spread":
            arr = np.stack([preds[ch].mean(axis=(1,2)) for ch in spec["channels"]], axis=1)
            out[name] = np.std(arr, axis=1)
        elif family == "field_laplacian_energy":
            if gspec is None:
                sample = preds[spec["channels"][0]]
                gspec = GridSpec(shape=(sample.shape[-1], sample.shape[-2]), dx=DX, dy=DY, dt=float(req["runtime"]["weather_dt"]))
                eng = GridComputeEngine()
            out[name] = (
                np.abs(eng.lap(preds["weather_T"], gspec)).mean(axis=(1,2)) +
                0.8*np.abs(eng.lap(preds["weather_q"], gspec)).mean(axis=(1,2)) +
                0.5*np.abs(eng.lap(preds["weather_u"], gspec)).mean(axis=(1,2)) +
                0.5*np.abs(eng.lap(preds["weather_v"], gspec)).mean(axis=(1,2)) +
                0.35*np.abs(eng.lap(preds["weather_h"], gspec)).mean(axis=(1,2))
            )
    return out

def apply_reward_policy(bundle, metrics, req):
    schema = bundle["reward_schema"]
    policy = schema.get("policy")
    if not policy:
        return {}
    if policy["name"] == "plan_nutrient":
        fams = bundle["meta"]["family"]; n = bundle["meta"]["n"]; nutrient_cfg = req["reward"]["nutrient"]
        route_bonus = np.where(fams=="network", 0.14*metrics["field_fit"] + 0.06*metrics["feasibility"], 0.0) + np.where(fams=="phase", 0.07*(1.0-metrics["risk"]), 0.0) + np.where((fams=="batch") & (np.abs(n-20000.0)<=1e-6), 0.05, 0.0) + np.where(np.abs(n-20000.0)<=1e-6, 0.06, 0.0)
        nutrient = nutrient_cfg["feasibility_threshold_gain"]*np.maximum(0.0, metrics["feasibility"]-0.82) + nutrient_cfg["stability_threshold_gain"]*np.maximum(0.0, metrics["stability"]-0.80) + nutrient_cfg["field_fit_threshold_gain"]*np.maximum(0.0, metrics["field_fit"]-0.68) + route_bonus + nutrient_cfg["risk_penalty"]*metrics["risk"] + nutrient_cfg["oversize_penalty"]*np.maximum(0.0, (n-20000.0)/5000.0)
        return {"nutrient_gain": nutrient}
    return {}

def build_reward_bundle(bundle, metrics, req):
    reward = req["reward"]["components"]
    schema = bundle["reward_schema"]
    score = np.zeros_like(next(iter(metrics.values())))
    for k in schema["metric_keys"]:
        score = score + reward[k] * metrics[k]
    out = {"score": score}
    for src, dst in schema.get("output_map", {}).items():
        out[dst] = metrics[src]
    out.update(apply_reward_policy(bundle, metrics, req))
    return out

def observe_batch(final_state, carr, req):
    bundle = build_tensor_bundle(final_state, carr, req)
    metrics = build_metric_bundle(bundle, req)
    return build_reward_bundle(bundle, metrics, req)

def batch_rows_from_metrics(candidates, metrics):
    rows = []
    for i, c in enumerate(candidates):
        row = {"family": c["family"], "template": c["template"], "params": c["params"]}
        for k, arr in metrics.items(): row[k] = float(arr[i])
        rows.append(row)
    return rows

def run_batched_domain(req, domain, candidates, initial_state, spec):
    gal = GridAbstractionLayer(spec); candidates = gal.scheduler(candidates)
    carr = prepare_candidate_arrays(candidates); final_state = td_rollout(initial_state, carr, req, gal); metrics = observe_batch(final_state, carr, req)
    rows = batch_rows_from_metrics(candidates, metrics); rows = sorted(rows, key=lambda x: x["score"], reverse=True); scores = [r["score"] for r in rows]
    for i, row in enumerate(rows): row["branch_status"] = classify_relative(scores, i)
    return rows, gal

def td_hydro_control(rows):
    ranked = sorted(rows, key=lambda x: x["score"], reverse=True)
    margin = ranked[0]["score"] - ranked[1]["score"] if len(ranked) > 1 else 0.0; spread = ranked[0]["score"] - ranked[-1]["score"] if len(ranked) > 1 else 0.0
    pressure_balance = 1.0
    if margin < 0.08: pressure_balance += 0.04
    if spread > 1.4: pressure_balance -= 0.03
    pressure_balance = float(np.clip(pressure_balance, 0.94, 1.08))
    return {"pressure_balance": pressure_balance, "top_margin": float(margin), "score_spread": float(spread), "mean_score": float(np.mean([m["score"] for m in rows])) if rows else 0.0}

def run_plan(req, external_boost=None):
    shape = tuple(req["runtime"]["plan_grid_shape"]); spec = GridSpec(shape=shape, dx=1.0, dy=1.0, dt=1.0, engine=req["runtime"]["grid_engine"])
    candidates = generate_plan_candidates(); B = len(candidates); initial = encode_plan_state_batch(req, spec, B, external_boost)
    rows, gal = run_batched_domain(req, "plan", candidates, initial, spec); hydro = td_hydro_control(rows[:12]); best = rows[0]
    return {"mapping": "plan", "best_worldline": best, "main_worldline_alive": best["branch_status"] in ("active", "restricted"), "main_worldline_active": best["branch_status"] == "active", "hydro_control_state": hydro, "branch_histogram": histogram_of_status(rows[:12]), "top_worldlines": rows[:5], "grid_summary": gal.aggregate(rows)}

def run_meteorology(req):
    xw, yh = req["runtime"]["weather_grid_shape"]; spec = GridSpec(shape=(xw, yh), dx=DX, dy=DY, dt=float(req["runtime"]["weather_dt"]), engine=req["runtime"]["grid_engine"])
    candidates = generate_weather_candidates(); B = len(candidates); initial = encode_meteorology_state_batch(req, spec, B)
    rows, gal = run_batched_domain(req, "meteorology", candidates, initial, spec); hydro = td_hydro_control(rows)
    candidates2 = []
    for c in candidates:
        c2 = {"family": c["family"], "template": c["template"], "params": dict(c["params"]), "domain": c["domain"]}; c2["params"]["pg_scale"] *= hydro["pressure_balance"]; candidates2.append(c2)
    rows2, gal2 = run_batched_domain(req, "meteorology", candidates2, initial, spec); best = rows2[0]
    return {"mapping": "meteorology", "best_worldline": best["family"], "best_status": best["branch_status"], "hydro_control": hydro, "branch_histogram": histogram_of_status(rows2), "ranking": rows2, "grid_summary": gal2.aggregate(rows2)}

def weather_to_plan_boost(weather_oracle):
    hist = weather_oracle["branch_histogram"]; total = max(1, sum(hist.values()))
    active_ratio = hist["active"] / total; restricted_ratio = hist["restricted"] / total; score_spread = weather_oracle["hydro_control"].get("score_spread", 0.0); best_branch = weather_oracle["best_worldline"]
    return {"field_coherence": 0.06*active_ratio - 0.02*restricted_ratio, "network_amplification": 0.04 if best_branch in ("high_mix","balanced","humid_bias") else -0.03, "phase_turbulence": -0.04*active_ratio + 0.03*(best_branch=="strong_pg"), "resource_elasticity": 0.02 if score_spread < 1.0 else -0.01}

def run_unified(req):
    routing = route_mappings(req)
    if routing["coupled"]:
        weather = run_meteorology(req); boost = weather_to_plan_boost(weather); plan = run_plan(req, boost)
        return {"mapping_mode":"auto_coupled","routing":routing,"meteorology_shell":weather,"plan_kernel":plan,"best_worldline":plan["best_worldline"],"oracle_summary":{"dominant_mapping":"coupled","main_worldline_alive":plan["main_worldline_alive"],"main_worldline_active":plan["main_worldline_active"]}}
    if routing["meteorology"]:
        weather = run_meteorology(req)
        return {"mapping_mode":"auto_meteorology","routing":routing,"meteorology_shell":weather,"best_worldline":{"family":weather["best_worldline"],"branch_status":weather["best_status"]},"oracle_summary":{"dominant_mapping":"meteorology","main_worldline_active":weather["best_status"]=="active"}}
    plan = run_plan(req)
    return {"mapping_mode":"auto_plan","routing":routing,"plan_kernel":plan,"best_worldline":plan["best_worldline"],"oracle_summary":{"dominant_mapping":"plan","main_worldline_alive":plan["main_worldline_alive"],"main_worldline_active":plan["main_worldline_active"]}}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default=None)
    parser.add_argument("--outdir", default="./tree_diagram_unified_out_v15")
    args = parser.parse_args()
    req = load_request(args.input); oracle = run_unified(req)
    outdir = Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)
    outpath = outdir / "unified_oracle.json"
    outpath.write_text(json.dumps(oracle, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(oracle, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
