#!/usr/bin/env python3
"""
Social Molecular Dynamics with Cross‑Entropy Influence (SMD‑CE).

This module implements a simplified social molecular dynamics model
incorporating network cross‑entropy to quantify and inject
"influence" back into the dynamics. It fits the Tree Diagram Engine
interface by providing a ``simulate(cfg, seed)`` function and
producing riskfield, curve, graph and sample trajectories.

Key features:

  * Each agent has a position (x,y) and velocity (vx,vy) in a
    two‑dimensional state space. A double‑well potential in x
    encourages two preferred locations (value and bubble), while y
    is unconstrained. Damping and stochastic noise allow
    individuals to diffuse and occasionally "cross the barrier".

  * The social network at time t is induced by proximity: the weight
    from agent i to j is ``w_ij = exp(-dist^2 / sigma^2)`` with an
    optional self‑loop. From this an outgoing probability
    distribution P_t(j|i) is computed by row normalisation.

  * A network cross‑entropy increment is computed between the
    previous distribution P_{t-Δ} and the current P_t:
    ``I_ce = (1/N) \sum_i \sum_j P_prev[i][j] * log(P_prev[i][j] / (P_t[i][j] + eps))``.
    This quantifies how much the network structure has changed.

  * The cross‑entropy drives the dynamics by modulating the noise
    amplitude: ``D(t) = kT * exp(entropy) * (1 + kappa * I_ce)``. A
    larger I_ce corresponds to stronger fluctuations.

  * Outputs follow the Tree Diagram contract: ``riskfield`` is the
    occupancy histogram on a coarse grid, ``curve`` stores the
    cross‑entropy value per step, ``graph`` is a weighted directed
    network of transitions between grid cells, and ``samples`` holds
    a few agent trajectories.

Note: This model is highly simplified; real social dynamics may
require more sophisticated network evolution and external fields.
Nevertheless it demonstrates how network cross‑entropy can be
integrated into a dynamical system.
"""

from __future__ import annotations

import argparse
import json
import math
import random
from dataclasses import dataclass
from typing import Dict, List, Tuple


@dataclass
class SMDConfig:
    """Configuration parameters for SMD‑CE simulation."""

    steps: int = 300         # number of simulation steps
    dt: float = 0.02         # time step size
    grid: int = 32           # coarse grid resolution for riskfield and WCN
    n: int = 200             # number of agents
    mass: float = 1.0        # agent mass (unused presently but reserved)
    gamma: float = 0.5       # friction coefficient
    kT: float = 0.05         # base thermal energy (noise prefactor)
    entropy: float = 0.0     # entropy knob; scales noise baseline
    temp_ramp: float = 0.0   # unused in this model but included for interface
    a: float = 1.0           # double‑well potential parameter in x
    kappa: float = 2.0       # scaling of cross‑entropy influence on noise
    sigma: float = 0.5       # width of proximity weighting in network
    boxmin: float = -1.0     # spatial bounds (square domain)
    boxmax: float = 1.0
    topk_edges: int = 30     # number of WCN edges to return
    sample_traces: int = 16  # number of trajectories to record


def simulate(cfg: SMDConfig, seed: int = 123) -> Dict:
    """Run an SMD‑CE simulation and return Tree Diagram outputs.

    Parameters
    ----------
    cfg : SMDConfig
        Configuration parameters controlling the simulation.
    seed : int, optional
        Random seed for reproducibility.

    Returns
    -------
    dict
        A dictionary with keys ``riskfield``, ``curve``, ``graph``,
        ``samples`` and ``meta``. ``curve`` contains the cross‑entropy
        value at each step.
    """
    rng = random.Random(seed)

    # Initialise positions uniformly in the box
    xs = [rng.uniform(cfg.boxmin, cfg.boxmax) for _ in range(cfg.n)]
    ys = [rng.uniform(cfg.boxmin, cfg.boxmax) for _ in range(cfg.n)]
    # Initialise velocities from a Maxwellian distribution
    D0 = cfg.kT * math.exp(cfg.entropy)
    std0 = math.sqrt(D0 / cfg.mass)
    vxs = [rng.gauss(0.0, std0) for _ in range(cfg.n)]
    vys = [rng.gauss(0.0, std0) for _ in range(cfg.n)]
    # Containers for outputs
    occ = [0] * (cfg.grid * cfg.grid)
    trans_counts: Dict[Tuple[int, int], int] = {}
    prev_bucket = [None] * cfg.n
    # Sample trajectories
    sample_ids = list(range(min(cfg.sample_traces, cfg.n)))
    samples: Dict[str, List[Tuple[float, float]]] = {str(i): [] for i in sample_ids}
    # Store cross‑entropy per step (curve)
    ce_curve: List[float] = []
    # Previous network distribution (list of lists); None for first step
    prev_P: List[List[float]] | None = None
    # Precompute double‑well potential derivative function
    # U(x) = a (x^2 - 1)^2 => dU/dx = 4a x (x^2 - 1)
    def dU_dx(x: float) -> float:
        return 4.0 * cfg.a * x * (x * x - 1.0)
    # Domain width for wrapping
    L = cfg.boxmax - cfg.boxmin
    # Simulation loop
    for step in range(cfg.steps):
        # 1) Compute network weights and cross‑entropy
        # Build adjacency weight matrix w_{ij}
        # We will also compute row sums for normalisation
        P_current = [[0.0] * cfg.n for _ in range(cfg.n)]
        row_sum = [0.0] * cfg.n
        # Compute weights; include self weight to avoid zero rows
        for i in range(cfg.n):
            xi, yi = xs[i], ys[i]
            # Self weight ensures P_current[i] sums to >0
            w_self = 1.0
            P_current[i][i] = w_self
            row_sum[i] = w_self
        # Add proximity weights
        sigma2 = cfg.sigma * cfg.sigma
        for i in range(cfg.n):
            xi, yi = xs[i], ys[i]
            for j in range(cfg.n):
                if i == j:
                    continue
                dx = xi - xs[j]
                dy = yi - ys[j]
                dist2 = dx * dx + dy * dy
                w_ij = math.exp(-dist2 / sigma2)
                P_current[i][j] += w_ij
                row_sum[i] += w_ij
        # Normalise to get probabilities P_current[j|i]
        for i in range(cfg.n):
            denom = row_sum[i]
            inv = 1.0 / denom if denom > 0 else 0.0
            for j in range(cfg.n):
                P_current[i][j] *= inv
        # Compute cross‑entropy (actually KL divergence) between prev and current
        I_ce = 0.0
        if prev_P is not None:
            eps = 1e-12
            for i in range(cfg.n):
                # KL divergence for row i: sum p_prev * log(p_prev / p_curr)
                row_prev = prev_P[i]
                row_curr = P_current[i]
                for j in range(cfg.n):
                    p_prev = row_prev[j]
                    if p_prev > 0:
                        p_curr = row_curr[j] + eps
                        I_ce += p_prev * math.log(p_prev / p_curr)
            # Average per node
            I_ce /= cfg.n
        # Append to curve
        ce_curve.append(I_ce)
        # Set prev_P for next iteration
        prev_P = [row[:] for row in P_current]
        # 2) Determine noise amplitude D(t)
        D_t = D0 * (1.0 + cfg.kappa * I_ce)
        # 3) Update velocities and positions (Euler–Maruyama)
        # Precompute sqrt factor once per step
        sqrt_fac = math.sqrt(2.0 * D_t * cfg.dt)
        for i in range(cfg.n):
            # deterministic force from double‑well potential in x
            f_x = -dU_dx(xs[i])
            # friction
            f_x -= cfg.gamma * vxs[i]
            f_y = -cfg.gamma * vys[i]
            # integrate velocity
            vxs[i] += f_x * cfg.dt + sqrt_fac * rng.gauss(0.0, 1.0)
            vys[i] += f_y * cfg.dt + sqrt_fac * rng.gauss(0.0, 1.0)
            # integrate position
            xs[i] += vxs[i] * cfg.dt
            ys[i] += vys[i] * cfg.dt
            # wrap positions into box
            # Equivalent to periodic boundary conditions
            # note: keep xs, ys within [boxmin, boxmax)
            xi = xs[i]
            yi = ys[i]
            while xi < cfg.boxmin:
                xi += L
            while xi >= cfg.boxmax:
                xi -= L
            while yi < cfg.boxmin:
                yi += L
            while yi >= cfg.boxmax:
                yi -= L
            xs[i] = xi
            ys[i] = yi
        # 4) Accumulate riskfield occupancy and WCN transitions
        # riskfield: 2D grid occupancy counts
        for i in range(cfg.n):
            # map (x,y) to grid index
            gx = int((xs[i] - cfg.boxmin) / L * cfg.grid)
            gy = int((ys[i] - cfg.boxmin) / L * cfg.grid)
            # clamp to [0,grid-1]
            gx = max(0, min(cfg.grid - 1, gx))
            gy = max(0, min(cfg.grid - 1, gy))
            cell_idx = gy * cfg.grid + gx
            occ[cell_idx] += 1
            # transitions
            if prev_bucket[i] is not None:
                k = (prev_bucket[i], cell_idx)
                trans_counts[k] = trans_counts.get(k, 0) + 1
            prev_bucket[i] = cell_idx
        # 5) Record sample trajectories
        for sid in sample_ids:
            samples[str(sid)].append((xs[sid], ys[sid]))
    # Normalise riskfield
    total_occ = sum(occ) or 1
    riskfield = [v / total_occ for v in occ]
    # Build WCN graph (top‑k edges)
    edges = sorted(trans_counts.items(), key=lambda kv: kv[1], reverse=True)[: cfg.topk_edges]
    graph = [[u, v, w] for (u, v), w in edges]
    # Return result
    return {
        "riskfield": riskfield,
        "curve": ce_curve,
        "graph": graph,
        "samples": samples,
        "meta": {
            "kernel": "smd_ce",
            "steps": cfg.steps,
            "dt": cfg.dt,
            "grid": cfg.grid,
            "n": cfg.n,
            "gamma": cfg.gamma,
            "kT": cfg.kT,
            "entropy": cfg.entropy,
            "kappa": cfg.kappa,
            "sigma": cfg.sigma,
        },
    }


def main() -> None:
    """Command‑line interface for running SMD‑CE simulation stand‑alone."""
    parser = argparse.ArgumentParser(description="Run SMD‑CE simulation")
    parser.add_argument("--steps", type=int, default=300, help="Number of steps")
    parser.add_argument("--dt", type=float, default=0.02, help="Time step size")
    parser.add_argument("--grid", type=int, default=32, help="Grid resolution")
    parser.add_argument("--n", type=int, default=200, help="Number of agents")
    parser.add_argument("--gamma", type=float, default=0.5, help="Friction coefficient")
    parser.add_argument("--kT", type=float, default=0.05, help="Base thermal energy")
    parser.add_argument("--entropy", type=float, default=0.0, help="Entropy knob (scales noise baseline)")
    parser.add_argument("--a", type=float, default=1.0, help="Double‑well potential parameter")
    parser.add_argument("--kappa", type=float, default=2.0, help="Cross‑entropy scaling coefficient")
    parser.add_argument("--sigma", type=float, default=0.5, help="Proximity width for network weights")
    parser.add_argument("--out", type=str, default="tde_smd_ce_outputs.json", help="Output JSON file")
    parser.add_argument("--seed", type=int, default=123, help="Random seed")
    args = parser.parse_args()
    cfg = SMDConfig(
        steps=args.steps,
        dt=args.dt,
        grid=args.grid,
        n=args.n,
        gamma=args.gamma,
        kT=args.kT,
        entropy=args.entropy,
        a=args.a,
        kappa=args.kappa,
        sigma=args.sigma,
    )
    res = simulate(cfg, seed=args.seed)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False)
    print(f"Wrote {args.out}")
    print("meta:", res["meta"])
    print("riskfield len:", len(res["riskfield"]), "curve len:", len(res["curve"]), "edges:", len(res["graph"]))


if __name__ == "__main__":
    main()